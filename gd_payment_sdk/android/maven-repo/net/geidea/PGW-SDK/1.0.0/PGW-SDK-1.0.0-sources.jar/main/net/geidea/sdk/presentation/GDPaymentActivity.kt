package net.geidea.sdk.presentation


import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import net.geidea.sdk.core.di.DependencyContainer
import net.geidea.sdk.core.di.ProvideDependencies
import net.geidea.sdk.core.di.inject
import net.geidea.sdk.core.navigation.SDKNavigation
import net.geidea.sdk.core.ui.theme.GeideaSDKTheme
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.sdk.GDPaymentSDK
import net.geidea.sdk.sdk.SDKTheme


internal class GDPaymentActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        GDPaymentSDK.sharedInstance().registerActivity(this)
        enableEdgeToEdge()
        setContent {
            GDPaymentSDKCompose()
        }

        onBackPressedDispatcher.addCallback {
            GDPaymentSDK.sharedInstance().onPaymentCanceled()
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        GDPaymentSDK.sharedInstance().unregisterActivity(this)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun GDPaymentSDKCompose(navController: NavHostController = rememberNavController()) {
    ProvideDependencies(DependencyContainer.getInstance()) {
        GeideaSDKTheme(
            theme = inject<SDKTheme>(),
            language = GDPaymentSDK.sharedInstance().getConfigurations().language
        ) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = SdkTheme.colors.surface
            ) { innerPadding ->
                SDKNavigation(navController)
            }
        }
    }
}
