package net.geidea.sdk.presentation.features.paymentdetails.components.card.model

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import kotlinx.collections.immutable.toPersistentList
import net.geidea.sdk.core.ui.models.TextFieldInput
import net.geidea.sdk.core.ui.models.updateTextField
import net.geidea.sdk.core.utils.extensions.getCurrentMonth
import net.geidea.sdk.core.utils.extensions.getCurrentYear
import net.geidea.sdk.domain.model.CardModel
import net.geidea.sdk.domain.model.paymentdetails.SupportedCard
import org.json.JSONObject

@Immutable
@Stable
internal data class CardUiModel(
    internal val id: String = "",
    @DrawableRes internal val iconResId: Int? = null,
    internal val cardNumber: TextFieldInput = TextFieldInput(),
    internal val expiryDate: TextFieldInput = TextFieldInput(),
    internal val cvv: TextFieldInput = TextFieldInput(),
    internal val nameOnCard: TextFieldInput = TextFieldInput(),
    internal val isCardSaved: Boolean = false,
    internal val month: Int = getCurrentMonth(),
    internal val year: Int = getCurrentYear(),
    internal val showDatePicker: Boolean = false,
    internal val showSavedCard: Boolean = false,
    internal val supportedCards: List<SupportedCard> = listOf(),
    internal val possibleBrand: SupportedCard? = null,
) {
    internal val isValid: Boolean
        get() = cardNumber.validation.isValid &&
                expiryDate.validation.isValid &&
                cvv.validation.isValid &&
                nameOnCard.validation.isValid
}


internal fun CardModel.toState() = CardUiModel(
    id = this.id,
    cardNumber = updateTextField(this.cardNumber),
    expiryDate = updateTextField(this.expiryDate),
    cvv = updateTextField(this.cvv),
    nameOnCard = updateTextField(this.nameOnCard),
    iconResId = this.iconResId
)

internal fun CardUiModel.toJson(): String {
    return JSONObject().apply {
        put("id", id)
        put("iconResId", iconResId)
        put("cardNumber", cardNumber.value)
        put("expiryDate", expiryDate.value)
        put("cvv", cvv.value)
        put("nameOnCard", nameOnCard.value)
        put("isCardSaved", isCardSaved)
        put("month", month)
        put("year", year)
        put("showDatePicker", showDatePicker)
        // Note: supportedCards and possibleBrand would need additional serialization if needed
    }.toString()
}

internal fun cardUiModelFromJson(jsonString: String): CardUiModel {
    val json = JSONObject(jsonString)


    return CardUiModel(
        id = json.optString("id"),
        iconResId = if (json.has("iconResId") && !json.isNull("iconResId")) json.getInt("iconResId") else null,
        cardNumber = TextFieldInput(value = json.optString("cardNumber")),
        expiryDate = TextFieldInput(value = json.optString("expiryDate")),
        cvv = TextFieldInput(value = json.optString("cvv")),
        nameOnCard = TextFieldInput(value = json.optString("nameOnCard")),
        isCardSaved = json.optBoolean("isCardSaved"),
        month = json.optInt("month", getCurrentMonth()),
        year = json.optInt("year", getCurrentYear()),
        showDatePicker = json.optBoolean("showDatePicker")

    )
}

internal fun List<CardModel>.toStateList() = this.map { it.toState() }.toPersistentList()