package net.geidea.sdk.core.ui.components

import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.asImageBitmap
import net.geidea.sdk.core.utils.extensions.toBitmap


@Composable
internal fun MerchantLogo(modifier : Modifier = Modifier, merchantLogo: Drawable?){

    if(merchantLogo != null){
        Image(
            bitmap = merchantLogo.toBitmap().asImageBitmap(),
            contentDescription = "Merchant Logo",
            modifier = modifier.wrapContentSize()
                .scale(1.5f)
        )
    } else {
        GeideaLogo(modifier)
    }

}