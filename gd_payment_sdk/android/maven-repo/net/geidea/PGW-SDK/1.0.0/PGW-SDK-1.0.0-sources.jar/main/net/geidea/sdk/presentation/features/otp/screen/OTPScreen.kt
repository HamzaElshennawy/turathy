package net.geidea.sdk.presentation.features.otp.screen

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.net.http.SslError
import android.view.View
import android.view.ViewGroup
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.viewinterop.AndroidView
import net.geidea.sdk.BuildConfig
import net.geidea.sdk.R
import net.geidea.sdk.core.di.injectViewModel
import net.geidea.sdk.core.mvi.ViewEvent
import net.geidea.sdk.core.ui.BaseScreen
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.utils.extensions.isReturnUrl
import net.geidea.sdk.domain.model.otp.ReturnUrlParams
import net.geidea.sdk.domain.model.pay.PerformAuthenticateResponse
import net.geidea.sdk.presentation.features.otp.viewmodel.OTPEffect
import net.geidea.sdk.presentation.features.otp.viewmodel.OTPEvent
import net.geidea.sdk.presentation.features.otp.viewmodel.OTPViewModel
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.CardUiModel
import net.geidea.sdk.sdk.GDPaymentSDK

@Composable
internal fun OTPScreen(
    viewModel: OTPViewModel = injectViewModel<OTPViewModel>(),
    authResponse: PerformAuthenticateResponse?,
    cardDetails: CardUiModel?,
    onNavigateBack: () -> Unit = {},
    onNavigateBackToPay: () -> Unit = {},
    onPaymentSuccess: (String) -> Unit = {},
) {
    LaunchedEffect(Unit) {
        viewModel.sendEvent(OTPEvent.OnScreenInit(authResponse, cardDetails))
    }
    BaseScreen(
        viewModel = viewModel,
        onEffect = { effect ->
            when (effect) {
                is OTPEffect.NavigateBack -> onNavigateBack()
                is OTPEffect.SetPaymentSuccess -> {
                    onPaymentSuccess(effect.orderId)
                }

                is OTPEffect.NavigateBackToPay -> onNavigateBackToPay()
            }
        },
        content = { state ->
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Toolbar
                CardAuthToolbar(
                    onBackClick = {
                        viewModel.sendEvent(OTPEvent.OnBackPressed)
                    }
                )

                // Progress Bar
                if (state.showProgressBar) {
                    LinearProgressIndicator(
                        progress = { state.webViewProgress / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = SdkTheme.colors.primary,
                    )
                }

                // WebView
                val htmlContent = state.authResponse?.htmlBodyContent
                if (htmlContent?.isNotEmpty() == true) {
                    CardAuthWebView(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        htmlContent = htmlContent,
                        onReturnUrl = { url ->
                            viewModel.sendEvent(OTPEvent.OnReturnUrl(url))
                        },
                        onProgressChanged = { progress ->
                            viewModel.sendEvent(OTPEvent.OnProgressChanged(progress))
                        },
                        onPageStarted = {
                            viewModel.sendEvent(OTPEvent.OnPageStarted)
                        },
                        onPageFinished = {
                            viewModel.sendEvent(OTPEvent.OnPageFinished)
                        },
                        onError = { error ->
                            viewModel.sendEvent(OTPEvent.OnWebError(error))
                        },
                    )
                }


            }
        },
        overlayDismiss = {
            viewModel.sendEvent(ViewEvent.ClearError)
        }
    )


}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CardAuthToolbar(
    onBackClick: () -> Unit
) {
    TopAppBar(
        title = {
            Text(
                stringResource(R.string.card_auth),
                style = SdkTheme.typography.bold20,
                color = SdkTheme.colors.onPrimary
            )
        },
        navigationIcon = {
            IconButton(
                onClick =
                    onBackClick
            )
            {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.back),
                    tint = SdkTheme.colors.onPrimary
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = SdkTheme.colors.transparent,
            titleContentColor = SdkTheme.colors.neutral900,
            navigationIconContentColor = SdkTheme.colors.neutral900
        )
    )
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun CardAuthWebView(
    modifier: Modifier = Modifier,
    htmlContent: String,
    onReturnUrl: (String) -> Unit,
    onProgressChanged: (Int) -> Unit,
    onPageStarted: () -> Unit,
    onPageFinished: () -> Unit,
    onError: (String) -> Unit,
) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(GDPaymentSDK.sharedInstance().getCurrentActivity() as Activity).apply {
                setLayerType(View.LAYER_TYPE_HARDWARE, null)

                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    cacheMode = WebSettings.LOAD_NO_CACHE
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView, newProgress: Int) {
                        onProgressChanged(newProgress)
                    }
                }

                webViewClient = object : WebViewClient() {
                    @Deprecated("Deprecated in Java")
                    override fun shouldOverrideUrlLoading(
                        view: WebView,
                        url: String
                    ): Boolean {
                        return if (url.isReturnUrl(ReturnUrlParams.RETURN_URL)) {
                            onReturnUrl(url)
                            true
                        } else {
                            false
                        }
                    }

                    override fun onPageStarted(
                        view: WebView?,
                        url: String?,
                        favicon: Bitmap?
                    ) {
                        onPageStarted()
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        onPageFinished()
                    }

                    @SuppressLint("WebViewClientOnReceivedSslError")
                    override fun onReceivedSslError(
                        view: WebView,
                        handler: SslErrorHandler?,
                        error: SslError
                    ) {
                        if (BuildConfig.DEBUG) {
                            handler?.proceed() // Ignore only in debug builds
                        } else {
                            handler?.cancel() // Enforce SSL validation in release builds
                        }
                    }

                    override fun onReceivedError(
                        view: WebView,
                        request: WebResourceRequest,
                        error: WebResourceError?
                    ) {

                    }
                }
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL(
                "",
                htmlContent,
                "text/html",
                "UTF-8",
                null
            )
        }
    )
}