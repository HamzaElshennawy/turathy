package net.geidea.sdk.presentation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.ui.platform.ComposeView
import androidx.fragment.app.Fragment


class GDPaymentFragment : Fragment() {
    companion object {
        const val TAG = "GDPaymentFragment"

        fun newInstance(): GDPaymentFragment {
            return GDPaymentFragment()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setContent {
                GDPaymentSDKCompose()
            }
        }
    }
}