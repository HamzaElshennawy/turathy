package net.geidea.sdk.presentation.features.cardscan.exception

class UnknownScanException(message: String? = null) : Exception(message)
