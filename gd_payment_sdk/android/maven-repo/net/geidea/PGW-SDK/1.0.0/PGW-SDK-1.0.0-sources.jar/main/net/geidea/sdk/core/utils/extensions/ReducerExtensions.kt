package net.geidea.sdk.core.utils.extensions

import net.geidea.sdk.core.ui.validation.ValidationResult
import net.geidea.sdk.core.ui.validation.Validator

internal inline fun <S, V> updateIfChanged(
    state: S,
    currentValue: V,
    newValue: V,
    validator: Validator,
    crossinline update: S.(ValidationResult) -> S
) = if (newValue == currentValue) state
else state.update(validator.validate(newValue.toString()))


internal inline fun <S, V> updateIfChanged(
    state: S, currentValue: V, newValue: V, crossinline update: S.() -> S
) = if (newValue == currentValue) state
else state.update()

