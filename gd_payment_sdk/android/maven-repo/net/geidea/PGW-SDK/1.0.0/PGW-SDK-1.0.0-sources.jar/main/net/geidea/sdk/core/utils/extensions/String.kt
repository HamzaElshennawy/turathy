package net.geidea.sdk.core.utils.extensions

internal fun String.parseQueryParams(): List<Pair<String, String>> {
    return try {
        val queryParams = mutableListOf<Pair<String, String>>()

        // Find the query string part (after '?')
        val queryStartIndex = this.indexOf('?')
        if (queryStartIndex == -1) {
            return emptyList() // No query parameters found
        }

        val queryString = this.substring(queryStartIndex + 1)

        // Handle fragment identifier (remove everything after '#')
        val fragmentIndex = queryString.indexOf('#')
        val cleanQueryString = if (fragmentIndex != -1) {
            queryString.substring(0, fragmentIndex)
        } else {
            queryString
        }

        // Split by '&' to get individual parameter pairs
        val paramPairs = cleanQueryString.split('&')

        for (pair in paramPairs) {
            val equalIndex = pair.indexOf('=')
            if (equalIndex != -1) {
                val key = pair.substring(0, equalIndex).trim()
                val value = pair.substring(equalIndex + 1).trim()

                if (key.isNotEmpty()) {
                    queryParams.add(Pair(key, value))
                }
            } else if (pair.trim().isNotEmpty()) {
                // Handle parameters without values (e.g., "?flag&param=value")
                queryParams.add(Pair(pair.trim(), ""))
            }
        }

        queryParams
    } catch (e: Exception) {
        emptyList() // Return empty list if parsing fails
    }
}

internal fun String.isReturnUrl(url: String): Boolean {
    return this.startsWith(url)
}