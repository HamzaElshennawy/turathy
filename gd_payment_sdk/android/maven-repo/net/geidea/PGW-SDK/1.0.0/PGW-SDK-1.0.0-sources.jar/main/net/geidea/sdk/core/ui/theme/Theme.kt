package net.geidea.sdk.core.ui.theme

import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.LocalLifecycleOwner
import net.geidea.sdk.core.utils.extensions.toComposeColor
import net.geidea.sdk.core.utils.extensions.withSdkLocale
import net.geidea.sdk.sdk.SDKLanguage
import net.geidea.sdk.sdk.SDKTheme

@Composable
internal fun GeideaSDKTheme(
    theme: SDKTheme,
    typography: GSdkTypography = GSdkTypography(),
    language: SDKLanguage = SDKLanguage.ENGLISH,
    content: @Composable () -> Unit
) {
    val layoutDirection = when (language) {
        SDKLanguage.ENGLISH -> LayoutDirection.Ltr
        SDKLanguage.ARABIC -> LayoutDirection.Rtl
    }


    val darkTheme = when (theme.style) {
//        SDKTheme.ThemeStyle.DARK -> true
        SDKTheme.ThemeStyle.LIGHT -> false
        SDKTheme.ThemeStyle.AUTO -> isSystemInDarkTheme()
    }

    val colorScheme = buildSdkColorScheme(darkTheme, theme)
    val originalContext = LocalContext.current
    val sdkContext = remember(language) {
        originalContext.withSdkLocale(language)
    }
    val activityResultRegistryOwner = LocalActivityResultRegistryOwner.current
    val lifecycleOwner = LocalLifecycleOwner.current
    CompositionLocalProvider(
        LocalSdkColorScheme provides colorScheme,
        LocalLayoutDirection provides layoutDirection,
        LocalSdkTypography provides typography,
        LocalContext provides sdkContext,
        // Explicitly preserve these
        LocalActivityResultRegistryOwner provides activityResultRegistryOwner!!,
        LocalLifecycleOwner provides lifecycleOwner,
    ) {
        MaterialTheme(
            content = content,
            typography = Typography,
        )
    }
}

private fun buildSdkColorScheme(
    darkTheme: Boolean,
    theme: SDKTheme
): SdkColorScheme {
    val primaryOverride = theme.getPrimaryColorHex(darkTheme)
    val secondaryOverride = theme.getSecondaryColorHex(darkTheme)

    val baseScheme = if (darkTheme) DarkSdkColorScheme else LightSdkColorScheme

    return baseScheme.copy(
        primary = primaryOverride.toComposeColor(),
        secondary = secondaryOverride.toComposeColor()
    )
}