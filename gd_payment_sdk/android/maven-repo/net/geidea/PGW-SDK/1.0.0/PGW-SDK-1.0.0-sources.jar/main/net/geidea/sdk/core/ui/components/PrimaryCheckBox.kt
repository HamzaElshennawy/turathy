package net.geidea.sdk.core.ui.components

import androidx.annotation.StringRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme

@Composable
internal fun PrimaryCheckBox(
    @StringRes label: Int,
    isChecked: Boolean,
    modifier: Modifier = Modifier,
    size: Float = 18f,
    checkedColor: Color = SdkTheme.colors.primary,
    uncheckedColor: Color = SdkTheme.colors.surface,
    onValueChange: (Boolean) -> Unit
) {
    val density = LocalDensity.current

    val currentChecked by rememberUpdatedState(isChecked)
    val currentOnChange by rememberUpdatedState(onValueChange)


    val checkboxColor by animateColorAsState(
        targetValue = if (currentChecked) checkedColor else uncheckedColor,
        label = "checkboxColor"
    )

    val interactionSource = remember { MutableInteractionSource() }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.toggleable(
            value = currentChecked,
            role = Role.Checkbox,
            onValueChange = { currentOnChange(it) },
            indication = null,
            interactionSource = interactionSource
        )
    ) {
        Box(
            modifier = Modifier
                .size(size.dp)
                .background(
                    color = checkboxColor,
                    shape = RoundedCornerShape(dimensionResource(R.dimen.spacing_4))
                )
                .border(
                    width = 1.5.dp,
                    color = checkedColor,
                    shape = RoundedCornerShape(dimensionResource(R.dimen.spacing_4))
                ),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.animation.AnimatedVisibility(
                visible = currentChecked,
                enter = slideInHorizontally(animationSpec = tween(200)) {
                    with(density) { (size * -0.5).dp.roundToPx() }
                } + expandHorizontally(
                    expandFrom = Alignment.Start,
                    animationSpec = tween(200)
                ),
                exit = fadeOut()
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_check),
                    contentDescription = stringResource(R.string.ic_check),
                    modifier = Modifier.padding(horizontal = dimensionResource(R.dimen.spacing_1)),
                    tint = Color.Unspecified
                )
            }
        }

        Text(
            modifier = Modifier.padding(start = dimensionResource(R.dimen.spacing_8)),
            text = stringResource(label),
            style = SdkTheme.typography.medium14.copy(color = SdkTheme.colors.onPrimary)
        )
    }
}
