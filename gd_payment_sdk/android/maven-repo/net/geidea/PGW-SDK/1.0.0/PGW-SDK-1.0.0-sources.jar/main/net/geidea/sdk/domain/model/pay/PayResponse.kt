package net.geidea.sdk.domain.model.pay

import net.geidea.sdk.core.network.response.BaseResponse
import org.json.JSONObject

internal typealias PayResponse = BaseResponse<ThreeDSecureResponse>

internal data class ThreeDSecureResponse(
    internal val orderId: String? = null,
    internal val tokenId: String? = null,
    internal val agreementId: String? = null,
    internal val paymentMethod: PaymentMethodResponse? = null,
    internal val responseMessage: String? = null,
    internal val detailedResponseMessage: String? = null,
    internal val language: String? = null,
    internal val responseCode: String? = null,
    internal val detailedResponseCode: String? = null
)

internal data class PaymentMethodResponse(
    internal val type: String? = null,
    internal val brand: String? = null,
    internal val cardholderName: String? = null,
    internal val maskedCardNumber: String? = null,
    internal val wallet: String? = null,
    internal val expiryDate: ExpiryDateResponse? = null
)

internal data class ExpiryDateResponse(
    internal val month: Int? = null,
    internal val year: Int? = null
)


internal fun mapPayResponse(jsonString: String): ThreeDSecureResponse {
    val threeDSecureJSON = JSONObject(jsonString)

    val paymentMethodJson = threeDSecureJSON.optJSONObject("paymentMethod")
    val expiryDateJson = paymentMethodJson?.optJSONObject("expiryDate")

    val paymentMethod = paymentMethodJson?.let {
        PaymentMethodResponse(
            type = it.optString("type"),
            brand = it.optString("brand"),
            cardholderName = it.optString("cardholderName"),
            maskedCardNumber = it.optString("maskedCardNumber"),
            wallet = if (it.isNull("wallet")) null else it.optString("wallet"),
            expiryDate = expiryDateJson?.let { expiry ->
                ExpiryDateResponse(
                    month = expiry.optInt("month"),
                    year = expiry.optInt("year")
                )
            }
        )
    }

    return ThreeDSecureResponse(
        orderId = threeDSecureJSON.optString("orderId"),
        tokenId = threeDSecureJSON.optString("tokenId"),
        agreementId = threeDSecureJSON.optString("agreementId"),
        paymentMethod = paymentMethod,
        responseMessage = threeDSecureJSON.optString("responseMessage"),
        detailedResponseMessage = threeDSecureJSON.optString("detailedResponseMessage"),
        language = threeDSecureJSON.optString("language"),
        responseCode = threeDSecureJSON.optString("responseCode"),
        detailedResponseCode = threeDSecureJSON.optString("detailedResponseCode")
    )
}
