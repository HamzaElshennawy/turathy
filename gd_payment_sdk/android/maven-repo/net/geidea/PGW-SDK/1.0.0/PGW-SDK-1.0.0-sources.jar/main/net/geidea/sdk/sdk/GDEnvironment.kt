package net.geidea.sdk.sdk

interface GDEnvironment {
    fun getBaseUrl(region: REGION): String
}