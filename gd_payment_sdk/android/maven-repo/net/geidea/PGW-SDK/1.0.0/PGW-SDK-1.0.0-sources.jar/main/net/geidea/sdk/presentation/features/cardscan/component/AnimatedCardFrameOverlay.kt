package net.geidea.sdk.presentation.features.cardscan.component

import android.graphics.PathMeasure
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI

@Composable
internal fun AnimatedCardFrameOverlay(
    progress: Float,
    isAnimating: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val cardWidth = canvasWidth * 0.8f
        val cardHeight = cardWidth * 0.6f
        val cardLeft = (canvasWidth - cardWidth) / 2f
        val cardTop = (canvasHeight - cardHeight) / 2f
        val cornerRadius = 24f

        // Draw semi-transparent overlay
        drawRect(
            color = Color.Black.copy(alpha = 0.5f),
            size = size
        )

        // Cut out card area
        drawRoundRect(
            color = Color.Transparent,
            topLeft = Offset(cardLeft, cardTop),
            size = Size(cardWidth, cardHeight),
            cornerRadius = CornerRadius(cornerRadius, cornerRadius),
            blendMode = BlendMode.Clear
        )

        if (isAnimating) {
            drawAnimatedBorder(
                cardLeft = cardLeft,
                cardTop = cardTop,
                cardWidth = cardWidth,
                cardHeight = cardHeight,
                cornerRadius = cornerRadius,
                progress = progress
            )
        } else {
            // Draw static card frame
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(cardLeft, cardTop),
                size = Size(cardWidth, cardHeight),
                cornerRadius = CornerRadius(cornerRadius, cornerRadius),
                style = Stroke(width = 4f)
            )
        }
    }
}

private fun DrawScope.drawAnimatedBorder(
    cardLeft: Float,
    cardTop: Float,
    cardWidth: Float,
    cardHeight: Float,
    cornerRadius: Float,
    progress: Float
) {

    val strokeWidth = 6f
    val highlightLength = 150f // Length of the glowing highlight

    // Path for rounded rectangle
    val path = Path().apply {
        addRoundRect(
            RoundRect(
                left = cardLeft,
                top = cardTop,
                right = cardLeft + cardWidth,
                bottom = cardTop + cardHeight,
                cornerRadius = CornerRadius(cornerRadius, cornerRadius)
            )
        )
    }

    val perimeter = 2 * (cardWidth + cardHeight) - 8 * cornerRadius +
            2 * PI.toFloat() * cornerRadius

    val currentPosition = (perimeter - (progress * perimeter)) % perimeter
    val segmentStart = currentPosition
    val segmentEnd = (segmentStart + highlightLength).coerceAtMost(perimeter)

    val pathMeasure = PathMeasure()
    pathMeasure.setPath(path.asAndroidPath(), false)

    val segmentPath = Path()
    pathMeasure.getSegment(
        segmentStart,
        segmentEnd,
        segmentPath.asAndroidPath(),
        true
    )

    // Gradient for the highlight
    val brush = Brush.linearGradient(
        colors = listOf(
            Color.Green,
            Color.Green,
            Color.Yellow,
            Color.Transparent
        )
    )

    // Draw the moving highlight
    drawPath(
        path = segmentPath,
        brush = brush,
        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
    )

    // Draw static dimmed border
    drawPath(
        path = path,
        color = Color.White.copy(alpha = 0.3f),
        style = Stroke(width = 2f)
    )
}