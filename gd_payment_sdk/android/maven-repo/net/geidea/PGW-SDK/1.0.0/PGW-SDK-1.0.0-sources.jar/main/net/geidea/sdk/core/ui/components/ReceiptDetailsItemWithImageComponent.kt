package net.geidea.sdk.core.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme


@Composable
internal fun ReceiptItemComponentWithImages(
    iconUrl: String,
    itemTitle: String,
    quantity: String,
    price: String,
    currency: String = "",
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = dimensionResource(R.dimen.spacing_8)),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        if (!iconUrl.isEmpty()) {
            BaseAsyncImage(
                imageUrl = iconUrl,
                contentDescription = "",
                modifier = Modifier
                    .size(72.dp),
                contentScale = ContentScale.Crop,
            )
        } else {
            Icon(
                painter = painterResource(android.R.drawable.ic_menu_gallery),
                contentDescription = null,
                tint = Color.Unspecified
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = dimensionResource(R.dimen.spacing_16))
        ) {
            Text(
                text = itemTitle,
                style = SdkTheme.typography.semibold16,
                color = SdkTheme.colors.neutral700
            )
            Spacer(
                modifier = Modifier.height(dimensionResource(R.dimen.spacing_8))
            )
            Text(
                text = "${stringResource(R.string.quantity)} $quantity",
                style = SdkTheme.typography.regular14,
                color = SdkTheme.colors.neutral100
            )
        }

        Text(
            text = "$currency $price",
            style = SdkTheme.typography.medium14,
            color = SdkTheme.colors.neutral700
        )
    }
}
