package net.geidea.sdk.core.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf

internal val LocalSdkColorScheme = staticCompositionLocalOf { LightSdkColorScheme }
internal val LocalSdkTypography = staticCompositionLocalOf { GSdkTypography() }

internal object SdkTheme {
    internal val colors: SdkColorScheme
        @Composable get() = LocalSdkColorScheme.current
    internal val typography: GSdkTypography
        @Composable get() = LocalSdkTypography.current
}