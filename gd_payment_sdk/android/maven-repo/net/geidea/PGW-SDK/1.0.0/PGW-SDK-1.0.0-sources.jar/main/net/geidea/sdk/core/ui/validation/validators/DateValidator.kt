package net.geidea.sdk.core.ui.validation.validators

import net.geidea.sdk.R
import net.geidea.sdk.core.ui.validation.ValidationResult
import net.geidea.sdk.core.ui.validation.Validator
import net.geidea.sdk.core.utils.constants.Constants.Regex.DATE_VALIDATION_REGEX
import java.util.Calendar


internal class DateValidator : Validator {

    override fun validate(value: String): ValidationResult {
        val trimmed = value.trim()

        if (trimmed.isBlank()) {
            return ValidationResult(
                isValid = false,
                message = R.string.field_required
            )
        }

        val regex = Regex(DATE_VALIDATION_REGEX)
        if (!regex.matches(trimmed)) {
            return ValidationResult(
                isValid = false,
                message = R.string.invalid_date
            )
        }

        val (monthStr, yearStr) = trimmed.split("/")
        val month = monthStr.toInt()
        val year = 2000 + yearStr.toInt()

        val calendar = Calendar.getInstance()
        val nowYear = calendar.get(Calendar.YEAR)
        val nowMonth = calendar.get(Calendar.MONTH) + 1

        if (year < nowYear || (year == nowYear && month < nowMonth)) {
            return ValidationResult(
                isValid = false,
                message = R.string.expired_card
            )
        }

        return ValidationResult(isValid = true)
    }
}

