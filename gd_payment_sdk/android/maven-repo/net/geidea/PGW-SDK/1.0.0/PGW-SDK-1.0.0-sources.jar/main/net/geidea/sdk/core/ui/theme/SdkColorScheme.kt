package net.geidea.sdk.core.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.ui.graphics.Color
import net.geidea.sdk.core.utils.constants.Constants
import net.geidea.sdk.core.utils.extensions.toComposeColor

@Immutable
@Stable
internal data class SdkColorScheme(
    internal val primary: Color,
    internal val secondary: Color,
    internal val tertiary: Color,
    internal val onPrimary: Color,
    internal val neutral10: Color,
    internal val neutral20: Color,
    internal val neutral30: Color,
    internal val neutral80: Color,
    internal val neutral100: Color,
    internal val neutral300: Color,
    internal val neutral700: Color,
    internal val neutral900: Color,
    internal val danger700: Color,
    internal val surface: Color,
    internal val transparent: Color,
    internal val gradient1A: Color,
    internal val primaryBlue: Color,
    internal val alwaysWhite: Color,
    internal val isDark: Boolean,
)


internal val DarkSdkColorScheme = SdkColorScheme(
    primary = Constants.SDKDefaultColors.PRIMARY_DARK_HEX.toComposeColor(),
    secondary = Constants.SDKDefaultColors.SECONDARY_DARK_HEX.toComposeColor(),
    tertiary = White,
    onPrimary = White,
    neutral10 = Grey10,
    neutral20 = Grey20,
    neutral30 = Grey30,
    neutral80 = Grey80,
    neutral100 = Grey100,
    neutral300 = Black300,
    neutral700 = Black700,
    neutral900 = Black900,
    danger700 = Red700,
    surface = Black900,
    transparent = Color.Transparent,
    gradient1A = Gradient1A,
    primaryBlue = PrimaryBlue,
    alwaysWhite = White,
    isDark = true
)

internal val LightSdkColorScheme = SdkColorScheme(
    primary = Constants.SDKDefaultColors.PRIMARY_HEX.toComposeColor(),
    secondary = Constants.SDKDefaultColors.SECONDARY_HEX.toComposeColor(),
    tertiary = Grey80,
    onPrimary = Black900,
    neutral10 = Grey10,
    neutral20 = Grey20,
    neutral30 = Grey30,
    neutral80 = Grey80,
    neutral100 = Grey100,
    neutral300 = Black300,
    neutral700 = Black700,
    danger700 = Red700,
    surface = White,
    transparent = Color.Transparent,
    neutral900 = Black900,
    gradient1A = Gradient1A,
    primaryBlue = PrimaryBlue,
    alwaysWhite = White,
    isDark = false
)