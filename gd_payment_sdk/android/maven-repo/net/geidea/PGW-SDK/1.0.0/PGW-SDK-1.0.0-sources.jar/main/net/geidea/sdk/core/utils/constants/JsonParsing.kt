package net.geidea.sdk.core.utils.constants

import org.json.JSONObject


internal fun safeJson(jsonString: String?): JSONObject {
    return try {
        if (jsonString.isNullOrBlank()) JSONObject() else JSONObject(jsonString)
    } catch (e: Exception) {
        JSONObject()
    }
}
