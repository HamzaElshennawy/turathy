package net.geidea.sdk.core.utils.extensions

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.toColorInt


// Convert hex string to Compose Color
internal fun String.toComposeColor(): Color {
    return try {
        Color(this.toColorInt())
    } catch (e: Exception) {
        // Return a fallback color if parsing fails
        Color.Red
    }
}

// Convert Color to hex string
internal fun Color.toHexString(): String {
    return String.format("#%08X", this.toArgb())
}