package net.geidea.sdk.core.ui.validation

internal interface Validator {
    fun validate(value: String): ValidationResult
}