package net.geidea.sdk.core.network.client


internal enum class HttpMethod { GET, POST, PUT, DELETE, PATCH }
