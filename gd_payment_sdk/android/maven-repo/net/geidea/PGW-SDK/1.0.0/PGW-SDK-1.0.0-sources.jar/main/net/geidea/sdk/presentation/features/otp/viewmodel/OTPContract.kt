package net.geidea.sdk.presentation.features.otp.viewmodel

import net.geidea.sdk.core.mvi.BaseEffect
import net.geidea.sdk.core.mvi.ErrorEvent
import net.geidea.sdk.core.mvi.ViewEvent
import net.geidea.sdk.core.mvi.ViewState
import net.geidea.sdk.domain.model.pay.PerformAuthenticateResponse
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.CardUiModel

internal data class OTPState(
    override val isLoading: Boolean = false,
    override val errorEvent: ErrorEvent? = null,
    override val isFullScreenError: Boolean = false,
    override val isOverlayError: Boolean = false,
    internal val authResponse: PerformAuthenticateResponse? = null,
    internal val cardDetails: CardUiModel? = null,
    internal val orderId: String? = null,
    internal val webViewProgress: Int = 0,
    internal val showProgressBar: Boolean = false,
    internal val paymentSucceeded: Boolean = false
) : ViewState

internal sealed class OTPEvent : ViewEvent {
    internal data class OnReturnUrl(internal val url: String) : OTPEvent()
    internal data class OnProgressChanged(internal val progress: Int) : OTPEvent()
    internal data object OnPageStarted : OTPEvent()
    internal data object OnPageFinished : OTPEvent()
    internal data class OnWebError(internal val error: String) : OTPEvent()
    internal data object OnBackPressed : OTPEvent()
    internal data class OnScreenInit(
        internal val authResponse: PerformAuthenticateResponse? = null,
        internal val cardDetails: CardUiModel? = null
    ) : OTPEvent()
}

internal sealed class OTPEffect : BaseEffect {
    internal data class NavigateBack(internal val orderId: String? = null) : OTPEffect()
    internal data class SetPaymentSuccess(internal val orderId: String) : OTPEffect()
    internal data object NavigateBackToPay : OTPEffect()
}