package net.geidea.sdk.internal

import net.geidea.sdk.sdk.GDEnvironment
import net.geidea.sdk.sdk.REGION

internal class GSDKEnvironment : GDEnvironment {
    override fun getBaseUrl(region: REGION): String {
        return when (region) {
            REGION.EGY -> SDKEnvironment.EgyptProd.baseUrl
            REGION.KSA -> SDKEnvironment.KsaProd.baseUrl
            REGION.UAE -> SDKEnvironment.UaeProd.baseUrl
        }
    }
}