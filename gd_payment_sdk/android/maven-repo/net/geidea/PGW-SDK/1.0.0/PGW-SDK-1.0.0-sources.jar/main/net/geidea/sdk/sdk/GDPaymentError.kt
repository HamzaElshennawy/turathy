package net.geidea.sdk.sdk

data class GDPaymentError(
    val code: String,
    val message: String,
    val details: String? = null
)