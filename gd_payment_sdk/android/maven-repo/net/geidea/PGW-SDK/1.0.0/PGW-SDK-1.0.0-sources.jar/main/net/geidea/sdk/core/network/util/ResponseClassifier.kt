package net.geidea.sdk.core.network.util

//import net.geidea.sdk.domain.model.paymentdetails.safeJson
//import org.json.JSONObject
//
//
//internal interface ResponseClassifier {
//    fun classify(httpCode: Int, body: String?): Classification
//}
//
//internal sealed class Classification {
//    internal data object Success : Classification()
//    internal data class DomainError(val apiError: ApiError) : Classification()
//}
//
//internal object DefaultResponseClassifier : ResponseClassifier {
//    override fun classify(httpCode: Int, body: String?): Classification {
//        return when (httpCode) {
//            in 200..299 -> {
//                if (body.isNullOrBlank()) Classification.Success
//                else {
//                    val json = safeJson(body)
//                    if (json.optString("responseCode") == "000") {
//                        Classification.Success
//                    } else {
//                        Classification.DomainError(ApiError.fromJson(json))
//                    }
//                }
//            }
//
//            in 400..499 -> Classification.DomainError(ApiError(rawBody = body.orEmpty()))
//            in 500..599 -> Classification.DomainError(ApiError(rawBody = body.orEmpty()))
//            else -> Classification.DomainError(ApiError(rawBody = body.orEmpty()))
//        }
//    }
//}
//
//internal data class ApiError(
//    val responseCode: String = "",
//    val responseMessage: String = "",
//    val detailedResponseCode: String = "",
//    val detailedResponseMessage: String = "",
//    val rawBody: String = ""
//) {
//    companion object {
//        fun fromJson(json: JSONObject): ApiError {
//            return try {
//                ApiError(
//                    responseCode = json.optString("responseCode", ""),
//                    responseMessage = json.optString("responseMessage", ""),
//                    detailedResponseCode = json.optString("detailedResponseCode", ""),
//                    detailedResponseMessage = json.optString("detailedResponseMessage", ""),
//                    rawBody = json.toString()
//                )
//            } catch (e: Exception) {
//                ApiError(rawBody = json.toString())
//            }
//        }
//    }
//}