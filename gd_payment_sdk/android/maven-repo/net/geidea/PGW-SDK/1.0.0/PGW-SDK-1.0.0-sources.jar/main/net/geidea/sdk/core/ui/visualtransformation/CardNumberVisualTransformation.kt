package net.geidea.sdk.core.ui.visualtransformation


import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import net.geidea.sdk.core.utils.constants.Constants.Regex.CARD_NUMBER_GROUP_LENGTH
import net.geidea.sdk.core.utils.constants.Constants.Regex.CARD_NUMBER_LENGTH

internal class CardNumberVisualTransformation : VisualTransformation {

    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text.filter { it.isDigit() }.take(CARD_NUMBER_LENGTH)

        val grouped = raw.chunked(CARD_NUMBER_GROUP_LENGTH).joinToString(" ")

        val formatted = "\u200E$grouped"

        val offsetMapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                val spacesBefore = (0 until offset).count {
                    (it + 1) % CARD_NUMBER_GROUP_LENGTH == 0 && it + 1 < raw.length
                }
                return offset + spacesBefore + 1
            }

            override fun transformedToOriginal(offset: Int): Int {
                val adjusted = (offset - 1).coerceAtLeast(0)
                val spacesBefore = (0 until raw.length).count {
                    (it + 1) % CARD_NUMBER_GROUP_LENGTH == 0 &&
                            it + 1 < raw.length &&
                            (it + 1 + it / CARD_NUMBER_GROUP_LENGTH) < adjusted
                }
                return (adjusted - spacesBefore).coerceAtLeast(0).coerceAtMost(raw.length)
            }
        }

        return TransformedText(AnnotatedString(formatted), offsetMapping)
    }
}