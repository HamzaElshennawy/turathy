package net.geidea.sdk.presentation.features.cardscan.viewmodel

import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import net.geidea.sdk.core.mvi.BaseViewModel
import net.geidea.sdk.core.mvi.ViewEvent
import net.geidea.sdk.presentation.features.cardscan.ScannedCardData
import net.geidea.sdk.presentation.features.cardscan.ScannedCardResult

internal class CardScanViewModel : BaseViewModel<CardScanState, CardScanEvent, CardScanEffect>() {
    override fun createInitialState(): CardScanState = CardScanState()

    private var animationJob: Job? = null


    override fun handleEvent(event: ViewEvent) {
        when (event) {
            is CardScanEvent.StartScanning -> startScanning()
            is CardScanEvent.StopScanning -> stopScanning()
            is CardScanEvent.ToggleFlashOn -> toggleFlash()
            is CardScanEvent.ToggleFlashOff -> toggleFlash()
            is CardScanEvent.RequestCameraPermission -> requestPermission()
            is CardScanEvent.DismissPermissionRationale -> dismissPermissionRationale()
            is CardScanEvent.AcceptRationalDialog -> acceptRationalDialog()
            is CardScanEvent.OnReturnFromAppSetting -> backFromSettings(event.granted)
            is CardScanEvent.CardDetected -> handleCardDetected(event.cardData)
            is CardScanEvent.PermissionResult -> handlePermissionResult(event.granted)
            is CardScanEvent.ProcessingStateChanged -> updateProcessingState(event.isProcessing)
            is CardScanEvent.Close -> close()
        }
    }

    private fun startScanning() {
        setState {
            copy(
                isScanning = true,
                isAnimating = true,
                errorEvent = null,
                hasScannedCard = false
            )
        }
        startBorderAnimation()
    }

    private fun stopScanning() {
        setState {
            copy(
                isScanning = false,
                isAnimating = false
            )
        }
        animationJob?.cancel()
    }


    private fun requestPermission() {
        emitEffect(CardScanEffect.RequestPermission)
    }

    private fun handlePermissionResult(granted: Boolean) {
        setState {
            copy(
                hasPermission = granted,
                showPermissionRationale = !granted
            )
        }
        if (granted) {
            sendEvent(CardScanEvent.StartScanning)
        }
    }

    private fun dismissPermissionRationale() {
        setState {
            copy(showPermissionRationale = false)
        }
        close()
    }

    private fun handleCardDetected(cardData: ScannedCardData) {
        // Prevent processing multiple scans
        if (state.value.hasScannedCard) return

        try {
            if (cardData.isValid && cardData.confidence > 0.6f) {


                setState {
                    copy(
                        scannedCard = cardData,
                        isScanning = false,
                        isAnimating = false,
                        isProcessing = false,
                        hasScannedCard = true
                    )
                }

                animationJob?.cancel()

                // Add a small delay to show success before closing
                viewModelScope.launch {
                    delay(500)
                    emitEffect(
                        CardScanEffect.CardScanned(
                            ScannedCardResult(success = true, cardData = cardData)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateProcessingState(isProcessing: Boolean) {
        setState {
            copy(isProcessing = isProcessing)
        }
    }

    private fun startBorderAnimation() {
        animationJob?.cancel()
        animationJob = viewModelScope.launch {
            while (state.value.isAnimating) {
                try {
                    for (progress in 0..100) {
                        if (!state.value.isAnimating) break
                        setState {
                            copy(animationProgress = progress / 100f)
                        }
                        delay(20) // 50 FPS animation
                    }
                    if (state.value.isAnimating) {
                        setState {
                            copy(animationProgress = 0f)
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    break
                }
            }
        }
    }


    private fun toggleFlash() {
        setState {
            copy(isFlashOn = !isFlashOn)
        }
    }

    private fun close() {
        stopScanning()
        emitEffect(CardScanEffect.Close)
    }

    private fun acceptRationalDialog() {
        emitEffect(CardScanEffect.NavigateToAppSetting)
    }

    private fun backFromSettings(isPermissionGranted: Boolean) {
        if (isPermissionGranted) {
            startScanning()
            setState {
                copy(
                    showPermissionRationale = false,
                    hasPermission = true
                )
            }

        }
    }

    override fun onCleared() {
        super.onCleared()
        animationJob?.cancel()
    }

}