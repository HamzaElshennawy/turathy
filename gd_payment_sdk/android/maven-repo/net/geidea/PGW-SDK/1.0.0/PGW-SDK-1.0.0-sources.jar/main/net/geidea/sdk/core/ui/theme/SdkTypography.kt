package net.geidea.sdk.core.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

@Immutable
@Stable
internal data class GSdkTypography(
    internal val bold32: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.Bold, fontSize = 32.sp
    ),
    internal val bold24: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.Bold, fontSize = 24.sp
    ),
    internal val bold20: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.Bold, fontSize = 20.sp
    ),
    internal val bold14: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.Bold, fontSize = 14.sp
    ),
    internal val semibold18: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.SemiBold, fontSize = 18.sp
    ),
    internal val semibold16: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.SemiBold, fontSize = 16.sp
    ),
    internal val medium16: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.Medium, fontSize = 16.sp
    ),
    internal val medium14: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.Medium, fontSize = 14.sp
    ),
    internal val medium12: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.Medium, fontSize = 12.sp
    ),
    internal val regular14: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.Normal, fontSize = 14.sp
    ),
    internal val regular12: TextStyle = TextStyle(
        fontFamily = SDKFont.getFont(), fontWeight = FontWeight.Normal, fontSize = 12.sp
    ),
)