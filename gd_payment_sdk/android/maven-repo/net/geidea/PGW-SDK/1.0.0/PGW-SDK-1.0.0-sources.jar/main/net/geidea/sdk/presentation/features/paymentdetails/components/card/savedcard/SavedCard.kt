package net.geidea.sdk.presentation.features.paymentdetails.components.card.savedcard

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.components.ErrorText
import net.geidea.sdk.core.ui.components.PrimaryTextField
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.ui.validation.FieldValidationTrigger
import net.geidea.sdk.core.utils.extensions.cardItemBorder
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.CardUiModel


internal fun LazyListScope.savedCardsSection(
    state: SavedCardsState,
    onEvent: (SavedCardEvent) -> Unit
) {
    if (state.cards.isNotEmpty()) {
        item(key = "savedCardHeader") {
            SectionHeader(text = stringResource(R.string.saved_card))
        }

        itemsIndexed(
            state.cards,
            key = { _, card -> card.id }
        ) { _, card ->
            CardSelectionItem(
                card = card,
                isSelected = state.isSelected(card.id),
                onCardSelected = remember(card, state.selectedCard) {
                    { selectedCard ->
                        if (!state.isSelected(selectedCard.id)) {
                            onEvent(SavedCardEvent.CardSelected(selectedCard))
                        }
                    }
                },
                onCvvChange = remember(card, state.selectedCard) {
                    { cardId: String, cvv: String ->
                        onEvent(SavedCardEvent.CVVChanged(cardId, cvv))
                    }
                },
                modifier = Modifier
                    .padding(
                        top = dimensionResource(R.dimen.spacing_16),
                        start = dimensionResource(R.dimen.spacing_16),
                        end = dimensionResource(R.dimen.spacing_16)
                    )
                    .fillMaxWidth(),
                showCvvError = state.showCardSelectionError && state.isSelected(card.id)
            )
        }

        if (state.showCardSelectionError && state.showAddNewCardRow) {
            item(key = "error_card") {
                ErrorText(errorMessageRes = R.string.field_required)
            }
        }

        if (state.showAddNewCardRow) {
            item(key = "addNewCardRow") {
                AddNewCardRow(
                    onClick = remember { { onEvent(SavedCardEvent.AddNewCard) } }
                )
            }
        }
    }
}


@Composable
private fun CardSelectionItem(
    modifier: Modifier = Modifier,
    card: CardUiModel,
    isSelected: Boolean,
    onCardSelected: (CardUiModel) -> Unit,
    onCvvChange: (cardId: String, cvv: String) -> Unit,
    showCvvError: Boolean = false
) {
    val animatedWeight by animateFloatAsState(
        targetValue = if (isSelected) 0.3f else 0.0001f,
        animationSpec = tween(durationMillis = 300),
        label = "cvvWeight"
    )

    val isError = !card.cvv.validation.isValid || (showCvvError && isSelected)
    Column {
        Row(
            modifier = modifier
                .animateContentSize()
                .fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            // Card Info Section
            Row(
                modifier = Modifier
                    .weight(0.7f)
                    .height(dimensionResource(R.dimen.primary_textfield_height))
                    .clickable { onCardSelected(card) }
                    .cardItemBorder(if (isError) SdkTheme.colors.danger700 else SdkTheme.colors.neutral20)
                    .padding(horizontal = dimensionResource(R.dimen.spacing_20)),
                verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = isSelected,
                    onClick = { onCardSelected(card) },
                    modifier = Modifier.size(dimensionResource(R.dimen.spacing_16)),
                    colors = RadioButtonDefaults.colors(
                        selectedColor = SdkTheme.colors.primary,
                        unselectedColor = SdkTheme.colors.neutral30
                    )
                )

                Box(
                    modifier = Modifier
                        .padding(start = dimensionResource(R.dimen.spacing_16))
                        .cardItemBorder()
                        .padding(dimensionResource(R.dimen.spacing_10))
                ) {
                    Icon(
                        painter = painterResource(id = card.iconResId ?: R.drawable.ic_master),
                        contentDescription = null,
                        modifier = Modifier.wrapContentSize(),
                        tint = Color.Unspecified
                    )
                }

                Text(
                    modifier = Modifier
                        .padding(start = dimensionResource(R.dimen.spacing_10))
                        .weight(1f),
                    text = card.cardNumber.value,
                    style = SdkTheme.typography.medium14.copy(color = SdkTheme.colors.onPrimary)
                )
            }

            // CVV Field Section
            if (isSelected) {
                PrimaryTextField(
                    modifier = Modifier
                        .weight(animatedWeight)
                        .padding(start = dimensionResource(R.dimen.spacing_16)),
                    label = R.string.cvv,
                    value = card.cvv.value,
                    isError = card.cvv.let { !it.validation.isValid },
                    onValueChange = { input ->
                        val sanitized = input.filter { it.isDigit() }.take(3)
                        onCvvChange(card.id, sanitized)
                    },
                    visualTransformation = PasswordVisualTransformation(),
                    validationTrigger = FieldValidationTrigger.ON_FOCUS_LOST,
                )
            }
        }

        if (isError) {
            ErrorText(errorMessageRes = card.cvv.validation.message ?: R.string.field_required)
        }
    }
}


@Composable
private fun SectionHeader(text: String) {
    Text(
        modifier = Modifier.padding(top = dimensionResource(R.dimen.spacing_24)),
        text = text,
        style = SdkTheme.typography.semibold16.copy(color = SdkTheme.colors.onPrimary)
    )
}

@Composable
private fun AddNewCardRow(onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .padding(top = dimensionResource(R.dimen.spacing_16))
            .clickable(onClick = onClick)
    ) {
        Icon(
            painter = painterResource(id = R.drawable.ic_add),
            contentDescription = stringResource(R.string.add_new_card),
            tint = SdkTheme.colors.primary
        )

        Text(
            modifier = Modifier.padding(start = dimensionResource(R.dimen.spacing_10)),
            text = stringResource(R.string.add_new_card),
            style = SdkTheme.typography.semibold16.copy(color = SdkTheme.colors.onPrimary)
        )
    }
}
