package net.geidea.sdk.presentation.features.cardscan.screen

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import net.geidea.sdk.presentation.features.cardscan.ScannedCardData
import net.geidea.sdk.presentation.features.cardscan.logic.ProductionCardRecognizer

internal class ComposeCardScanFlow(
    private val context: Context,
    private val errorListener: (Throwable) -> Unit
) {
    private var canceled = false
    private val recognizer = ProductionCardRecognizer()

    fun start(
        imageStream: Flow<Bitmap>,
        scope: CoroutineScope,
        onResult: (ScannedCardData) -> Unit
    ): Job {
        canceled = false
        return scope.launch {
            imageStream.collect { bitmap ->
                if (canceled) return@collect
                try {
                    val result = recognizer.extractCardData(bitmap)
                    if (result.isValid) onResult(result)
                } catch (e: Exception) {
                    errorListener(e)
                }
            }
        }
    }

    fun cancel() {
        canceled = true
    }

    fun reset() {
        canceled = false
    }
}