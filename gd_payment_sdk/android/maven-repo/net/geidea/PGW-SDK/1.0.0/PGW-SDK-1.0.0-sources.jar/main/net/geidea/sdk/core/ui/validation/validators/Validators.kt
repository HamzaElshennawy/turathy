package net.geidea.sdk.core.ui.validation.validators

import net.geidea.sdk.core.di.inject
import net.geidea.sdk.core.ui.validation.Validator


internal data class PaymentValidators(
    internal val name: Validator = inject<NameValidator>(),
    internal val cvv: Validator = inject<CvvValidator>(),
    internal val cardNumber: Validator = inject<CardNumberValidator>(),
    internal val date: Validator = inject<DateValidator>(),
)

