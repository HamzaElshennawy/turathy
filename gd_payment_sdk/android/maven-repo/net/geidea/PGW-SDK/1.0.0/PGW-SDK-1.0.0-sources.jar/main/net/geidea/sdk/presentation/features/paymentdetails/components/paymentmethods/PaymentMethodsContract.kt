package net.geidea.sdk.presentation.features.paymentdetails.components.paymentmethods

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import net.geidea.sdk.domain.model.paymentdetails.PaymentMethod
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent


@Immutable
@Stable
internal data class PaymentMethodsState(
    internal val paymentMethods: List<PaymentMethod> = emptyList(),
    internal val selectedMethod: PaymentMethod? = null
)

internal sealed interface PaymentMethodsEvent : PaymentEvent {
    data class OnMethodSelected(internal val method: PaymentMethod) : PaymentMethodsEvent
}
