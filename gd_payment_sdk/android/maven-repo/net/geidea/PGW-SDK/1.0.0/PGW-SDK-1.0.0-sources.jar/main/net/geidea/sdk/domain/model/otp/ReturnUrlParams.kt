package net.geidea.sdk.domain.model.otp

internal data class ReturnUrlParams(
    internal val code: String?,
    internal val msg: String?,
    internal val orderId: String?
) {
    internal val isSuccess: Boolean get() = code.equals(CODE_SUCCESS, ignoreCase = true)

    internal companion object {
        internal const val RETURN_URL = "geidea://payment/return"
        private const val CODE_SUCCESS = "000"
    }
}