package net.geidea.sdk.core.ui


import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import net.geidea.sdk.R
import net.geidea.sdk.core.mvi.BaseEffect
import net.geidea.sdk.core.mvi.BaseViewModel
import net.geidea.sdk.core.mvi.ErrorEvent
import net.geidea.sdk.core.mvi.ViewEvent
import net.geidea.sdk.core.mvi.ViewState
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.utils.extensions.withSdkLocale
import net.geidea.sdk.sdk.GDPaymentSDK
import net.geidea.sdk.sdk.SDKLanguage

@Composable
internal fun <STATE : ViewState> BaseScreen(
    viewModel: BaseViewModel<STATE, out ViewEvent, out BaseEffect>,
    modifier: Modifier = Modifier,
    applyStatusBarPadding: Boolean = true,
    applyNavigationBarPadding: Boolean = true,
    onEffect: (BaseEffect) -> Unit = {},
    loadingContent: @Composable () -> Unit = { DefaultLoadingScreen() },
    content: @Composable (STATE) -> Unit,
    fullScreenDismiss: (() -> Unit)? = null,
    overlayDismiss: (() -> Unit)? = null,
    errorDialog: @Composable (title: String?, message: String?, onDismiss: () -> Unit) -> Unit = { title, message, onDismiss ->
        DefaultErrorDialog(title, message, onDismiss)
    }
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(viewModel) {
        viewModel.effect.collect { effect -> onEffect(effect) }
    }

    val systemBarModifier = modifier
        .fillMaxSize()
        .then(if (applyStatusBarPadding) Modifier.statusBarsPadding() else Modifier)
        .then(if (applyNavigationBarPadding) Modifier.navigationBarsPadding() else Modifier)

    Box(modifier = systemBarModifier) {

        val showContent = !(state.isLoading || state.isFullScreenError)
        if (showContent) content(state)

        if (state.isLoading) loadingContent()

        state.errorEvent?.let { error ->
            val title: String? = when (error) {
                is ErrorEvent.BusinessError -> error.responseMessage
                    ?: stringResource(R.string.general_error_title)

                is ErrorEvent.Unauthorized -> error.responseMessage
                    ?: stringResource(R.string.general_error_title)

                is ErrorEvent.Forbidden -> stringResource(R.string.forbidden_error)
                is ErrorEvent.NotFound -> stringResource(R.string.not_found_error)
                is ErrorEvent.HttpError -> stringResource(R.string.general_error_title)
                is ErrorEvent.GeneralError -> stringResource(R.string.general_error_title)
            }

            val message = when (error) {
                is ErrorEvent.BusinessError -> error.detailedResponseMessage
                    ?: stringResource(R.string.general_error)

                is ErrorEvent.Unauthorized -> error.detailedResponseMessage
                    ?: stringResource(R.string.unauthorized_error)

                else -> stringResource(R.string.general_error)
            }

            val onDismiss = {
                when {
                    state.isFullScreenError -> {
                        viewModel.sendEvent(ViewEvent.ClearError)
                        val error = state.errorEvent
                        if (error is ErrorEvent.BusinessError && error.code == "210") {
                            GDPaymentSDK.sharedInstance().closeSDK()
                        } else {

                            fullScreenDismiss?.invoke()
                        }
                    }

                    state.isOverlayError -> {
                        val error = state.errorEvent
                        viewModel.sendEvent(ViewEvent.ClearOvelayError)

                        if (error is ErrorEvent.BusinessError && error.code == "210") {
                            GDPaymentSDK.sharedInstance().closeSDK()

                        } else {

                            overlayDismiss?.invoke()

                        }
                    }
                }
            }


            errorDialog(title, message, onDismiss)
        }
    }
}


@Composable
internal fun DefaultErrorDialog(
    title: String? = null,
    message: String? = null,
    onDismiss: () -> Unit,
    language: SDKLanguage = GDPaymentSDK.sharedInstance().getConfigurations().language,
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        )
    ) {
        val localizedContext = LocalContext.current.withSdkLocale(language)
        CompositionLocalProvider(
            LocalContext provides localizedContext,
        ) {
            Surface(
                modifier = Modifier
                    .width(320.dp)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(14.dp),
                color = SdkTheme.colors.surface,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    // Header with title and icon
                    if (title != null) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = title,
                                    style = TextStyle(
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF2C2C2C),
                                        letterSpacing = (-0.2).sp
                                    ),
                                    modifier = Modifier.weight(1f)
                                )

                                // Error icon
                                Image(
                                    painter = painterResource(id = R.drawable.ic_error),
                                    contentDescription = null,
                                    modifier = Modifier.scale(1.0f)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Divider
                            HorizontalDivider(
                                thickness = 1.dp,
                                color = Color(0xFFE0E0E0)
                            )

                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }

                    // Message
                    Text(
                        text = message.orEmpty(),
                        style = TextStyle(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color(0xFF4A4A4A),
                            lineHeight = 20.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Button aligned to the right
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        Surface(
                            modifier = Modifier
                                .widthIn(min = 80.dp)
                                .height(36.dp)
                                .clickable(
                                    onClick = onDismiss,
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() }
                                ),
                            shape = RoundedCornerShape(18.dp),
                            color = Color.Transparent,
                            border = BorderStroke(1.5.dp, Color(0xFF3C3C3C))
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            ) {
                                Text(
                                    text = stringResource(R.string.close),
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF2C2C2C)
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

    }
}

@Composable
internal fun DefaultLoadingScreen() {
    Dialog(onDismissRequest = { }) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 8.dp,
            color = MaterialTheme.colorScheme.surface,
        ) {
            Box(
                modifier = Modifier
                    .padding(24.dp)
                    .wrapContentSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = SdkTheme.colors.primary)
            }
        }
    }
}
