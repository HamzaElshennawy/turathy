package net.geidea.sdk.presentation.features.paymentdetails.components.card.carddetails


import net.geidea.sdk.core.ui.models.TextFieldInput
import net.geidea.sdk.core.ui.models.updateTextField
import net.geidea.sdk.core.ui.validation.validators.PaymentValidators
import net.geidea.sdk.core.utils.extensions.updateIfChanged
import net.geidea.sdk.domain.model.paymentdetails.SupportedCard
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.CardUiModel
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent


internal fun reduceCardDetailsState(
    state: CardUiModel,
    event: PaymentEvent,
    paymentValidators: PaymentValidators
) = when (event) {

    is CardDetailsEvent.CardNumberChanged -> updateIfChanged(
        state,
        state.cardNumber.value,
        event.value,
        paymentValidators.cardNumber
    ) {
        state.copy(
            cardNumber = TextFieldInput(event.value, it),
            possibleBrand = detectCardBrand(event.value, state.supportedCards)
        )
    }

    is CardDetailsEvent.ExpiryDateChanged -> updateIfChanged(
        state,
        state.expiryDate.value,
        event.value,
        paymentValidators.date
    ) {
        val parts = event.value.split("/")
        val parsedMonth = parts.getOrNull(0)?.toIntOrNull()?.takeIf { it in 1..12 }
        val parsedYear = parts.getOrNull(1)?.toIntOrNull()?.let { yearPart ->
            when {
                yearPart < 100 -> 2000 + yearPart
                else -> yearPart
            }
        }

        copy(
            expiryDate = TextFieldInput(event.value, it),
            month = parsedMonth ?: 0,
            year = parsedYear ?: 0
        )
    }

    is CardDetailsEvent.CvvChanged -> updateIfChanged(
        state,
        state.cvv.value,
        event.value,
        paymentValidators.cvv
    ) {
        copy(cvv = TextFieldInput(event.value, it))
    }

    is CardDetailsEvent.CardNameChanged -> updateIfChanged(
        state,
        state.nameOnCard.value,
        event.value,
        paymentValidators.name
    ) {
        copy(nameOnCard = TextFieldInput(event.value, it))
    }

    is CardDetailsEvent.CardSavedChanged -> updateIfChanged(
        state,
        state.isCardSaved,
        event.isCardSaved
    ) {
        copy(isCardSaved = event.isCardSaved)
    }

    is CardDetailsEvent.ShowDatePickerChanged -> updateIfChanged(
        state, state.showDatePicker, event.show
    ) {
        copy(showDatePicker = event.show)
    }

    is CardDetailsEvent.ValidateAllFields -> {
        val cardNumber = updateTextField(state.cardNumber.value, paymentValidators.cardNumber)
        val expiryDate = updateTextField(state.expiryDate.value, paymentValidators.date)
        val cvv = updateTextField(state.cvv.value, paymentValidators.cvv)
        val nameOnCard = updateTextField(state.nameOnCard.value, paymentValidators.name)

        if (cardNumber == state.cardNumber && expiryDate == state.expiryDate && cvv == state.cvv && nameOnCard == state.nameOnCard) {
            state
        } else {
            state.copy(
                cardNumber = cardNumber, expiryDate = expiryDate, cvv = cvv, nameOnCard = nameOnCard
            )
        }
    }

    is CardDetailsEvent.CardScanned -> {
        state.copy(
            cardNumber = updateTextField(event.cardData.cardNumber, paymentValidators.cardNumber),
            expiryDate = updateTextField(event.cardData.expiryDate, paymentValidators.date),
            nameOnCard = updateTextField(event.cardData.cardHolderName, paymentValidators.name)
        )
    }

    else -> state
}

private fun detectCardBrand(
    cardNumber: String,
    supportedCards: List<SupportedCard> = listOf(),
): SupportedCard? {
    val trimmed = cardNumber.replace(" ", "") // remove spaces
    val matches = supportedCards.filter { card ->
        card.regex?.toRegex()?.matches(trimmed) == true ||
                card.regex?.toRegex()?.containsMatchIn(trimmed) == true
    }

    return if (matches.isNotEmpty()) {
        matches.first()
    } else {
        null // either none or multiple matches → wait for more digits
    }
}