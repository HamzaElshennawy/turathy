package net.geidea.sdk.core.network.client

import kotlinx.coroutines.flow.Flow
import net.geidea.sdk.core.network.response.BaseResponse
import org.json.JSONObject

internal interface NetworkClient {
    fun <T> getAsFlow(
        url: String,
        queryParams: Map<String, String> = emptyMap(),
        headers: Map<String, String> = emptyMap(),
        mapper: (String) -> T
    ): Flow<BaseResponse<T>>

    fun <T> postAsFlow(
        url: String,
        body: JSONObject? = null,
        headers: Map<String, String> = emptyMap(),
        mapper: (String) -> T
    ): Flow<BaseResponse<T>>

    fun <T> putAsFlow(
        url: String,
        body: JSONObject? = null,
        headers: Map<String, String> = emptyMap(),
        mapper: (String) -> T
    ): Flow<BaseResponse<T>>

    fun <T> patchAsFlow(
        url: String,
        body: JSONObject? = null,
        headers: Map<String, String> = emptyMap(),
        mapper: (String) -> T
    ): Flow<BaseResponse<T>>

    fun <T> deleteAsFlow(
        url: String,
        queryParams: Map<String, String> = emptyMap(),
        headers: Map<String, String> = emptyMap(),
        mapper: (String) -> T
    ): Flow<BaseResponse<T>>
}