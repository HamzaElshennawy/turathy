package net.geidea.sdk.core.network.client

import android.os.Build
import net.geidea.sdk.BuildConfig

internal interface BaseHeadersProvider {
    fun getBaseHeaders(language: String): Map<String, String>
}

internal object DefaultBaseHeadersProvider : BaseHeadersProvider {
    override fun getBaseHeaders(language: String): Map<String, String> = mapOf(
        "Content-Type" to "application/json;charset=UTF-8",
        "accept" to "*/*",
        "language" to language,
        "deviceType" to Build.MANUFACTURER,
        "deviceModel" to Build.MODEL,
        "deviceBrand" to Build.BRAND,
        "sdkVersion" to BuildConfig.SDK_VERSION,
        "OSVersion" to Build.VERSION.RELEASE
    )
}
