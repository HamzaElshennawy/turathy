package net.geidea.sdk.core.utils.extensions

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
internal fun Modifier.conditional(
    condition: Boolean,
    modifier: @Composable Modifier.() -> Modifier
) = if (condition) {
    then(modifier(Modifier))
} else {
    this
}
