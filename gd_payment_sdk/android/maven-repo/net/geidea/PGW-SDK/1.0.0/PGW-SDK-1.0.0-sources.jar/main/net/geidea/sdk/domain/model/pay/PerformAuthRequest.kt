package net.geidea.sdk.domain.model.pay

import net.geidea.sdk.domain.model.otp.ReturnUrlParams
import org.json.JSONObject

internal data class PerformAuthRequest(
    internal val paymentOperation: String? = null,
    internal val paymentMethod: PaymentMethod? = null,
    internal val sessionId: String? = null,
    internal val source: String = "MobileApp",
    internal val cardOnFile: Boolean = false,
    internal val returnUrl: String? = ReturnUrlParams.RETURN_URL,

    ) {
    internal fun toJson(): JSONObject {
        val json = JSONObject()
        paymentOperation.let { json.put("paymentOperation", it) }
        sessionId?.let { json.put("sessionId", it) }
        source.let { json.put("source", it) }
        paymentMethod?.let { json.put("paymentMethod", it.toJson()) }
        cardOnFile.let { json.put("cardOnFile", it) }
        returnUrl.let { json.put("returnUrl", it) }

        return json
    }
}

internal data class PaymentMethod(
    internal val expiryDate: String? = null,
    internal val cvv: String? = null,
    internal val cardholderName: String? = null,
    internal val cardNumber: String? = null
) {
    internal fun toJson(): JSONObject {
        val json = JSONObject()
        expiryDate?.let { json.put("expiryDate", it) }
        cvv?.let { json.put("cvv", it) }
        cardholderName?.let { json.put("cardholderName", it) }
        cardNumber?.let { json.put("cardNumber", it) }
        return json
    }
}


