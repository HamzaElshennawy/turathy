package net.geidea.sdk.core.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import java.util.concurrent.ConcurrentHashMap
import kotlin.reflect.KClass

internal class DependencyContainer private constructor() {
    private val providers = ConcurrentHashMap<String, DependencyProvider<*>>()
    private val viewModelFactories = ConcurrentHashMap<String, () -> ViewModel>()

    companion object {
        @Volatile
        private var instance: DependencyContainer? = null

        internal fun getInstance(): DependencyContainer {
            return instance ?: synchronized(this) {
                instance ?: DependencyContainer().also { instance = it }
            }
        }
    }

    private fun <T : Any> keyFor(type: KClass<T>, key: String?): String =
        key ?: type.java.name

    internal fun <T : Any> registerFactory(type: KClass<T>, key: String? = null, factory: () -> T) {
        providers[keyFor(type, key)] = DependencyProvider.Factory(factory)
    }

    internal fun <T : Any> registerSingleton(
        type: KClass<T>,
        key: String? = null,
        factory: () -> T
    ) {
        providers[keyFor(type, key)] = DependencyProvider.Singleton(factory)
    }

    internal fun <T : ViewModel> registerViewModel(
        type: KClass<T>,
        key: String? = null,
        factory: () -> T
    ) {
        viewModelFactories[keyFor(type, key)] = factory
    }

    @Suppress("UNCHECKED_CAST")
    internal fun <T : Any> get(type: KClass<T>, key: String? = null): T {
        val keyName = keyFor(type, key)
        return providers[keyName]?.get() as? T
            ?: throw IllegalArgumentException("No dependency registered for $keyName")
    }

    internal fun <T : ViewModel> getViewModel(
        type: KClass<T>,
        viewModelStoreOwner: ViewModelStoreOwner,
        key: String? = null
    ): T {
        val keyName = keyFor(type, key)
        val factory = viewModelFactories[keyName]
            ?: throw IllegalArgumentException("No ViewModel factory registered for $keyName")

        return ViewModelProvider(viewModelStoreOwner, object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <VM : ViewModel> create(modelClass: Class<VM>): VM = factory() as VM
        })[type.java]
    }

    internal fun getViewModelFactory(key: String): (() -> ViewModel)? = viewModelFactories[key]

    private fun clear() {
        providers.clear()
        viewModelFactories.clear()
    }
}

private sealed interface DependencyProvider<out T> {
    fun get(): T

    class Factory<T>(private val factory: () -> T) : DependencyProvider<T> {
        override fun get(): T = factory()
    }

    class Singleton<T>(private val factory: () -> T) : DependencyProvider<T> {
        private val instance by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { factory() }
        override fun get(): T = instance
    }
}