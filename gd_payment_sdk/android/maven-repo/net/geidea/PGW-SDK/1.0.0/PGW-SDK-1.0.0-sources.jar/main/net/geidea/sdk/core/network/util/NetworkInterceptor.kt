package net.geidea.sdk.core.network.util

import net.geidea.sdk.core.network.client.HttpMethod


internal interface NetworkInterceptor {
    fun onRequest(url: String, method: HttpMethod, headers: Map<String, String>, body: String?)
    fun onResponse(code: Int, body: String?)
}




