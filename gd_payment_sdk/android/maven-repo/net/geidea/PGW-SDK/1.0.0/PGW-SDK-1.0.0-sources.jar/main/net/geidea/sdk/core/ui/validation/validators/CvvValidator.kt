package net.geidea.sdk.core.ui.validation.validators

import net.geidea.sdk.R
import net.geidea.sdk.core.ui.validation.ValidationResult
import net.geidea.sdk.core.ui.validation.Validator

internal class CvvValidator : Validator {
    override fun validate(value: String): ValidationResult {
        // 1️⃣ Required check
        if (value.isBlank()) {
            return ValidationResult(
                isValid = false,
                message = R.string.field_required
            )
        }

        // 2️⃣ CVV should be exactly 3 digits
        val cvvRegex = Regex("^[0-9]{3,4}$")
        if (!cvvRegex.matches(value)) {
            return ValidationResult(
                isValid = false,
                message = R.string.invalid_cvv
            )
        }

        // ✅ Valid CVV
        return ValidationResult(isValid = true)
    }
}
