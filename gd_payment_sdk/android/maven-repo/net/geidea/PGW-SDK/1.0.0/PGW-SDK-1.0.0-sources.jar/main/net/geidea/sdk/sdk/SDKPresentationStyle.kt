package net.geidea.sdk.sdk

import android.app.Activity
import androidx.fragment.app.FragmentManager


sealed class SDKPresentationStyle {
    /**
     * Push to activity stack (equivalent to iOS push)
     * @param activity The activity to push from, null to use current activity
     */
    data class Push(val activity: Activity? = null) : SDKPresentationStyle()

    /**
     * Present as fragment (equivalent to iOS present)
     * @param fragmentManager The FragmentManager to use for fragment transaction
     * @param containerId The container view ID where the fragment should be added
     * @param activity The activity context, null to use current activity
     */
    data class Present(
        val presentationType: PresentationType,
        val activity: Activity
    ) : SDKPresentationStyle() {

        sealed class PresentationType {
            /**
             * Present as Fragment in container
             */
            data class Fragment(
                val fragmentManager: FragmentManager,
                val containerId: Int
            ) : PresentationType()

            /**
             * Present as Composable - returns composable that client can use
             */
//            data class Composable(
//                val navController: NavHostController,
//                val startDestination: String = Destination.CardDetailsScreen.fullRoute) : PresentationType()
        }
    }

    /**
     * Present as bottom sheet
     * @param activity The activity context
     * @param maxHeightDp Maximum height in DP, null for default
     */
    data class BottomSheet(
        val activity: Activity? = null,
        val maxHeightDp: Float? = null
    ) : SDKPresentationStyle()
}