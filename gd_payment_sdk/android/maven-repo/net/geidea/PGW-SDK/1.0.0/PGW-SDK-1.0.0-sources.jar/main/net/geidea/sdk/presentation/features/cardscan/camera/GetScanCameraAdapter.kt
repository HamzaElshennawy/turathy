package net.geidea.sdk.presentation.features.cardscan.camera

import android.app.Activity
import android.graphics.Bitmap
import android.util.Log
import android.util.Size
import android.view.ViewGroup

private const val LOG_TAG = "CameraSelector"

/**
 * Get the appropriate camera adapter. If the customer has provided an additional camera adapter,
 * use that in place of camera 1.
 */
internal fun getScanCameraAdapter(
    activity: Activity,
    previewView: ViewGroup,
    minimumResolution: Size,
    cameraErrorListener: CameraErrorListener
): CameraAdapter<CameraPreviewImage<Bitmap>> =
    Camera1Adapter(activity, previewView, minimumResolution, cameraErrorListener).apply {
        Log.d(LOG_TAG, "Using camera implementation ${this.implementationName}")
    }