package net.geidea.sdk.core.network.client


import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import net.geidea.sdk.core.network.interceptor.LoggingInterceptor
import net.geidea.sdk.core.network.response.BaseResponse
import net.geidea.sdk.core.network.util.HttpConnectionUtils
import net.geidea.sdk.core.network.util.NetworkInterceptor
import net.geidea.sdk.core.network.util.UrlUtils.buildUrlWithParams
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL


internal class HttpRequestExecutor(
    private val networkInterceptor: NetworkInterceptor? = LoggingInterceptor(),
    private val connectTimeout: Int = 60_000,
    private val readTimeout: Int = 60_000,
    private val totalTimeout: Long = 60_000L,
    private val language: String = "en",
) {
    internal fun <T> executeAsFlow(
        method: HttpMethod,
        url: String,
        queryParams: Map<String, String> = emptyMap(),
        body: JSONObject? = null,
        headers: Map<String, String> = emptyMap(),
        mapper: (String) -> T
    ): Flow<BaseResponse<T>> = flow {
        val finalUrl = buildUrlWithParams(url, queryParams)
        var connection: HttpURLConnection? = null

        try {
            val response = withTimeout(totalTimeout) {
                withContext(Dispatchers.IO) {
                    connection = URL(finalUrl).openConnection() as HttpURLConnection
                    HttpConnectionUtils.setupAndExecute(
                        connection = connection,
                        method = method,
                        body = body,
                        headers = headers,
                        connectTimeout = connectTimeout,
                        readTimeout = readTimeout,
                        networkInterceptor = networkInterceptor,
                        url = finalUrl,
                        mapper = mapper,
                        language = language
                    )
                }
            }
            emit(response) // Success or Failure from HttpConnectionUtils
        } finally {
            connection?.disconnect()
        }
    }.flowOn(Dispatchers.IO)
}