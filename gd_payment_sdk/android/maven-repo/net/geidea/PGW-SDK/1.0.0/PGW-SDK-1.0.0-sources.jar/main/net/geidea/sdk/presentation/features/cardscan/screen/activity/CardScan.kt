package net.geidea.sdk.presentation.features.cardscan.screen.activity

import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultRegistry
import kotlin.toString

internal class CardScan(private val activity: ComponentActivity) {
    private var callback: ((CardScanSheetResult) -> Unit)? = null

    private val scanSheet = CardScanSheet.create(
        from = activity,
        cardScanSheetResultCallback = { result ->
            callback?.invoke(result)
        }
    )

    fun startScan(onResult: (CardScanSheetResult) -> Unit) {
        this.callback = onResult
        scanSheet.present()
    }

}