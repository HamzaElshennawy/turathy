package net.geidea.sdk.presentation.features.cardscan.component

import android.util.Log
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import net.geidea.sdk.R
import net.geidea.sdk.core.utils.extensions.toBitmapImage
import net.geidea.sdk.presentation.features.cardscan.ScannedCardData
import net.geidea.sdk.presentation.features.cardscan.logic.ProductionCardRecognizer
import net.geidea.sdk.presentation.features.cardscan.viewmodel.CardScanEvent
import net.geidea.sdk.presentation.features.cardscan.viewmodel.CardScanState
import java.util.concurrent.Executors


@Composable
internal fun CardScannerPreview(
    state: CardScanState,
    onEvent: (CardScanEvent) -> Unit,
    modifier: Modifier = Modifier
) {

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val coroutineScope = rememberCoroutineScope()

    var camera by remember { mutableStateOf<Camera?>(null) }
    // Keep track of last analysis time (throttle OCR)
    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)

                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()

                    val preview = Preview.Builder()
                        .setTargetResolution(android.util.Size(1280, 720))
                        .build()
                    preview.surfaceProvider = previewView.surfaceProvider

                    val analysis = ImageAnalysis.Builder()
                        .setTargetResolution(android.util.Size(1280, 720))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()

                    analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { proxy ->
                        val bitmap = proxy.toBitmapImage()
                        val bounds = proxy.cropRect
                        proxy.close()


                    }

                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        analysis
                    )
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        // Animated card frame overlay
        AnimatedCardFrameOverlay(
            progress = state.animationProgress,
            isAnimating = state.isAnimating,
            modifier = Modifier.fillMaxSize()
        )

        // Top controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = {
                    onEvent(CardScanEvent.Close)
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .size(40.dp)
            ) {
                Icon(
                    Icons.Default.Close,
                    contentDescription = "Close",
                    tint = Color.White
                )
            }

            IconButton(
                onClick = {
                    onEvent(if (state.isFlashOn) CardScanEvent.ToggleFlashOff else CardScanEvent.ToggleFlashOn)
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .size(40.dp)
            ) {
                Icon(
                    painter = if (state.isFlashOn) painterResource(R.drawable.ic_flash_off) else painterResource(
                        R.drawable.ic_flash_on
                    ),
                    contentDescription = "Toggle Flash",
                    tint = Color.White
                )
            }
        }

        // Instructions and processing indicator
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.position_your_card_on_the_frame),
                color = Color.White,
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.height(8.dp))
        }
    }

    // Handle flash changes
    LaunchedEffect(state.isFlashOn) {
        camera?.let { cam ->
            if (cam.cameraInfo.hasFlashUnit()) {
                cam.cameraControl.enableTorch(state.isFlashOn)
            }
        }
    }

    // 🔥 Properly release camera when screen is disposed
    DisposableEffect(lifecycleOwner) {
        onDispose {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                cameraProvider.unbindAll()
            }, ContextCompat.getMainExecutor(context))

            cameraExecutor.shutdown()
        }
    }
}

// 2. Fixed processImage function with proper state management
private fun processImage(
    imageProxy: ImageProxy,
    textRecognizer: ProductionCardRecognizer,
    onProcessingStateChanged: (Boolean) -> Unit,
    onResult: (ScannedCardData) -> Unit
) {
    try {
        onProcessingStateChanged(true)

        val bitmap = imageProxy.toBitmapImage()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cardData = textRecognizer.extractCardData(bitmap)

                withContext(Dispatchers.Main) {
                    if (cardData.isValid) {
                        Log.d("CardScan", "✓ Card detected: ${cardData.cardNumber}")
                        onResult(cardData)
                    }

                    delay(300) // Faster than your current 1000ms
                    onProcessingStateChanged(false)
                }
            } catch (e: Exception) {
                Log.e("CardScan", "Processing error", e)
                withContext(Dispatchers.Main) {
                    onProcessingStateChanged(false)
                }
            }
        }
    } catch (e: Exception) {
        Log.e("CardScan", "Image conversion error", e)
        onProcessingStateChanged(false)
    } finally {
        imageProxy.close()
    }
}