package net.geidea.sdk.core.utils.constants

internal object Constants {
    internal object SDKDefaultColors {
        internal const val PRIMARY_HEX = "#FF4D00" // Your default primary color
        internal const val SECONDARY_HEX = "#F5F5F6" // Your default secondary color
        internal const val PRIMARY_DARK_HEX = "#FF4D00"
        internal const val SECONDARY_DARK_HEX = "#F5F5F6"
    }

    internal object Regex {
        internal const val PHONE_VALIDATION = "^\\+?[0-9\\s\\-()]{7,20}$"
        internal const val NAME_VALIDATION = "^[a-zA-Z\\s.'-]{2,50}$"
        internal const val NUMBER_VALIDATION = "^\\d{1,10}$"
        internal const val POSTAL_CODE_VALIDATION = "^\\d{4,10}$"
        internal const val DATE_VALIDATION_REGEX = "^(0[1-9]|1[0-2])/\\d{2}$"
        internal const val ADDRESS_MIN_LENGTH = 5
        internal const val CARD_NUMBER_LENGTH = 16

        internal const val CARD_NUMBER_GROUP_LENGTH = 4
        internal const val MAX_EXPIRY_YEARS = 10
    }

    internal object DestinationArgs {
        internal const val AUTH_RESPONSE = "auth_response"
        internal const val CARD_DETAILS = "card_details"
        internal const val PROCEED_TO_PAY = "proceed_to_pay"
    }

    internal object Date {
        internal val MONTHS_EN = listOf(
            "01 - January",
            "02 - February",
            "03 - March",
            "04 - April",
            "05 - May",
            "06 - June",
            "07 - July",
            "08 - August",
            "09 - September",
            "10 - October",
            "11 - November",
            "12 - December"
        )
        internal val MONTHS_AR = listOf(
            "يناير - 01",
            "فبراير - 02",
            "مارس - 03",
            "أبريل - 04",
            "مايو - 05",
            "يونيو - 06",
            "يوليو - 07",
            "أغسطس - 08",
            "سبتمبر - 09",
            "أكتوبر - 10",
            "نوفمبر - 11",
            "ديسمبر - 12",
        )
    }

    internal const val CARD_METHOD = "card"


    object PaymentOperation {
        const val SAVE_CARD = "SaveCard"
        const val PAY = "Pay"
    }

    internal const val SDK_SOURCE = "MobileApp"
    internal const val PUBLIC_KEY =
        "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhu9juoUaghyhp15V40D/cdj3AmWTWI8MO" +
                "HQf9U9q7u8hb+nk4GS9qgUX5tuylW2N3JLpWqRHHoI2NLubncpec30lUCrIcAvHih83fp2CXZlAhOEatgrbY0EMeQKQL6eHUfqepVxFuF/" +
                "PucfMuonmDORAnVf883QxN8LWHwRhH/7+yr3Kg7Qh/YqLwPE20hD4K96UDs8hu3fZ94Aa/bqCOajA/3+VtpxckIxaXdAWA+1sVTZRaVh0i1" +
                "zoakxSpZw8wTSTo08cQEtdzBof5rAfEZlTwV040PQrtqekmV7rl752Ten3p8pID2F0EvRkbrTq3ORaykilY3Sbar2vpjfJuwIDAQAB"

}