package net.geidea.sdk.data.repository

import kotlinx.coroutines.flow.Flow
import net.geidea.sdk.core.network.response.BaseResponse
import net.geidea.sdk.data.source.remote.PaymentRemoteDataSource
import net.geidea.sdk.domain.model.pay.GetPerformAuthenticateResponse
import net.geidea.sdk.domain.model.pay.PayRequest
import net.geidea.sdk.domain.model.pay.PayResponse
import net.geidea.sdk.domain.model.pay.PerformAuthRequest
import net.geidea.sdk.domain.model.paymentdetails.PaymentConfigResponse
import net.geidea.sdk.domain.repository.PaymentRepository

internal class PaymentRepositoryImpl(
    private val remoteDataSource: PaymentRemoteDataSource
) : PaymentRepository {


    override fun getMerchantConfigurationDetails(): Flow<BaseResponse<PaymentConfigResponse>> {
        return remoteDataSource.getMerchantConfigurationDetails()
    }

    override fun performAuthentication(request: PerformAuthRequest): Flow<GetPerformAuthenticateResponse> {
        return remoteDataSource.performAuthentication(request)
    }

    override fun pay(request: PayRequest): Flow<PayResponse> {
        return remoteDataSource.pay(request)
    }
}