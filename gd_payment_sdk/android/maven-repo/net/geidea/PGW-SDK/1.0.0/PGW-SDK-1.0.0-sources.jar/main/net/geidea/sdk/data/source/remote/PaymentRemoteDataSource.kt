package net.geidea.sdk.data.source.remote

import kotlinx.coroutines.flow.Flow
import net.geidea.sdk.core.network.EndPoints
import net.geidea.sdk.core.network.client.NetworkClient
import net.geidea.sdk.core.network.response.BaseResponse
import net.geidea.sdk.domain.model.pay.GetPerformAuthenticateResponse
import net.geidea.sdk.domain.model.pay.PayRequest
import net.geidea.sdk.domain.model.pay.PayResponse
import net.geidea.sdk.domain.model.pay.PerformAuthRequest
import net.geidea.sdk.domain.model.pay.mapPayResponse
import net.geidea.sdk.domain.model.pay.mapPerformAuthenticateResponse
import net.geidea.sdk.domain.model.paymentdetails.PaymentConfigResponse
import net.geidea.sdk.domain.model.paymentdetails.mapPaymentConfigResponse
import net.geidea.sdk.sdk.GDPaymentSDK

internal interface PaymentRemoteDataSource {
    fun getMerchantConfigurationDetails(): Flow<BaseResponse<PaymentConfigResponse>>
    fun performAuthentication(request: PerformAuthRequest): Flow<GetPerformAuthenticateResponse>
    fun pay(request: PayRequest): Flow<PayResponse>
}

internal class PaymentRemoteDataSourceImpl(
    private val httpClient: NetworkClient,
) : PaymentRemoteDataSource {


    override fun getMerchantConfigurationDetails(): Flow<BaseResponse<PaymentConfigResponse>> {
        return httpClient.getAsFlow(
            url = EndPoints.CONFIGURATIONS_DETAILS + GDPaymentSDK.sharedInstance()
                .getConfigurations().sessionId,
            mapper = { jsonString ->
                mapPaymentConfigResponse(jsonString)
            })
    }

    override fun performAuthentication(request: PerformAuthRequest): Flow<GetPerformAuthenticateResponse> {
        return httpClient.postAsFlow(
            url = EndPoints.PERFORM_AUTHENTICATION,
            mapper = { jsonString ->
                mapPerformAuthenticateResponse(jsonString)
            },
            body = request.toJson()
        )
    }

    override fun pay(request: PayRequest): Flow<PayResponse> {
        return httpClient.postAsFlow(
            url = EndPoints.PAY,
            mapper = { jsonString ->
                mapPayResponse(jsonString)
            },
            body = request.toJson()
        )
    }
}