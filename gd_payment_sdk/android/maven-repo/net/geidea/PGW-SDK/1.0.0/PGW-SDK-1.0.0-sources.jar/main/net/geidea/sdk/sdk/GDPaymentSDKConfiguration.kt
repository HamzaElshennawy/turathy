package net.geidea.sdk.sdk

data class GDPaymentSDKConfiguration(
    val theme: SDKTheme = SDKTheme(), // default theme
    val sessionId: String,
    val language: SDKLanguage = SDKLanguage.ENGLISH,
    val isSandbox: Boolean = false,
    val region: REGION = REGION.EGY,
)

enum class REGION {
    EGY,
    KSA,
    UAE
}