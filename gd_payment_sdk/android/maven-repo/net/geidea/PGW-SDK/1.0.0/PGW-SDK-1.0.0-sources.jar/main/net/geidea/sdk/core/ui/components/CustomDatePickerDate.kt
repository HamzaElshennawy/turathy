package net.geidea.sdk.core.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.utils.constants.Constants
import net.geidea.sdk.core.utils.constants.Constants.Regex.MAX_EXPIRY_YEARS
import net.geidea.sdk.core.utils.extensions.withSdkLocale
import net.geidea.sdk.sdk.GDPaymentSDK
import net.geidea.sdk.sdk.SDKLanguage
import java.util.Calendar


@Composable
internal fun CustomDatePickerDialog(
    modifier: Modifier = Modifier,
    initialMonth: Int,
    initialYear: Int,
    onDateConfirmed: (Calendar) -> Unit,
    onDismissRequest: () -> Unit,
    language: SDKLanguage = GDPaymentSDK.sharedInstance().getConfigurations().language,
) {
    val currentYear = Calendar.getInstance().get(Calendar.YEAR)
    val years = (currentYear..currentYear + MAX_EXPIRY_YEARS).toList() // List of years

    var selectedMonth by rememberSaveable { mutableIntStateOf(initialMonth) }
    var selectedYear by rememberSaveable { mutableIntStateOf(initialYear) }

    val localizedContext = LocalContext.current.withSdkLocale(language)
    CompositionLocalProvider(
        LocalContext provides localizedContext,
        LocalLayoutDirection provides LayoutDirection.Ltr,
    ) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .background(
                    color = SdkTheme.colors.surface,
                    shape = RoundedCornerShape(dimensionResource(R.dimen.spacing_16))
                )
                .padding(
                    start = dimensionResource(R.dimen.spacing_8),
                    end = dimensionResource(R.dimen.spacing_8),
                    bottom = dimensionResource(R.dimen.spacing_8),
                )
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismissRequest) {
                        Text(stringResource(R.string.cancel), color = SdkTheme.colors.primaryBlue)
                    }

                    Text(
                        text = stringResource(R.string.pick_date),
                        style = SdkTheme.typography.bold14.copy(color = SdkTheme.colors.onPrimary),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = {
                            val calendar = Calendar.getInstance()
                            calendar.set(selectedYear, selectedMonth - 1, 1)
                            onDateConfirmed(calendar)
                            onDismissRequest()
                        }
                    ) {
                        Text(stringResource(R.string.done), color = SdkTheme.colors.primaryBlue)
                    }
                }

                HorizontalDivider(
                    thickness = dimensionResource(R.dimen.spacing_1),
                    color = Color.LightGray
                )

                Row(
                    modifier = Modifier
                        .padding(top = dimensionResource(R.dimen.spacing_16))
                        .fillMaxWidth()
                        .height(dimensionResource(R.dimen.picker_height)),
                    horizontalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.spacing_8))
                ) {
                    PickerColumn(
                        modifier = Modifier.weight(1f),
                        items = if (language == SDKLanguage.ENGLISH) Constants.Date.MONTHS_EN else Constants.Date.MONTHS_AR,
                        selectedIndex = selectedMonth - 1,
                        onItemSelected = { selectedMonth = it + 1 } // Update selected month
                    )

                    PickerColumn(
                        modifier = Modifier.weight(1f),
                        items = years.map { it.toString() },
                        selectedIndex = years.indexOf(selectedYear).coerceAtLeast(0),
                        onItemSelected = { selectedYear = years[it] } // Update selected year
                    )
                }
            }
        }
    }
}

@Composable
private fun PickerColumn(
    modifier: Modifier = Modifier,
    items: List<String>,
    selectedIndex: Int,
    onItemSelected: (Int) -> Unit,
) {
    val pickerHeight = dimensionResource(R.dimen.picker_height)
    val itemHeightDp = pickerHeight / 5
    val itemHeightPx = with(LocalDensity.current) { itemHeightDp.toPx() }

    val listState = rememberLazyListState()
    val haptic = LocalHapticFeedback.current
    val snapBehavior = rememberSnapFlingBehavior(lazyListState = listState)

    LaunchedEffect(selectedIndex) {
        listState.scrollToItem(selectedIndex.coerceIn(0, items.lastIndex))
    }

    val currentCenterIndex by remember {
        derivedStateOf {
            val offsetPx = listState.firstVisibleItemScrollOffset
            val itemOffset = if (offsetPx > itemHeightPx / 2) 1 else 0
            (listState.firstVisibleItemIndex + itemOffset).coerceIn(0, items.lastIndex)
        }
    }

    LaunchedEffect(currentCenterIndex, listState.isScrollInProgress) {
        if (!listState.isScrollInProgress && currentCenterIndex != selectedIndex) {
            onItemSelected(currentCenterIndex)
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }

    Box(
        modifier = modifier.height(pickerHeight),
        contentAlignment = Alignment.Center
    ) {
        LazyColumn(
            state = listState,
            flingBehavior = snapBehavior,
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            contentPadding = PaddingValues(vertical = itemHeightDp * 2),
        ) {
            itemsIndexed(items) { index, item ->
                Box(
                    modifier = Modifier
                        .height(itemHeightDp)
                        .fillMaxWidth()
                        .clickable { onItemSelected(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = item,
                        textAlign = TextAlign.Start,
                        style = if (index == selectedIndex) SdkTheme.typography.bold14.copy(
                            fontWeight = FontWeight.Bold,
                            color = SdkTheme.colors.onPrimary
                        ) else SdkTheme.typography.regular14.copy(
                            color = SdkTheme.colors.onPrimary
                        ),
                        color = if (index == selectedIndex) SdkTheme.colors.onPrimary
                        else SdkTheme.colors.onPrimary.copy(alpha = 0.6f)
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(itemHeightDp)
                .align(Alignment.Center)
                .background(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp)
                )
        )
    }
}
