package net.geidea.sdk.presentation.features.paymentdetails.screen


import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.dimensionResource
import net.geidea.sdk.R
import net.geidea.sdk.core.di.injectViewModel
import net.geidea.sdk.core.ui.BaseScreen
import net.geidea.sdk.core.ui.DefaultLoadingScreen
import net.geidea.sdk.core.ui.components.PrimaryButtonColor
import net.geidea.sdk.core.utils.constants.Constants
import net.geidea.sdk.domain.model.pay.PerformAuthenticateResponse
import net.geidea.sdk.presentation.features.cardscan.ScannedCardResult
import net.geidea.sdk.presentation.features.paymentdetails.components.card.carddetails.CardDetailsEvent
import net.geidea.sdk.presentation.features.paymentdetails.components.card.carddetails.CardDetailsSection
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.CardUiModel
import net.geidea.sdk.presentation.features.paymentdetails.components.card.savedcard.savedCardsSection
import net.geidea.sdk.presentation.features.paymentdetails.components.header.PaymentHeaderSection
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEffect
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentState
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentViewModel
import net.geidea.sdk.presentation.features.receipt.ReceiptDialog
import net.geidea.sdk.sdk.GDPaymentSDK

@Composable
internal fun PaymentScreen(
    viewModel: PaymentViewModel = injectViewModel<PaymentViewModel>(),
    onNavigateToCardScan: () -> Unit,
    onNavigateToOTP: (authResponse: PerformAuthenticateResponse, cardDetails: CardUiModel) -> Unit,
    scannedCardResult: ScannedCardResult? = null,
    proceedToPay: Boolean = false,
) {
    LaunchedEffect(scannedCardResult) {
        scannedCardResult?.cardData?.let {
            viewModel.sendEvent(CardDetailsEvent.CardScanned(it))
        }
    }

    LaunchedEffect(proceedToPay) {
        if (proceedToPay) {
            viewModel.sendEvent(PaymentEvent.ProceedToPay)
        }
    }

    BaseScreen(
        viewModel = viewModel,
        onEffect = { effect ->
            when (effect) {
                is PaymentEffect.NavigateToOTP -> onNavigateToOTP(
                    effect.authResponse,
                    effect.cardDetails
                )

                PaymentEffect.NavigateToCardScan -> onNavigateToCardScan()
                else -> Unit
            }
        },
        content = { state ->
            Box(modifier = Modifier.fillMaxSize()) {
                PaymentScreenContent(state, viewModel, viewModel::sendEvent)

                if (state.showOverlayLoading) {
                    DefaultLoadingScreen()
                }

                ReceiptDialog(
                    showDialog = state.showReceiptDialog,
                    paymentResponse = state.paymentResponse,
                    paymentOperation = state.paymentOperation.orEmpty(),
                    onDismiss = { viewModel.sendEvent(PaymentEvent.DismissReceipt) },
                    onClickPrimaryAction = { println("Primary action clicked") }
                )
            }
        },
        fullScreenDismiss = {
            GDPaymentSDK.sharedInstance().onPaymentCanceled()
        }
    )
}


@Composable
private fun PaymentScreenContent(
    state: PaymentState,
    viewModel: PaymentViewModel,
    onEvent: (PaymentEvent) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // 1️⃣ Header
        PaymentHeaderSection(
            paymentState = state,
            onEvent = viewModel::sendEvent,
        )

        PaymentDetails(state = state, viewModel = viewModel, onEvent = onEvent)
    }
}

@Composable
private fun ColumnScope.PaymentDetails(
    modifier: Modifier = Modifier,
    state: PaymentState,
    viewModel: PaymentViewModel,
    onEvent: (PaymentEvent) -> Unit
) {
    val lazyListState = rememberLazyListState()
    var isScrolling by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    val isScrollInProgress by remember {
        derivedStateOf { lazyListState.isScrollInProgress }
    }
    LaunchedEffect(isScrollInProgress) {
        if (isScrollInProgress && !isScrolling && state.paymentHeaderState.isExpanded) {
            isScrolling = true
            onEvent(PaymentEvent.ScrollingStarted)
        } else if (!isScrollInProgress && isScrolling && !state.paymentHeaderState.isExpanded) {
            isScrolling = false
        }
    }

    LazyColumn(
        modifier = modifier.weight(1f),
        state = lazyListState,
        contentPadding = PaddingValues(bottom = dimensionResource(R.dimen.spacing_16))

    ) {


//
//        item(key = "PaymentMethods") {
//            PaymentMethods(
//                modifier = Modifier.padding(
//                    top = dimensionResource(R.dimen.spacing_32),
//                ),
//                state = state.paymentMethodState,
//                onEvent = viewModel::sendEvent,
//            )
//        }
        if (state.paymentOperation != Constants.PaymentOperation.SAVE_CARD)
            savedCardsSection(
                state = state.savedCardsState,
                onEvent = viewModel::sendEvent,
            )


        item(key = "cardDetails") {
            AnimatedVisibility(
                modifier = Modifier.padding(horizontal = dimensionResource(R.dimen.spacing_16)),
                visible = !state.savedCardsState.showAddNewCardRow
                        || state.savedCardsState.cards.isEmpty(),
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut(),
            ) {
                CardDetailsSection(
                    paymentState = state,
                    onEvent = viewModel::sendEvent,
                )
            }
        }

        item(key = "pay_top_spacer") {
            Spacer(modifier = Modifier.height(dimensionResource(R.dimen.spacing_32)))
        }
        item(key = "payButton") {
            PrimaryButtonColor(
                enabled = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = dimensionResource(R.dimen.spacing_16)),
                onClick = {
                    focusManager.clearFocus(force = true)
                    viewModel.sendEvent(PaymentEvent.SubmitClicked)
                },
                text = if (state.paymentOperation == Constants.PaymentOperation.SAVE_CARD)
                    R.string.save
                else
                    R.string.pay,
                loading = state.isLoading
            )
        }
    }
}
