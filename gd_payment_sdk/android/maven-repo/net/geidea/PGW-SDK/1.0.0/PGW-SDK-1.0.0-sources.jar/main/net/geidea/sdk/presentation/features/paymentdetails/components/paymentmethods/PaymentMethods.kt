package net.geidea.sdk.presentation.features.paymentdetails.components.paymentmethods


import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.components.BaseAsyncImage
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.domain.model.paymentdetails.PaymentMethod


@Composable
internal fun PaymentMethods(
    modifier: Modifier = Modifier,
    state: PaymentMethodsState,
    onEvent: (PaymentMethodsEvent) -> Unit
) {
    Column(modifier = modifier) {
        Text(
            modifier = Modifier.padding(
                bottom = dimensionResource(R.dimen.spacing_16),
                start = dimensionResource(R.dimen.spacing_16),
                end = dimensionResource(R.dimen.spacing_16)
            ),
            text = stringResource(R.string.Payment_methods),
            style = SdkTheme.typography.bold20.copy(
                color = SdkTheme.colors.onPrimary
            )
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = dimensionResource(R.dimen.spacing_16)),
            horizontalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.spacing_16))
        ) {
            items(
                state.paymentMethods,
                key = { it.id }
            ) { method ->
                PaymentMethodItem(
                    method = method,
                    isSelected = method == state.selectedMethod,
                    onClick = { onEvent(PaymentMethodsEvent.OnMethodSelected(method)) }
                )
            }
        }
    }
}

@Composable
private fun PaymentMethodItem(
    modifier: Modifier = Modifier,
    method: PaymentMethod,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val border = if (isSelected) {
        BorderStroke(dimensionResource(R.dimen.spacing_05), SdkTheme.colors.primary)
    } else {
        BorderStroke(dimensionResource(R.dimen.spacing_1), SdkTheme.colors.neutral20)
    }

    Card(
        modifier = modifier
            .size(
                width = dimensionResource(R.dimen.spacing_113),
                height = dimensionResource(R.dimen.spacing_96)
            )
            .clickable { onClick() },
        shape = RoundedCornerShape(dimensionResource(R.dimen.spacing_8)),
        border = border,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        colors = CardDefaults.cardColors(containerColor = SdkTheme.colors.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(dimensionResource(R.dimen.spacing_16)),
        ) {
            BaseAsyncImage(
                imageUrl = method.icon,
                contentDescription = method.name,
                modifier = Modifier
                    .height(dimensionResource(R.dimen.spacing_24))
                    .wrapContentWidth(),
            )

            Text(
                text = method.name.orEmpty(),
                style = SdkTheme.typography.regular14.copy(
                    color = SdkTheme.colors.onPrimary,
                    lineBreak = LineBreak.Simple
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                softWrap = true,
                modifier = Modifier
                    .padding(top = dimensionResource(R.dimen.spacing_8))
                    .fillMaxWidth()
            )
        }
    }
}





