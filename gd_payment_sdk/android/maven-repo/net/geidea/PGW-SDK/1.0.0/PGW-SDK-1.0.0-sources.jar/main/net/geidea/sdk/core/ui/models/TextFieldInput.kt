package net.geidea.sdk.core.ui.models

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import net.geidea.sdk.core.ui.validation.ValidationResult
import net.geidea.sdk.core.ui.validation.Validator

@Immutable
@Stable
internal data class TextFieldInput(
    internal val value: String = "",
    internal val validation: ValidationResult = ValidationResult(isValid = true),
)

internal fun updateTextField(value: String, validator: Validator): TextFieldInput =
    TextFieldInput(value = value, validation = validator.validate(value))

internal fun updateTextField(value: String): TextFieldInput =
    TextFieldInput(value = value)