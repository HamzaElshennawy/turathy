package net.geidea.sdk.core.utils.extensions

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first


internal suspend fun LazyListState.scrollToItemByKey(
    key: Any,
    scrollOffset: Int = 0,
    fallbackIndex: Int = 0
) {
    snapshotFlow { layoutInfo.totalItemsCount }
        .filter { it > 0 }
        .first()

    val totalCount = layoutInfo.totalItemsCount
    if (totalCount == 0) return // 🛡️ Prevent crash

    val index = layoutInfo.visibleItemsInfo
        .firstOrNull { it.key == key }?.index
        ?: fallbackIndex.coerceIn(0, totalCount - 1) // 🛡️ Safe fallback

    animateScrollToItem(index, scrollOffset) // ✅ Safe now
}


//suspend fun LazyListState.smoothScrollToItemByKey(
//    key: Any,
//    durationMillis: Int = 300,
//    fallbackIndex: Int = 0,
//    scrollOffset: Int = 0
//) {
//    // Ensure layout is populated
//    snapshotFlow { layoutInfo.totalItemsCount }
//        .filter { it > 0 }
//        .first()
//
//    val targetIndex = layoutInfo.visibleItemsInfo
//        .firstOrNull { it.key == key }?.index
//        ?: layoutInfo.totalItemsCount.let {
//            fallbackIndex.coerceAtMost(it - 1)
//        }
//
//    val currentIndex = firstVisibleItemIndex
//    val direction = (targetIndex - currentIndex).sign
//
//    // Snap to current position to avoid jump
//    scrollToItem(currentIndex, firstVisibleItemScrollOffset)
//
//    // Estimate smooth scroll step
//    val viewportSize = layoutInfo.viewportEndOffset
//    val totalSteps = (durationMillis / 16).coerceAtLeast(1)
//    val distancePerStep = (viewportSize / totalSteps.toFloat())
//
//    repeat(totalSteps) {
//        animateScrollBy(distancePerStep * direction)
//        delay(16)
//    }
//
//    // Final snap for precision
//    scrollToItem(index = targetIndex, scrollOffset = scrollOffset)
//}

