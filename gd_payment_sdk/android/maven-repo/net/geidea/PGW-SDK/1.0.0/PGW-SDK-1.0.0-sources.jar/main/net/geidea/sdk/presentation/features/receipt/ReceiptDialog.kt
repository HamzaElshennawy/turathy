package net.geidea.sdk.presentation.features.receipt

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.window.DialogProperties
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.components.PrimaryButtonColor
import net.geidea.sdk.core.ui.components.ReceiptDetailsItemComponent
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.utils.constants.Constants
import net.geidea.sdk.core.utils.extensions.getCurrentTimestamp
import net.geidea.sdk.core.utils.extensions.withSdkLocale
import net.geidea.sdk.domain.model.pay.ThreeDSecureResponse
import net.geidea.sdk.sdk.GDPaymentSDK
import net.geidea.sdk.sdk.SDKLanguage

@Composable
internal fun ReceiptDialog(
    showDialog: Boolean,
    paymentResponse: ThreeDSecureResponse? = null,
    paymentOperation: String? = null,
    onDismiss: () -> Unit,
    language: SDKLanguage = GDPaymentSDK.sharedInstance().getConfigurations().language,
    onClickPrimaryAction: () -> Unit
) {
    if (showDialog) {
        AlertDialog(
            onDismissRequest = onDismiss,
            confirmButton = { },
            text = {
                val localizedContext = LocalContext.current.withSdkLocale(language)
                CompositionLocalProvider(
                    LocalContext provides localizedContext,
                ) {
                    ReceiptContent(
                        paymentResponse = paymentResponse,
                        infoRows = listOf(
                            stringResource(R.string.date) to getCurrentTimestamp(),
                            stringResource(R.string.order_id) to (paymentResponse?.orderId ?: ""),
                        ),
                        paymentOperation = paymentOperation,
                        onClickPrimaryAction = {
                            onClickPrimaryAction()
                            onDismiss()
                        },
                        onDismiss = onDismiss
                    )
                }
            },
            shape = RoundedCornerShape(dimensionResource(R.dimen.spacing_16)),
            containerColor = SdkTheme.colors.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = dimensionResource(R.dimen.spacing_16)),
            properties = DialogProperties(
                dismissOnClickOutside = false,
                usePlatformDefaultWidth = false
            )
        )
    }
}


@Composable
private fun ReceiptContent(
    modifier: Modifier = Modifier,
    paymentResponse: ThreeDSecureResponse? = null,
    infoRows: List<Pair<String, String>> = arrayListOf(),
    paymentOperation: String? = null,
    onClickPrimaryAction: () -> Unit,
    onDismiss: () -> Unit,
) {

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(dimensionResource(R.dimen.spacing_16)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .clickable {
                    onDismiss()
                }) {
            Icon(
                modifier = modifier.align(Alignment.CenterEnd),
                painter = painterResource(R.drawable.ic_close),
                contentDescription = stringResource(R.string.close),
            )
        }
        // Icon
        Image(
            painter = if (paymentResponse?.responseCode == "000") painterResource(id = R.drawable.ic_tick_circle)
            else painterResource(id = R.drawable.ic_minus_cirlce),
            contentDescription = null,
            modifier = Modifier.scale(1.0f)
        )

        Spacer(modifier = Modifier.height(dimensionResource(R.dimen.spacing_32)))

        // Title
        Text(
            text = paymentResponse?.responseMessage ?: "",
            style = SdkTheme.typography.bold24,
            color = SdkTheme.colors.onPrimary,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(dimensionResource(R.dimen.spacing_8)))

        //Subtitle
        Text(
            text = paymentResponse?.detailedResponseMessage ?: "",
            style = SdkTheme.typography.medium14,
            color = SdkTheme.colors.onPrimary,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(dimensionResource(R.dimen.spacing_32)))

        if (paymentOperation != Constants.PaymentOperation.SAVE_CARD) {


            infoRows.forEach { (label, value) ->
                ReceiptDetailsItemComponent(label, value)
            }



            Spacer(modifier = Modifier.height(dimensionResource(R.dimen.spacing_32)))
        }
        PrimaryButtonColor(
            modifier = Modifier
                .fillMaxWidth(),
            onClick = { onClickPrimaryAction() },
            text = if (paymentResponse?.responseCode == "000") R.string.continue_shopping else R.string.try_again,
        )

        Spacer(modifier = Modifier.height(dimensionResource(R.dimen.spacing_16)))

    }
}

