package net.geidea.sdk.presentation.features.cardscan

import org.json.JSONObject


internal data class ScannedCardResult(
    internal val success: Boolean,
    internal val cardData: ScannedCardData?,
    internal val error: String? = null
)

internal fun ScannedCardResult.toJson(): String {
    val json = JSONObject()
    json.put("success", success)

    cardData?.let {
        val cardJson = JSONObject()
        cardJson.put("cardNumber", it.cardNumber)
        cardJson.put("expiryDate", it.expiryDate)
        cardJson.put("cardHolder", it.cardHolderName)
        json.put("cardData", cardJson)
    }

    return json.toString()
}

internal fun scannedCardResultFromJson(jsonString: String): ScannedCardResult {
    val json = JSONObject(jsonString)
    val success = json.getBoolean("success")

    val cardData = if (json.has("cardData")) {
        val cardJson = json.getJSONObject("cardData")
        ScannedCardData(
            cardNumber = cardJson.optString("cardNumber"),
            expiryDate = cardJson.optString("expiryDate"),
            cardHolderName = cardJson.optString("cardHolder")
        )
    } else null

    return ScannedCardResult(success, cardData)
}