package net.geidea.sdk.domain.usecase

import kotlinx.coroutines.flow.Flow
import net.geidea.sdk.core.utils.constants.Constants
import net.geidea.sdk.core.utils.constants.RSAUtil
import net.geidea.sdk.domain.model.pay.PayRequest
import net.geidea.sdk.domain.model.pay.PayResponse
import net.geidea.sdk.domain.repository.PaymentRepository

internal class PayUseCase(private val repository: PaymentRepository) {
    internal fun execute(request: PayRequest): Flow<PayResponse> {
        val encryptedRequest = request.copy(
            paymentMethod = request.paymentMethod?.copy(
                cardNumber = request.paymentMethod.cardNumber?.let {
                    RSAUtil.encrypt(
                        it, RSAUtil.loadPublicKey(
                            Constants.PUBLIC_KEY
                        )
                    )
                },
                expiryDate = request.paymentMethod.expiryDate?.let {
                    RSAUtil.encrypt(
                        it, RSAUtil.loadPublicKey(
                            Constants.PUBLIC_KEY
                        )
                    )
                },
                cvv = request.paymentMethod.cvv?.let {
                    RSAUtil.encrypt(
                        it, RSAUtil.loadPublicKey(
                            Constants.PUBLIC_KEY
                        )
                    )
                }
            )
        )
        return repository.pay(encryptedRequest)
    }
}