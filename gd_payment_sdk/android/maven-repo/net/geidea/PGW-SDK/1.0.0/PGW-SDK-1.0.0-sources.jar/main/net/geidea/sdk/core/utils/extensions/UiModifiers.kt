package net.geidea.sdk.core.utils.extensions

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.res.dimensionResource
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme


@Composable
internal fun Modifier.cardItemBorder(
    borderColor: Color = SdkTheme.colors.neutral20
) = this.then(
    Modifier.border(
        width = dimensionResource(R.dimen.spacing_1),
        color = borderColor,
        shape = RoundedCornerShape(dimensionResource(R.dimen.spacing_8))
    )
)


internal fun Modifier.shimmerEffect(
    shape: Shape = RectangleShape,
    shimmerColor: Color = Color.LightGray.copy(alpha = 0.3f),
    backgroundColor: Color = Color.LightGray.copy(alpha = 0.1f)
): Modifier = composed {
    val transition = rememberInfiniteTransition()
    val shimmerTranslate by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    val brush = Brush.linearGradient(
        colors = listOf(backgroundColor, shimmerColor, backgroundColor),
        start = Offset(x = shimmerTranslate - 1000f, y = 0f),
        end = Offset(x = shimmerTranslate, y = 0f)
    )

    this
        .clip(shape)
        .background(brush)
}