package net.geidea.sdk.core.utils.extensions

import java.time.Month
import java.time.format.TextStyle
import java.util.Locale

fun Month.getDisplayName(locale: Locale = Locale.getDefault()): String {
    return this.getDisplayName(TextStyle.FULL, locale)
}