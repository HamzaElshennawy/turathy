package net.geidea.sdk.core.di

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.viewModel

// Extension functions for reified types
internal inline fun <reified T : Any> DependencyContainer.registerFactory(
    key: String? = null,
    noinline factory: () -> T
) = registerFactory(T::class, key, factory)

internal inline fun <reified T : Any> DependencyContainer.registerSingleton(
    key: String? = null,
    noinline factory: () -> T
) = registerSingleton(T::class, key, factory)

internal inline fun <reified T : ViewModel> DependencyContainer.registerViewModel(
    key: String? = null,
    noinline factory: () -> T
) = registerViewModel(T::class, key, factory)

private inline fun <reified T : ViewModel> DependencyContainer.getViewModel(
    viewModelStoreOwner: ViewModelStoreOwner,
    key: String? = null
): T = getViewModel(T::class, viewModelStoreOwner, key)

private inline fun <reified T : Any> DependencyContainer.get(key: String? = null): T =
    get(T::class, key)

@Composable
internal inline fun <reified T : Any> injectComposable(key: String? = null): T {
    val container = LocalDependencyContainer.current
    return remember(key) { container.get<T>(key) }
}

internal inline fun <reified T : Any> inject(key: String? = null): T {
    return DependencyContainer.getInstance().get(T::class, key)
}

@Composable
internal inline fun <reified T : ViewModel> injectViewModel(
    key: String? = null,
    viewModelStoreOwner: ViewModelStoreOwner? = null
): T {
    val container = LocalDependencyContainer.current

    return viewModelStoreOwner?.let { owner ->
        remember(key) { container.getViewModel<T>(owner, key) }
    } ?: run {
        val factory = remember(key) {
            val keyName = key ?: T::class.java.name
            val vmFactory = container.getViewModelFactory(keyName)
                ?: throw IllegalArgumentException("No ViewModel factory registered for $keyName")
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <VM : ViewModel> create(modelClass: Class<VM>): VM = vmFactory() as VM
            }
        }
        viewModel<T>(factory = factory)
    }
}

internal inline fun createDependencyContainer(block: DependencyContainer.() -> Unit = {}) =
    DependencyContainer.getInstance().apply(block)

// Composable functions
private val LocalDependencyContainer = compositionLocalOf<DependencyContainer> {
    error("DependencyContainer not provided")
}

@Composable
internal fun ProvideDependencies(
    container: DependencyContainer,
    content: @Composable () -> Unit
) = CompositionLocalProvider(LocalDependencyContainer provides container, content = content)