package net.geidea.sdk.presentation.features.cardscan.ml

import android.content.Context
import androidx.annotation.RestrictTo
import net.geidea.sdk.presentation.features.cardscan.ml.base.InterpreterInitializer

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
object InterpreterInitializerImpl : InterpreterInitializer {
    override fun initialize(
        context: Context,
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        onSuccess()
    }
}