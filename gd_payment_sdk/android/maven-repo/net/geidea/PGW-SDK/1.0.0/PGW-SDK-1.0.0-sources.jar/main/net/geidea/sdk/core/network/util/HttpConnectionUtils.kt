package net.geidea.sdk.core.network.util


import net.geidea.sdk.core.network.client.HttpMethod
import net.geidea.sdk.core.network.response.BaseResponse
import org.json.JSONException
import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.nio.charset.StandardCharsets


internal object HttpConnectionUtils {

    internal fun <T> setupAndExecute(
        connection: HttpURLConnection,
        method: HttpMethod,
        body: JSONObject?,
        headers: Map<String, String>,
        connectTimeout: Int,
        readTimeout: Int,
        networkInterceptor: NetworkInterceptor?,
        url: String,
        mapper: (String) -> T,
        language: String = "en",
    ): BaseResponse<T> {
        connection.apply {
            this.connectTimeout = connectTimeout
            this.readTimeout = readTimeout
            requestMethod = method.name
            doInput = true
            doOutput = body != null
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }

        networkInterceptor?.onRequest(url, method, headers, body?.toString())
        if (body != null) writeRequestBody(connection, body)

        return parseResponse(connection, mapper, language, networkInterceptor)
    }

    private fun writeRequestBody(connection: HttpURLConnection, jsonBody: JSONObject) {
        connection.outputStream.bufferedWriter(StandardCharsets.UTF_8)
            .use { it.write(jsonBody.toString()) }
    }

    private fun <T> parseResponse(
        connection: HttpURLConnection,
        mapper: (String) -> T,
        language: String = "en",
        networkInterceptor: NetworkInterceptor?,
    ): BaseResponse<T> {
        val code = connection.responseCode
        val headers = connection.headerFields.filterKeys { it != null }
        val body = readResponseBody(connection, code)

        networkInterceptor?.onResponse(code, "Headers: $headers \n Body: $body")


        when (code) {
            403 -> throw NetworkException.Forbidden
            404 -> throw NetworkException.NotFound
            in 400..599 -> throw NetworkException.GeneralError(code, body)
        }

        if (body.isNullOrBlank()) {
            throw NetworkException.GeneralError(
                code,
                if (language == "en") "Your request couldn't be completed" else "حدث خطأ"
            )
        }

        return if (isValidJsonObject(body)) {
            parseJsonBody(body, code, headers, mapper)
        } else {
            parsePlainBody(body, code, headers, mapper)
        }
    }

    private fun readResponseBody(connection: HttpURLConnection, code: Int): String? {
        return try {
            val stream: InputStream =
                if (code in 200..299) connection.inputStream else connection.errorStream
            stream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    private fun <T> parseJsonBody(
        body: String,
        code: Int,
        headers: Map<String, List<String>>,
        mapper: (String) -> T
    ): BaseResponse<T> {
        val json = JSONObject(body)
        val backendCode = json.optString("responseCode", "")
        val message = json.optString("responseMessage", "")
        val detailedMessage = json.optString("detailedResponseMessage", "")

        return if (backendCode == "000") {
            BaseResponse.Success(
                mapper(body),
                code,
                headers,
                backendCode,
                message,
                detailedMessage
            )
        } else if (backendCode == "210") {
            throw NetworkException.Unauthorized(
                message,
                detailedMessage
            )
        } else {
            throw NetworkException.BusinessError(
                backendCode,
                message,
                detailedMessage,
            )
        }
    }

    private fun <T> parsePlainBody(
        body: String,
        code: Int,
        headers: Map<String, List<String>>,
        mapper: (String) -> T
    ): BaseResponse<T> =
        runCatching { mapper(body) }
            .fold(
                onSuccess = { BaseResponse.Success(it, code, headers) },
                onFailure = { BaseResponse.Failure(code, headers) }
            )

    private fun isValidJsonObject(body: String): Boolean {
        return try {
            JSONObject(body)
            true
        } catch (e: JSONException) {
            false
        }
    }
}
