package net.geidea.sdk.core.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme

@Composable
internal fun ReceiptDetailsItemComponent(key: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = dimensionResource(R.dimen.spacing_8)),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {

        Text(
            text = key,
            style = SdkTheme.typography.regular14,
            color = SdkTheme.colors.neutral300
        )
        Spacer(modifier = Modifier.width(dimensionResource(R.dimen.spacing_8)))
        Text(
            text = value,
            style = SdkTheme.typography.medium14,
            color = SdkTheme.colors.neutral700
        )
    }
}