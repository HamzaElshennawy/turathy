package net.geidea.sdk.presentation.features.cardscan.screen

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import net.geidea.sdk.core.di.injectViewModel
import net.geidea.sdk.core.ui.BaseScreen
import net.geidea.sdk.core.utils.extensions.navigateToAppSettings
import net.geidea.sdk.presentation.features.cardscan.ScannedCardResult
import net.geidea.sdk.presentation.features.cardscan.component.CardScannerPreview
import net.geidea.sdk.presentation.features.cardscan.component.PermissionRationaleDialog
import net.geidea.sdk.presentation.features.cardscan.viewmodel.CardScanEffect
import net.geidea.sdk.presentation.features.cardscan.viewmodel.CardScanEvent
import net.geidea.sdk.presentation.features.cardscan.viewmodel.CardScanViewModel
import net.geidea.sdk.sdk.GDPaymentSDK

@Composable
internal fun CardScanScreen(
    onCardScanned: (ScannedCardResult) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: CardScanViewModel = injectViewModel<CardScanViewModel>()
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.sendEvent(CardScanEvent.PermissionResult(isGranted))
    }

    BaseScreen(viewModel = viewModel, onEffect = { effect ->
        when (effect) {
            is CardScanEffect.RequestPermission -> {
                permissionLauncher.launch(Manifest.permission.CAMERA)
            }

            is CardScanEffect.CardScanned -> {
                onCardScanned(effect.result)
            }

            is CardScanEffect.Close -> {
                onDismiss()
            }

            is CardScanEffect.NavigateToAppSetting -> {
                GDPaymentSDK.sharedInstance().getContext().navigateToAppSettings()
            }
        }
    }, content = { state ->
        // Request permission on first composition
        LaunchedEffect(Unit) {
            viewModel.sendEvent(CardScanEvent.RequestCameraPermission)
        }
        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    val granted = ContextCompat.checkSelfPermission(
                        GDPaymentSDK.sharedInstance().getContext(),
                        Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_GRANTED

                    viewModel.sendEvent(CardScanEvent.OnReturnFromAppSetting(granted))
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        when {
            state.hasPermission -> {

//                CardScannerPreview(
//                    state = state,
//                    onEvent = viewModel::sendEvent,
//                    modifier = modifier
//                )
            }

            state.showPermissionRationale -> {
                PermissionRationaleDialog(
                    onGrantPermission = {
                        viewModel.sendEvent(CardScanEvent.AcceptRationalDialog)
                    },
                    onDismiss = {
                        viewModel.sendEvent(CardScanEvent.DismissPermissionRationale)
                    }
                )
            }

            else -> {
                Box(
                    modifier = modifier
                        .fillMaxSize()
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = Color.Cyan)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "Requesting camera permission...",
                            color = Color.White,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

    })
}



