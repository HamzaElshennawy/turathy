package net.geidea.sdk.core.ui.validation.validators

import net.geidea.sdk.R
import net.geidea.sdk.core.ui.validation.ValidationResult
import net.geidea.sdk.core.ui.validation.Validator
import net.geidea.sdk.core.utils.constants.Constants

internal class NameValidator : Validator {
    override fun validate(value: String): ValidationResult {
        if (value.isBlank()) {
            return ValidationResult(false, R.string.field_required)
        }

        if (!Regex(Constants.Regex.NAME_VALIDATION).matches(value)) {
            return ValidationResult(false, R.string.invalid_input)
        }

        return ValidationResult(true)
    }
}