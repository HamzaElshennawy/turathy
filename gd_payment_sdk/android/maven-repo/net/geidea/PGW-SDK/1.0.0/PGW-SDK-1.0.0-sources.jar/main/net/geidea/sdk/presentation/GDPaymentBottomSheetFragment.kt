package net.geidea.sdk.presentation

import android.app.Dialog
import android.content.DialogInterface
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toDrawable
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import net.geidea.sdk.sdk.GDPaymentSDK

class GDPaymentBottomSheetFragment : BottomSheetDialogFragment() {
    companion object {
        const val TAG = "PaymentBottomSheetFragment"
        private const val ARG_MAX_HEIGHT = "max_height"

        fun newInstance(maxHeightDp: Float? = null): GDPaymentBottomSheetFragment {
            return GDPaymentBottomSheetFragment().apply {
                arguments = Bundle().apply {
                    maxHeightDp?.let { putFloat(ARG_MAX_HEIGHT, it) }
                }
            }
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = BottomSheetDialog(requireContext(), theme)
        dialog.setOnShowListener { d ->
            val bsd = d as BottomSheetDialog
            val sheet =
                bsd.findViewById<FrameLayout>(com.google.android.material.R.id.design_bottom_sheet)
                    ?: return@setOnShowListener

            // 1) Make the system sheet container fully transparent so rounded corners show correctly
            sheet.setBackgroundColor(Color.TRANSPARENT)
            (sheet.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
            bsd.window?.setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
        }
        return dialog
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setContent {
                Surface(
                    shape = RoundedCornerShape(
                        topStart = 24.dp, topEnd = 24.dp
                    ),
                    tonalElevation = 3.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        .clip(
                            shape = RoundedCornerShape(
                                topStart = 24.dp, topEnd = 24.dp
                            )
                        )
                ) {
                    GDPaymentSDKCompose()

                }
            }
        }
    }

    override fun onStart() {
        super.onStart()

        val dialog = dialog as? BottomSheetDialog
        val bottomSheet =
            dialog?.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)

        bottomSheet?.let {
            val behavior = BottomSheetBehavior.from(it)

            // allow user to drag it to full screen
            behavior.isFitToContents = true
            behavior.isDraggable = true
            behavior.peekHeight = BottomSheetBehavior.PEEK_HEIGHT_AUTO
            behavior.skipCollapsed = false

            // start collapsed but user can expand
            behavior.state = BottomSheetBehavior.STATE_COLLAPSED

            // optional: make it match parent height for full-screen drag
            it.layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT
        }
    }

    override fun onDismiss(dialog: DialogInterface) {
        GDPaymentSDK.sharedInstance().onPaymentCanceled()
        super.onDismiss(dialog)
    }
}