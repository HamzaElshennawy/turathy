package net.geidea.sdk.presentation.features.paymentdetails.components.card.savedcard

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import kotlinx.collections.immutable.PersistentList
import kotlinx.collections.immutable.persistentListOf
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.CardUiModel
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent

@Immutable
@Stable
internal data class SavedCardsState(
    internal val cards: PersistentList<CardUiModel> = persistentListOf(),
    internal val selectedCard: CardUiModel? = null,
    internal val showAddNewCardRow: Boolean = true,
    internal val showCardSelectionError: Boolean = false,
    internal val showCvvError: Boolean = false
) {
    @Stable
    internal fun isSelected(cardId: String) = selectedCard?.id == cardId
}

internal sealed interface SavedCardEvent : PaymentEvent {
    data class CardSelected(internal val card: CardUiModel) : SavedCardEvent
    data object AddNewCard : SavedCardEvent
    data class CVVChanged(internal val cardId: String, internal val cvv: String) : SavedCardEvent
    data object ValidateCardSelection : SavedCardEvent
}
