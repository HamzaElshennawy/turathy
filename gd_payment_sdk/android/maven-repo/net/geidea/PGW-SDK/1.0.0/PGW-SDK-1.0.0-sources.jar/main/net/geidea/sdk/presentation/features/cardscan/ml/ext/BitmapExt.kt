package net.geidea.sdk.presentation.features.cardscan.ml.ext

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Size
import androidx.annotation.CheckResult
import androidx.annotation.RestrictTo
import net.geidea.sdk.presentation.features.cardscan.ml.image.MLImage

/**
* Crop a [Bitmap] to a given [Rect]. The crop must have a positive area and must be contained
* within the bounds of the source [Bitmap].
*/
@CheckResult
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun Bitmap.crop(crop: Rect): Bitmap {
    require(crop.left < crop.right && crop.top < crop.bottom) { "Cannot use negative crop" }
    require(
        crop.left >= 0 &&
                crop.top >= 0 &&
                crop.bottom <= this.height &&
                crop.right <= this.width
    ) {
        "Crop is larger than source image"
    }
    return Bitmap.createBitmap(this, crop.left, crop.top, crop.width(), crop.height())
}

/**
 * Scale a [Bitmap] by a given [percentage].
 */
@CheckResult
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun Bitmap.scale(size: Size, filter: Boolean = false): Bitmap =
    if (size.width == width && size.height == height) {
        this
    } else {
        Bitmap.createScaledBitmap(this, size.width, size.height, filter)
    }

/**
 * Get the size of a [Bitmap].
 */
@CheckResult
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun Bitmap.size() = Size(this.width, this.height)

/**
 * Convert a [Bitmap] to an [MLImage] for use in ML models.
 */
@CheckResult
internal fun Bitmap.toMLImage(mean: Float = 0F, std: Float = 255F) = MLImage(this, mean, std)