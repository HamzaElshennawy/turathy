package net.geidea.sdk.core.mvi

import androidx.annotation.StringRes
import net.geidea.sdk.R


internal interface ViewState {
    val isLoading: Boolean
    val errorEvent: ErrorEvent?
        get() = null

    val isFullScreenError: Boolean
        get() = false

    val isOverlayError: Boolean
        get() = false
}

internal interface ViewEvent {
    object ClearError : ViewEvent
    object ClearOvelayError : ViewEvent
}

internal sealed class ErrorEvent : ViewEvent {
    internal abstract val messageRes: Int
    internal abstract val responseMessage: String?
    internal abstract val detailedResponseMessage: String?

    internal data class BusinessError(
        val code: String? = null,
        override val responseMessage: String?,
        override val detailedResponseMessage: String?,
        @StringRes override val messageRes: Int = R.string.general_error
    ) : ErrorEvent()

    internal data class GeneralError(
        @StringRes override val messageRes: Int = R.string.general_error,
        val code: String? = null,
        override val responseMessage: String? = null,
        override val detailedResponseMessage: String? = null
    ) : ErrorEvent()

    internal data class Unauthorized(
        @StringRes override val messageRes: Int = R.string.unauthorized_error,
        override val responseMessage: String? = null,
        override val detailedResponseMessage: String? = null
    ) : ErrorEvent()

    internal data class Forbidden(
        @StringRes override val messageRes: Int = R.string.forbidden_error,
        override val responseMessage: String? = null,
        override val detailedResponseMessage: String? = null
    ) : ErrorEvent()

    internal data class NotFound(
        @StringRes override val messageRes: Int = R.string.not_found_error,
        override val responseMessage: String? = null,
        override val detailedResponseMessage: String? = null
    ) : ErrorEvent()

    internal data class HttpError(
        val code: Int?,
        override val responseMessage: String?,
        override val detailedResponseMessage: String?,
        @StringRes override val messageRes: Int = R.string.general_error
    ) : ErrorEvent()
}

internal interface BaseEffect
