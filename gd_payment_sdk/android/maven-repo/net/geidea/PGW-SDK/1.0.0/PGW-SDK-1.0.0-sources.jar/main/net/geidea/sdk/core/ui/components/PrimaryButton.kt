package net.geidea.sdk.core.ui.components

import androidx.annotation.DimenRes
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.utils.extensions.conditional

@Composable
internal fun PrimaryButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
    enabled: Boolean = true,
    @DimenRes cornerRadius: Int = R.dimen.primary_button_corner_radius,
    @DimenRes elevation: Int = R.dimen.primary_button_corner_radius,
    content: @Composable () -> Unit
) {
    Button(
        modifier = modifier,
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        contentPadding = PaddingValues(),
        shape = RoundedCornerShape(dimensionResource(cornerRadius)),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = dimensionResource(id = elevation))
    ) {
        content.invoke()
    }
}

@Composable
internal fun PrimaryButtonColor(
    modifier: Modifier = Modifier,
    @StringRes text: Int,
    onClick: () -> Unit = {},
    textColor: Color = SdkTheme.colors.alwaysWhite,
    textStyle: TextStyle = SdkTheme.typography.semibold16,
    color: Color = SdkTheme.colors.primary,
    @DimenRes cornerRadius: Int = R.dimen.primary_button_corner_radius,
    @DimenRes elevation: Int = R.dimen.primary_button_default_elevation,
    @DimenRes verticalPadding: Int = R.dimen.primary_button_vertical_padding,
    @DimenRes horizontalPadding: Int = R.dimen.primary_button_horizontal_padding,
    hasBorder: Boolean = false,
    enabled: Boolean = true,
    loading: Boolean = false,
    borderColor: Color = SdkTheme.colors.transparent
) {
    PrimaryButton(
        modifier = modifier,
        onClick = onClick,
        elevation = elevation,
        cornerRadius = cornerRadius,
        enabled = !loading,
    ) {
        Box(
            modifier = Modifier
                .conditional(hasBorder) {
                    border(
                        width = dimensionResource(R.dimen.spacing_1),
                        color = borderColor,
                        shape = RoundedCornerShape(dimensionResource(R.dimen.primary_button_corner_radius))
                    )
                }
                .background(color)
                .fillMaxWidth()
                .padding(
                    vertical = dimensionResource(verticalPadding),
                    horizontal = dimensionResource(horizontalPadding)
                ),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(text),
                color = textColor,
                style = textStyle
            )
        }
    }
}