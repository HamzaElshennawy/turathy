package net.geidea.sdk.presentation.features.cardscan.viewmodel

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import net.geidea.sdk.core.mvi.BaseEffect
import net.geidea.sdk.core.mvi.ErrorEvent
import net.geidea.sdk.core.mvi.ViewEvent
import net.geidea.sdk.core.mvi.ViewState
import net.geidea.sdk.presentation.features.cardscan.ScannedCardData
import net.geidea.sdk.presentation.features.cardscan.ScannedCardResult

@Immutable
@Stable
internal data class CardScanState(
    override val isLoading: Boolean = false,
    override val errorEvent: ErrorEvent? = null,
    internal val isScanning: Boolean = false,
    internal val isProcessing: Boolean = false,
    internal val isFlashOn: Boolean = false,
    internal val hasPermission: Boolean = false,
    internal val showPermissionRationale: Boolean = false,
    internal val scannedCard: ScannedCardData? = null,
    internal val animationProgress: Float = 0f,
    internal val isAnimating: Boolean = false,
    internal val hasScannedCard: Boolean = false,
    internal var lastAnalysisTime: Long = 0L,
) : ViewState


internal sealed class CardScanEvent : ViewEvent {
    internal data object StartScanning : CardScanEvent()
    internal data object StopScanning : CardScanEvent()
    internal data object ToggleFlashOn : CardScanEvent()
    internal data object ToggleFlashOff : CardScanEvent()
    internal data object RequestCameraPermission : CardScanEvent()
    internal data object DismissPermissionRationale : CardScanEvent()

    internal data object AcceptRationalDialog : CardScanEvent()

    internal data class OnReturnFromAppSetting(internal val granted: Boolean) : CardScanEvent()
    internal data class CardDetected(internal val cardData: ScannedCardData) : CardScanEvent()
    internal data class PermissionResult(internal val granted: Boolean) : CardScanEvent()

    data class ProcessingStateChanged(internal val isProcessing: Boolean) : CardScanEvent()
    internal data object Close : CardScanEvent()

}

internal sealed interface CardScanEffect : BaseEffect {
    data object RequestPermission : CardScanEffect
    data class CardScanned(val result: ScannedCardResult) : CardScanEffect

    data object NavigateToAppSetting : CardScanEffect
    data object Close : CardScanEffect
}
