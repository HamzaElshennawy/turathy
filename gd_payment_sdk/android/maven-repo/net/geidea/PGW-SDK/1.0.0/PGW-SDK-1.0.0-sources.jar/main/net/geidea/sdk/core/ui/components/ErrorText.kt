package net.geidea.sdk.core.ui.components

import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme


@Composable
internal fun ErrorText(
    modifier: Modifier = Modifier, @StringRes errorMessageRes: Int,
    errorStyle: TextStyle = SdkTheme.typography.medium12.copy(
        color = SdkTheme.colors.danger700
    ),
) {
    ErrorText(
        modifier = modifier, errorMessage = stringResource(errorMessageRes), errorStyle = errorStyle
    )
}


@Composable
internal fun ErrorText(
    modifier: Modifier = Modifier, errorMessage: String,
    errorStyle: TextStyle = SdkTheme.typography.medium12.copy(
        color = SdkTheme.colors.danger700
    ),
) {
    Row(
        verticalAlignment = Alignment.CenterVertically, modifier = modifier.padding(
            vertical = dimensionResource(R.dimen.primary_textfield_error_vertical_padding)
        )
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_error_message),
            contentDescription = stringResource(R.string.error_message),
        )
        Text(
            text = errorMessage, style = errorStyle, modifier = Modifier.padding(
                start = dimensionResource(R.dimen.primary_textfield_horizontal_padding)
            )
        )
    }
}

