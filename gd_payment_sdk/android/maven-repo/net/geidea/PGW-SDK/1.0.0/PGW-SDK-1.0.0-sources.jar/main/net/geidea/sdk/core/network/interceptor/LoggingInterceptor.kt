package net.geidea.sdk.core.network.interceptor

import android.util.Log
//import net.geidea.networklogging.NetworkLogger
//import net.geidea.networklogging.logging.LoggedRequest
import net.geidea.sdk.BuildConfig
import net.geidea.sdk.core.network.client.HttpMethod
import net.geidea.sdk.core.network.util.NetworkInterceptor


internal class LoggingInterceptor : NetworkInterceptor {
    //private var lastRequest: LoggedRequest? = null
    override fun onRequest(
        url: String,
        method: HttpMethod,
        headers: Map<String, String>,
        body: String?
    ) {

//        if (BuildConfig.DEBUG) {
//            Log.d("HttpClient", "➡️ $method $url")
//            Log.d("HttpClient", "Headers: $headers")
//            if (body != null) Log.d("HttpClient", "Body: $body")
//            lastRequest = LoggedRequest(url, method.name, headers, body)
//        }
    }

    override fun onResponse(code: Int, body: String?) {
//        if (BuildConfig.DEBUG) {
//            Log.d("HttpClient", "⬅️ Code: $code")
//            Log.d("HttpClient", "Response: $body")
//            lastRequest?.let { req ->
//                NetworkLogger.logRequest(
//                    url = req.url,
//                    headers = req.headers,
//                    body = req.body,
//                    responseCode = code,
//                    responseBody = body
//                )
//            }
//            lastRequest = null
//        }
    }
}
