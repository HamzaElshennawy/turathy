package net.geidea.sdk.presentation.features.paymentdetails.components.card.carddetails

import net.geidea.sdk.presentation.features.cardscan.ScannedCardData
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent


internal sealed interface CardDetailsEvent : PaymentEvent {

    data class CardNumberChanged(internal val value: String) : CardDetailsEvent
    data class ExpiryDateChanged(internal val value: String) : CardDetailsEvent
    data class CvvChanged(internal val value: String) : CardDetailsEvent
    data class CardNameChanged(internal val value: String) : CardDetailsEvent
    data class CardSavedChanged(internal val isCardSaved: Boolean) : CardDetailsEvent

    data class ShowDatePickerChanged(internal val show: Boolean) : CardDetailsEvent

    data object ValidateAllFields : CardDetailsEvent
    data class CardScanned(internal val cardData: ScannedCardData) : CardDetailsEvent
}