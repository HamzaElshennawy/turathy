package net.geidea.sdk.domain.model.pay

import org.json.JSONObject

internal data class PayRequest(
    internal val threeDSecureId: String? = null,
    internal val orderId: String? = null,
    internal val paymentMethod: PaymentMethod? = null,
    internal val sessionId: String? = null,
    internal val source: String? = null
) {
    internal fun toJson(): JSONObject {
        val json = JSONObject()
        threeDSecureId?.let { json.put("threeDSecureId", it) }
        orderId?.let { json.put("orderId", it) }
        paymentMethod?.let { json.put("paymentMethod", it.toJson()) }
        sessionId?.let { json.put("sessionId", it) }
        source?.let { json.put("source", it) }
        return json
    }
}