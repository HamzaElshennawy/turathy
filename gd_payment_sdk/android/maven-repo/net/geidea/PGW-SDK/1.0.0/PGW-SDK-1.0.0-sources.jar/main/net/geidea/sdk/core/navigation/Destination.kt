package net.geidea.sdk.core.navigation

import androidx.navigation.NavType
import androidx.navigation.navArgument
import net.geidea.sdk.core.utils.constants.Constants

internal sealed class Destination(
    protected val route: String,
    vararg arguments: String
) {

    internal val fullRoute = if (arguments.isEmpty()) route else {
        val builder = StringBuilder(route)
        arguments.forEach { builder.append("/{${it}}") }
        builder.toString()
    }

    internal data object CardDetailsScreen : Destination(route = "cardDetailsScreen")

    internal data object CardScanScreen : Destination(route = "cardScanScreen")

    internal data object ReceiptScreen : Destination(route = "receiptScreen")

    internal data object OTPScreen : Destination(
        route = "OTPScreen",
        Constants.DestinationArgs.AUTH_RESPONSE,
        Constants.DestinationArgs.CARD_DETAILS,
    ) {
        val args
            get() = listOf(
                navArgument(Constants.DestinationArgs.AUTH_RESPONSE) {
                    type = NavType.StringType
                },
                navArgument(Constants.DestinationArgs.CARD_DETAILS) {
                    type = NavType.StringType
                },
            )
    }

    internal fun withArgs(vararg args: Pair<String, Any?>): String {
        return buildString {
            append(route)
            args.forEach { append("/${it.second}") }
        }
    }
}