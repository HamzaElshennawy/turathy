package net.geidea.sdk.core.network.util


import java.net.URLEncoder

internal object UrlUtils {
    internal fun buildUrlWithParams(base: String, params: Map<String, String>): String {
        if (params.isEmpty()) return base
        val query = params.entries.joinToString("&") {
            "${URLEncoder.encode(it.key, "UTF-8")}=${URLEncoder.encode(it.value, "UTF-8")}"
        }
        return if (base.contains('?')) "$base&$query" else "$base?$query"
    }
}
