package net.geidea.sdk.domain.model.pay

import net.geidea.sdk.core.network.response.BaseResponse
import net.geidea.sdk.core.utils.extensions.optStringOrNull
import org.json.JSONObject


internal typealias GetPerformAuthenticateResponse = BaseResponse<PerformAuthenticateResponse>

internal data class PerformAuthenticateResponse(
    internal val gatewayDecision: String? = null,
    internal val orderId: String? = null,
    internal val detailedResponseCode: String? = null,
    internal val htmlBodyContent: String? = null,
    internal val language: String? = null,
    internal val detailedResponseMessage: String? = null,
    internal val threeDSecureId: String? = null,
    internal val responseMessage: String? = null,
    internal val responseCode: String? = null
)

internal fun mapPerformAuthenticateResponse(jsonString: String): PerformAuthenticateResponse {
    val performAuthenticateJSON = JSONObject(jsonString)
    return PerformAuthenticateResponse(
        gatewayDecision = performAuthenticateJSON.optStringOrNull("gatewayDecision"),
        orderId = performAuthenticateJSON.optStringOrNull("orderId"),
        detailedResponseCode = performAuthenticateJSON.optStringOrNull("detailedResponseCode"),
        htmlBodyContent = performAuthenticateJSON.optStringOrNull("htmlBodyContent"),
        language = performAuthenticateJSON.optStringOrNull("language"),
        detailedResponseMessage = performAuthenticateJSON.optStringOrNull("detailedResponseMessage"),
        threeDSecureId = performAuthenticateJSON.optStringOrNull("threeDSecureId"),
        responseMessage = performAuthenticateJSON.optStringOrNull("responseMessage"),
        responseCode = performAuthenticateJSON.optStringOrNull("responseCode")
    )
}

internal fun PerformAuthenticateResponse.toJson(): String {
    return JSONObject().apply {
        put("gatewayDecision", gatewayDecision)
        put("orderId", orderId)
        put("detailedResponseCode", detailedResponseCode)
        put("htmlBodyContent", htmlBodyContent)
        put("language", language)
        put("detailedResponseMessage", detailedResponseMessage)
        put("threeDSecureId", threeDSecureId)
        put("responseMessage", responseMessage)
        put("responseCode", responseCode)
    }.toString()
}