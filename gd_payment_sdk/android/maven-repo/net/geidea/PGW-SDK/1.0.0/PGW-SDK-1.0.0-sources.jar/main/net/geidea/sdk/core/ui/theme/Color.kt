package net.geidea.sdk.core.ui.theme

import androidx.compose.ui.graphics.Color

internal val Black300 = Color(0xFF323242)
internal val Black700 = Color(0xFF21212E)
internal val Black900 = Color(0xFF0E0E14)

internal val Grey10 = Color(0xFFF5F5F6)
internal val Grey30 = Color(0xFF9C9CAD)
internal val Grey20 = Color(0xFFE6E6EB)
internal val Grey80 = Color(0xFF7B7B8F)
internal val Grey100 = Color(0xFF5E5E73)

internal val Blue900 = Color(0xFF0036FF)

internal val Orange700 = Color(0xFFFF4D00)
internal val PrimaryBlue = Color(0xFF007AFF)
internal val Red700 = Color(0xFFD32323)

internal val White = Color(0xFFFFFFFF)

internal val Gradient1A = Color(0xFFFF4D00)

