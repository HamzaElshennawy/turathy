package net.geidea.sdk.domain.repository

import kotlinx.coroutines.flow.Flow
import net.geidea.sdk.core.network.response.BaseResponse
import net.geidea.sdk.domain.model.pay.GetPerformAuthenticateResponse
import net.geidea.sdk.domain.model.pay.PayRequest
import net.geidea.sdk.domain.model.pay.PayResponse
import net.geidea.sdk.domain.model.pay.PerformAuthRequest
import net.geidea.sdk.domain.model.paymentdetails.PaymentConfigResponse

internal interface PaymentRepository {
    fun getMerchantConfigurationDetails(): Flow<BaseResponse<PaymentConfigResponse>>
    fun performAuthentication(request: PerformAuthRequest): Flow<GetPerformAuthenticateResponse>
    fun pay(request: PayRequest): Flow<PayResponse>
}