package net.geidea.sdk.core.utils.extensions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings


internal fun Context.navigateToAppSettings() {
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = Uri.fromParts("package", packageName, null)
        startActivity(this)
    }
}