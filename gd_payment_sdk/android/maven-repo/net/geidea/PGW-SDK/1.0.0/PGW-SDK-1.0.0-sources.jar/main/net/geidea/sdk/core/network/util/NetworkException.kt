package net.geidea.sdk.core.network.util


internal sealed class NetworkException(message: String? = null) : Exception(message) {

    internal object Forbidden : NetworkException("Forbidden (403)")
    internal object NotFound : NetworkException("Not Found (404)")
    internal object Timeout : NetworkException("Request Timeout")
    internal object NoInternet : NetworkException("No Internet Connection")

    internal data class GeneralError(
        internal val code: Int,
        internal val messageBody: String?
    ) : NetworkException(messageBody)

    internal data class BusinessError(
        internal val backendCode: String?,
        internal val responseMessage: String?,
        internal val detailedResponseMessage: String?,
    ) : NetworkException(responseMessage)

    internal data class Unauthorized(
        internal val responseMessage: String?,
        internal val detailedResponseMessage: String?,
    ) : NetworkException(responseMessage)
}
