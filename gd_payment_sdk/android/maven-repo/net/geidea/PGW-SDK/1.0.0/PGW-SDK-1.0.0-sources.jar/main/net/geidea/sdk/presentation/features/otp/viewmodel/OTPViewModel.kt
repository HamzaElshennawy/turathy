package net.geidea.sdk.presentation.features.otp.viewmodel

import net.geidea.sdk.R
import net.geidea.sdk.core.mvi.BaseViewModel
import net.geidea.sdk.core.mvi.ErrorEvent
import net.geidea.sdk.core.mvi.ViewEvent
import net.geidea.sdk.core.utils.extensions.parseQueryParams
import net.geidea.sdk.domain.model.otp.ReturnUrlParams
import net.geidea.sdk.presentation.features.otp.viewmodel.OTPEffect.NavigateBack
import java.net.URLDecoder

internal class OTPViewModel(
) : BaseViewModel<OTPState, OTPEvent, OTPEffect>() {

    override fun createInitialState(): OTPState = OTPState()


    override fun handleEvent(event: ViewEvent) {
        when (event) {
            is OTPEvent.OnReturnUrl -> handleReturnUrl(event.url)
            is OTPEvent.OnProgressChanged -> updateProgress(event.progress)
            is OTPEvent.OnPageStarted -> setState { copy(showProgressBar = true) }
            is OTPEvent.OnPageFinished -> setState { copy(showProgressBar = false) }
            is OTPEvent.OnWebError -> handleWebError(event.error)
            is OTPEvent.OnBackPressed -> emitEffect(NavigateBack())
            is OTPEvent.OnScreenInit -> {
                setState {
                    copy(
                        authResponse = event.authResponse,
                        cardDetails = event.cardDetails,
                    )
                }
            }

            is ViewEvent.ClearError -> {
                setState {
                    copy(
                        errorEvent = null,
                        isFullScreenError = false,
                        isOverlayError = false,
                    )
                }
                emitEffect(NavigateBack())
            }
        }
    }

    private fun handleReturnUrl(url: String) {
        val urlParams = parseUrlResult(url)
        if (urlParams.isSuccess) {
            handleSuccessReturnUrl()
        } else {
            handleFailureReturnUrl(urlParams)
        }
    }

    private fun handleSuccessReturnUrl() {
        emitEffect(OTPEffect.NavigateBackToPay)
    }

    private fun handleFailureReturnUrl(urlParams: ReturnUrlParams) {
        val errorEvent = ErrorEvent.BusinessError(
            messageRes = R.string.general_error,
            responseMessage = null,
            code = urlParams.code,
            detailedResponseMessage = urlParams.msg,
        )

        setState {
            copy(
                paymentSucceeded = false,
                isLoading = false,
                errorEvent = errorEvent,
                isOverlayError = true,
            )
        }
    }

    private fun updateProgress(progress: Int) {
        setState {
            copy(
                webViewProgress = progress,
                showProgressBar = progress < 100
            )
        }
    }

    private fun handleWebError(error: String) {
        val errorEvent = ErrorEvent.GeneralError(
            messageRes = R.string.general_error,
            responseMessage = error
        )

        setState {
            copy(
                errorEvent = errorEvent,
                isLoading = false,
                isOverlayError = true
            )
        }
    }


    private fun parseUrlResult(url: String): ReturnUrlParams {
        val queryPairs: List<Pair<String, String>> = url.parseQueryParams()

        val codePair = queryPairs.firstOrNull { it.first == "code" }
        val msgPair = queryPairs.firstOrNull { it.first == "msg" }
        val orderIdPair = queryPairs.firstOrNull { it.first == "orderId" }

        return ReturnUrlParams(
            code = codePair?.second?.let { URLDecoder.decode(it, "UTF-8") },
            msg = msgPair?.second?.let { URLDecoder.decode(it, "UTF-8") },
            orderId = orderIdPair?.second?.let { URLDecoder.decode(it, "UTF-8") }
        )
    }
}