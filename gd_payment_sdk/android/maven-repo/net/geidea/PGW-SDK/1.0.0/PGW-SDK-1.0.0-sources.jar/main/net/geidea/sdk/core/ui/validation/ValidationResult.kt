package net.geidea.sdk.core.ui.validation

import androidx.annotation.StringRes
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Immutable
@Stable
internal data class ValidationResult(
    internal val isValid: Boolean,
    @StringRes internal val message: Int? = null
)