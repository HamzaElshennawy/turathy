package net.geidea.sdk.presentation.features.cardscan.screen.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PointF
import android.os.Bundle
import android.util.Log
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.activity.addCallback
import androidx.annotation.RestrictTo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import net.geidea.sdk.R
import net.geidea.sdk.databinding.StripeActivityCardscanBinding
import net.geidea.sdk.presentation.features.cardscan.camera.CameraPreviewImage
import net.geidea.sdk.presentation.features.cardscan.camera.getScanCameraAdapter
import net.geidea.sdk.presentation.features.cardscan.card.ScannedCard
import net.geidea.sdk.presentation.features.cardscan.exception.UnknownScanException
import net.geidea.sdk.presentation.features.cardscan.result.MainLoopAggregator
import net.geidea.sdk.presentation.features.cardscan.result.MainLoopState
import net.geidea.sdk.presentation.features.cardscan.scanui.ScanErrorListener
import net.geidea.sdk.presentation.features.cardscan.scanui.ScanState
import net.geidea.sdk.presentation.features.cardscan.scanui.SimpleScanStateful
import net.geidea.sdk.presentation.features.cardscan.scanui.util.ViewFinderBackground
import net.geidea.sdk.presentation.features.cardscan.scanui.util.asRect
import net.geidea.sdk.presentation.features.cardscan.scanui.util.getColorByRes
import net.geidea.sdk.presentation.features.cardscan.scanui.util.hide
import net.geidea.sdk.presentation.features.cardscan.scanui.util.setDrawable
import net.geidea.sdk.presentation.features.cardscan.scanui.util.setVisible
import net.geidea.sdk.presentation.features.cardscan.scanui.util.show
import net.geidea.sdk.presentation.features.cardscan.scanui.util.startAnimation
import net.geidea.sdk.presentation.features.cardscan.screen.CardScanFlow

internal const val INTENT_PARAM_REQUEST = "request"
internal const val INTENT_PARAM_RESULT = "result"
internal const val TAGCAERD ="CardScanActivity"
private val MINIMUM_RESOLUTION = Size(1067, 600) // minimum size of OCR

internal interface CardScanResultListener : ScanResultListener {

    /**
     * The scan completed.
     */
    fun cardScanComplete(card: ScannedCard)
}

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
sealed class CardScanState(isFinal: Boolean) : ScanState(isFinal) {
    data object NotFound : CardScanState(isFinal = false)
    data object Found : CardScanState(isFinal = false)
    data object Correct : CardScanState(isFinal = true)
}

internal class CardScanActivity : ScanActivity(), SimpleScanStateful<CardScanState> {

    override val minimumAnalysisResolution = MINIMUM_RESOLUTION

    private val binding by lazy {
        StripeActivityCardscanBinding.inflate(layoutInflater)
    }

    override val previewFrame: ViewGroup by lazy {
        binding.cameraView.previewFrame
    }

    private val viewFinderWindow: View by lazy {
        binding.cameraView.viewFinderWindowView
    }

    private val viewFinderBorder: ImageView by lazy {
        binding.cameraView.viewFinderBorderView
    }

    private val viewFinderBackground: ViewFinderBackground by lazy {
        binding.cameraView.viewFinderBackgroundView
    }

    override var scanState: CardScanState? = CardScanState.NotFound

    override var scanStatePrevious: CardScanState? = null

    override val scanErrorListener: ScanErrorListener = ScanErrorListener()

    override val cameraAdapterBuilder = ::getScanCameraAdapter

    /**
     * The listener which handles results from the scan.
     */
    override val resultListener: CardScanResultListener =
        object : CardScanResultListener {

            override fun cardScanComplete(card: ScannedCard) {
                Log.d(TAGCAERD, "cardScanComplete : ${card} ")
                val intent = Intent()
                    .putExtra(
                        INTENT_PARAM_RESULT,
                        CardScanSheetResult.Completed(
                            ScannedCard(
                                pan = card.pan
                            )
                        )
                    )
                setResult(RESULT_OK, intent)
            }

            override fun userCanceled(reason: CancellationReason) {
                Log.d(TAGCAERD, "userCanceled : ${reason} ")
                val intent = Intent()
                    .putExtra(
                        INTENT_PARAM_RESULT,
                        CardScanSheetResult.Canceled(reason)
                    )
                setResult(RESULT_CANCELED, intent)
            }

            override fun failed(cause: Throwable?) {
                Log.d(TAGCAERD, "failed : ${cause} ")
                val intent = Intent()
                    .putExtra(
                        INTENT_PARAM_RESULT,
                        CardScanSheetResult.Failed(cause ?: UnknownScanException())
                    )
                setResult(RESULT_CANCELED, intent)
            }
        }

    /**
     * The flow used to scan an item.
     */
    private val scanFlow: CardScanFlow by lazy {
        object : CardScanFlow(scanErrorListener) {
            /**
             * A final result was received from the aggregator. Set the result from this activity.
             */
            override suspend fun onResult(
                result: MainLoopAggregator.FinalResult
            ) {
                launch(Dispatchers.Main) {
                    Log.d(TAGCAERD, "scanFlow : ${CardScanState.Correct} ")
                    changeScanState(CardScanState.Correct)
                    cameraAdapter.unbindFromLifecycle(this@CardScanActivity)
                    resultListener.cardScanComplete(ScannedCard(result.pan))
                    closeScanner()
                }.let {

                }
            }

            /**
             * An interim result was received from the result aggregator.
             */
            override suspend fun onInterimResult(
                result: MainLoopAggregator.InterimResult
            ) = launch(Dispatchers.Main) {
                when (result.state) {
                    is MainLoopState.Initial -> changeScanState(CardScanState.NotFound)
                    is MainLoopState.OcrFound -> changeScanState(CardScanState.Found)
                    is MainLoopState.Finished -> changeScanState(CardScanState.Correct)
                }
            }.let { }

            override suspend fun onReset() = launch(Dispatchers.Main) {
                changeScanState(CardScanState.NotFound)
            }.let { }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        onBackPressedDispatcher.addCallback {
            resultListener.userCanceled(CancellationReason.Back)
            closeScanner()
        }

        binding.apply {
            closeButton.setOnClickListener {
                userClosedScanner()
            }
            torchButton.setOnClickListener {
                toggleFlashlight()
            }
            swapCameraButton.setOnClickListener {
                toggleCamera()
            }
        }

        viewFinderBorder.setOnTouchListener { _, e ->
            setFocus(
                PointF(
                    e.x + viewFinderBorder.left,
                    e.y + viewFinderBorder.top
                )
            )
            true
        }

        displayState(requireNotNull(scanState), scanStatePrevious)
    }

    override fun onResume() {
        super.onResume()
        scanState = CardScanState.NotFound
    }

    override fun onDestroy() {
        scanFlow.cancelFlow()
        super.onDestroy()
    }

    override fun onFlashSupported(supported: Boolean) {
        binding.apply {
            torchButton.setVisible(supported)
        }
    }

    override fun onSupportsMultipleCameras(supported: Boolean) {
        binding.apply {
            swapCameraButton.setVisible(supported)
        }
    }

    override fun onCameraReady() {
        previewFrame.post {
            viewFinderBackground
                .setViewFinderRect(viewFinderWindow.asRect())
            startCameraAdapter()
        }
    }

    /**
     * Once the camera stream is available, start processing images.
     */
    override suspend fun onCameraStreamAvailable(cameraStream: Flow<CameraPreviewImage<Bitmap>>) {
        binding.apply {
            scanFlow.startFlow(
                context = this@CardScanActivity,
                imageStream = cameraStream,
                viewFinder = cameraView.viewFinderWindowView.asRect(),
                lifecycleOwner = this@CardScanActivity,
                coroutineScope = this@CardScanActivity,
                parameters = null,
                errorHandler = { e ->
                    scanErrorListener.onResultFailure(e)
                }
            )
        }
    }

    /**
     * Called when the flashlight state has changed.
     */
    override fun onFlashlightStateChanged(flashlightOn: Boolean) {
        binding.apply {
            if (flashlightOn) {
                torchButton.setDrawable(R.drawable.stripe_flash_on_dark)
            } else {
                torchButton.setDrawable(R.drawable.stripe_flash_off_dark)
            }
        }
    }

    override fun displayState(newState: CardScanState, previousState: CardScanState?) {
        binding.apply {
            when (newState) {
                is CardScanState.NotFound -> {
                    viewFinderBackground
                        .setBackgroundColor(getColorByRes(R.color.stripeNotFoundBackground))
                    viewFinderWindow
                        .setBackgroundResource(R.drawable.stripe_card_background_not_found)
                    viewFinderBorder.startAnimation(R.drawable.stripe_card_border_not_found)
                    instructions.setText(R.string.stripe_card_scan_instructions)
                }
                is CardScanState.Found -> {
                    viewFinderBackground
                        .setBackgroundColor(getColorByRes(R.color.stripeFoundBackground))
                    viewFinderWindow
                        .setBackgroundResource(R.drawable.stripe_card_background_found)
                    viewFinderBorder.startAnimation(R.drawable.stripe_card_border_found)
                    instructions.setText(R.string.stripe_card_scan_instructions)
                    instructions.show()
                }
                is CardScanState.Correct -> {
                    viewFinderBackground
                        .setBackgroundColor(getColorByRes(R.color.stripeCorrectBackground))
                    viewFinderWindow
                        .setBackgroundResource(R.drawable.stripe_card_background_correct)
                    viewFinderBorder.startAnimation(R.drawable.stripe_card_border_correct)
                    instructions.hide()
                }
            }
        }
    }

}