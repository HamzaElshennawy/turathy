package net.geidea.sdk.core.network

object EndPoints {
    internal const val CONFIGURATIONS_DETAILS = "pgw/api/v1/SDK/RetrievePaymentConfig/"
    internal const val PERFORM_AUTHENTICATION = "pgw/api/v1/SDK/PerformAuthentication"
    internal const val PAY = "pgw/api/v1/sdk/pay"
}