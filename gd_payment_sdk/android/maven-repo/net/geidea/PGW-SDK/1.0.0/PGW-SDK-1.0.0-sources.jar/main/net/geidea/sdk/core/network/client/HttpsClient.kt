package net.geidea.sdk.core.network.client

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import net.geidea.sdk.core.network.interceptor.LoggingInterceptor
import net.geidea.sdk.core.network.response.BaseResponse
import net.geidea.sdk.core.network.util.NetworkInterceptor
import net.geidea.sdk.core.utils.dispatcher.DefaultDispatcherProvider
import net.geidea.sdk.core.utils.dispatcher.DispatcherProvider
import org.json.JSONObject

internal class HttpClient(
    private val dispatcherProvider: DispatcherProvider = DefaultDispatcherProvider,
    private val baseHeadersProvider: BaseHeadersProvider = DefaultBaseHeadersProvider,
    private val connectTimeout: Int = 60_000,
    private val readTimeout: Int = 60_000,
    private val baseUrl: String = "",
    private val language: String = "en",
    private val networkInterceptor: NetworkInterceptor? = LoggingInterceptor()
) : NetworkClient {

    private fun mergeHeaders(headers: Map<String, String>) =
        baseHeadersProvider.getBaseHeaders(language) + headers

    private fun <T> requestAsFlow(
        method: HttpMethod,
        url: String,
        queryParams: Map<String, String> = emptyMap(),
        body: JSONObject? = null,
        headers: Map<String, String> = emptyMap(),
        mapper: (String) -> T
    ): Flow<BaseResponse<T>> {
        val finalUrl =
            if (url.startsWith("http")) url else baseUrl.trimEnd('/') + "/" + url.trimStart('/')
        return HttpRequestExecutor(
            networkInterceptor,
            connectTimeout,
            readTimeout,
            language = language
        )
            .executeAsFlow(method, finalUrl, queryParams, body, mergeHeaders(headers), mapper)
            .flowOn(dispatcherProvider.io)
    }

    override fun <T> getAsFlow(
        url: String,
        queryParams: Map<String, String>,
        headers: Map<String, String>,
        mapper: (String) -> T
    ): Flow<BaseResponse<T>> =
        requestAsFlow(HttpMethod.GET, url, queryParams, null, headers, mapper)

    override fun <T> postAsFlow(
        url: String,
        body: JSONObject?,
        headers: Map<String, String>,
        mapper: (String) -> T
    ): Flow<BaseResponse<T>> =
        requestAsFlow(HttpMethod.POST, url, emptyMap(), body, headers, mapper)

    override fun <T> putAsFlow(
        url: String,
        body: JSONObject?,
        headers: Map<String, String>,
        mapper: (String) -> T
    ): Flow<BaseResponse<T>> =
        requestAsFlow(HttpMethod.PUT, url, emptyMap(), body, headers, mapper)

    override fun <T> patchAsFlow(
        url: String,
        body: JSONObject?,
        headers: Map<String, String>,
        mapper: (String) -> T
    ): Flow<BaseResponse<T>> =
        requestAsFlow(HttpMethod.PATCH, url, emptyMap(), body, headers, mapper)

    override fun <T> deleteAsFlow(
        url: String,
        queryParams: Map<String, String>,
        headers: Map<String, String>,
        mapper: (String) -> T
    ): Flow<BaseResponse<T>> =
        requestAsFlow(HttpMethod.DELETE, url, queryParams, null, headers, mapper)
}
