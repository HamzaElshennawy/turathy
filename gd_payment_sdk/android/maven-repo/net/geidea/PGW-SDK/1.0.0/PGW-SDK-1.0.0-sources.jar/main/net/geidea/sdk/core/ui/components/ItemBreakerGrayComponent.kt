package net.geidea.sdk.core.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme


@Composable
internal fun ItemBreakerGrayComponent(modifier: Modifier) {
    Spacer(
        modifier = modifier
            .fillMaxWidth()
            .height(dimensionResource(R.dimen.spacing_1))
            .background(color = SdkTheme.colors.neutral20)
    )
}