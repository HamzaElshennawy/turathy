package net.geidea.sdk.domain.usecase

import net.geidea.sdk.domain.repository.PaymentRepository

internal class GetConfigurationUseCase(
    private val repository: PaymentRepository
) {
    internal fun getConfiguration() =
        repository.getMerchantConfigurationDetails()

}