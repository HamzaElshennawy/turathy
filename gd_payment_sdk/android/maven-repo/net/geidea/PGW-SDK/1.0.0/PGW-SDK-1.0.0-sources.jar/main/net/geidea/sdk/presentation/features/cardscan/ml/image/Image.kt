package net.geidea.sdk.presentation.features.cardscan.ml.image

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ConfigurationInfo
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.util.Log
import android.util.Size
import androidx.annotation.CheckResult
import androidx.annotation.RestrictTo
import net.geidea.sdk.presentation.features.cardscan.ml.ext.crop
import net.geidea.sdk.presentation.features.cardscan.ml.ext.projectRegionOfInterest
import net.geidea.sdk.presentation.features.cardscan.ml.ext.size
import net.geidea.sdk.presentation.features.cardscan.ml.ext.toRect
import kotlin.math.max
import kotlin.math.min

/**
 * Get a rect indicating what part of the preview is actually visible on screen. This assumes that the preview
 * is the same size or larger than the screen in both dimensions.
 */
private fun getVisiblePreview(previewBounds: Rect) = Size(
    previewBounds.right + previewBounds.left,
    previewBounds.bottom + previewBounds.top
)

/**
 * Determine how to crop the preview image from the camera based on the view finder's position in
 * the preview bounds.
 *
 * Note: This algorithm makes some assumptions:
 * 1. the [previewBounds] and the [cameraPreviewImageSize] are centered relative to each other.
 * 2. the [previewBounds] circumscribes the [cameraPreviewImageSize]. I.E. they share at least one
 *    field of view, and the [cameraPreviewImageSize] fields of view are smaller than or the same
 *    size as the [previewBounds]
 * 3. the [previewBounds] and the [cameraPreviewImageSize] have the same orientation
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun determineViewFinderCrop(
    cameraPreviewImageSize: Size,
    previewBounds: Rect,
    viewFinder: Rect
): Rect {
    // Scale the cardFinder to match the full image
    return previewBounds
        .projectRegionOfInterest(
            toSize = cameraPreviewImageSize,
            regionOfInterest = viewFinder
        )
        .intersectionWith(cameraPreviewImageSize.toRect())
}

/**
 * Crop the preview image from the camera based on the view finder's position in the preview bounds.
 *
 * Note: This algorithm makes some assumptions:
 * 1. the [previewBounds] and the [cameraPreviewImage] are centered relative to each other.
 * 2. the [previewBounds] circumscribes the [cameraPreviewImage]. I.E. they share at least one field
 *    of view, and the [cameraPreviewImage] fields of view are smaller than or the same size as the
 *    [previewBounds]
 * 3. the [previewBounds] and the [cameraPreviewImage] have the same orientation
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun cropCameraPreviewToViewFinder(
    cameraPreviewImage: Bitmap,
    previewBounds: Rect,
    viewFinder: Rect
): Bitmap {
    return cameraPreviewImage.crop(
        determineViewFinderCrop(cameraPreviewImage.size(), previewBounds, viewFinder)
    )
}


/**
 * Determine if the device supports OpenGL version 3.1.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
@CheckResult
fun hasOpenGl31(context: Context): Boolean {
    val openGlVersion = 0x00030001
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val configInfo = activityManager.deviceConfigurationInfo

    val isSupported = if (configInfo.reqGlEsVersion != ConfigurationInfo.GL_ES_VERSION_UNDEFINED) {
        configInfo.reqGlEsVersion >= openGlVersion && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
    } else {
        false
    }

    Log.d("Image#hasOpenGl31", "OpenGL is supported? $isSupported")
    return isSupported
}

/**
 * Return a rect that is the intersection of two other rects
 */
@CheckResult
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun Rect.intersectionWith(rect: Rect): Rect {
    require(this.intersect(rect)) {
        "Given rects do not intersect $this <> $rect"
    }

    return Rect(
        max(this.left, rect.left),
        max(this.top, rect.top),
        min(this.right, rect.right),
        min(this.bottom, rect.bottom)
    )
}
