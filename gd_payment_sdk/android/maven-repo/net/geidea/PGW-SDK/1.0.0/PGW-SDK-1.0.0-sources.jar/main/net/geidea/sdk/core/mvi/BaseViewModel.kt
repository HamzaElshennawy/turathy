package net.geidea.sdk.core.mvi


import android.os.Looper
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import net.geidea.sdk.core.network.response.BaseResponse
import net.geidea.sdk.core.network.util.NetworkException


internal abstract class BaseViewModel<STATE : ViewState, EVENT : ViewEvent, EFFECT : BaseEffect> :
    ViewModel() {

    private val _state = MutableStateFlow(createInitialState())
    internal val state: StateFlow<STATE> = _state.asStateFlow()

    private val _event = Channel<ViewEvent>(Channel.UNLIMITED)
    private val _effect = MutableSharedFlow<BaseEffect>(extraBufferCapacity = 1)
    internal val effect: SharedFlow<BaseEffect> = _effect.asSharedFlow()

    init {
        viewModelScope.launch {
            _event.receiveAsFlow().collect { event -> handleEvent(event) }
        }
    }

    internal abstract fun createInitialState(): STATE
    internal abstract fun handleEvent(event: ViewEvent)

    internal fun sendEvent(event: ViewEvent) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            viewModelScope.launch { _event.send(event) }
        } else {
            viewModelScope.launch(Dispatchers.Main) { _event.send(event) }
        }
    }

    protected fun setState(reducer: STATE.() -> STATE) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            _state.update { it.reducer() }
        } else {
            viewModelScope.launch(Dispatchers.Main) { _state.update { it.reducer() } }
        }
    }

    protected fun emitEffect(effect: BaseEffect) {
        viewModelScope.launch(Dispatchers.Main) { _effect.emit(effect) }
    }

    internal fun <T> collectResponse(
        flow: Flow<BaseResponse<T>>,
        onSuccess: suspend (T) -> Unit,
        onError: (suspend (ErrorEvent) -> Unit)? = null,
        loadingState: ((Boolean) -> Unit)? = null
    ) {
        viewModelScope.launch {
            flow
                .onStart { loadingState?.invoke(true) }
                .catch { throwable ->
                    loadingState?.invoke(false)
                    onError?.invoke(mapThrowableToErrorEvent(throwable))
                }
                .collect { response ->
                    loadingState?.invoke(false)
                    when (response) {
                        is BaseResponse.Success -> {
                            if (!response.responseCode.isNullOrEmpty() && response.responseCode != "000") {
                                onError?.invoke(
                                    ErrorEvent.BusinessError(
                                        code = response.responseCode,
                                        responseMessage = response.responseMessage,
                                        detailedResponseMessage = response.detailedResponseMessage
                                    )
                                )
                            } else {
                                onSuccess(response.data)
                            }
                        }

                        is BaseResponse.Unauthorized -> {
                            onError?.invoke(
                                ErrorEvent.Unauthorized(
                                    responseMessage = response.responseMessage,
                                    detailedResponseMessage = response.detailedResponseMessage
                                )
                            )
                        }

                        is BaseResponse.Failure -> {
                            onError?.invoke(
                                ErrorEvent.GeneralError(
                                    code = response.responseCode,
                                    responseMessage = response.responseMessage,
                                    detailedResponseMessage = response.detailedResponseMessage
                                )
                            )
                        }
                    }
                }
        }
    }

    protected fun mapThrowableToErrorEvent(throwable: Throwable): ErrorEvent = when (throwable) {
        is NetworkException.BusinessError -> ErrorEvent.BusinessError(
            code = throwable.backendCode,
            responseMessage = throwable.responseMessage,
            detailedResponseMessage = throwable.detailedResponseMessage
        )

        is NetworkException.Unauthorized -> ErrorEvent.Unauthorized(
            responseMessage = throwable.responseMessage,
            detailedResponseMessage = throwable.detailedResponseMessage
        )

        is NetworkException.Forbidden -> ErrorEvent.Forbidden()
        is NetworkException.NotFound -> ErrorEvent.NotFound()
        is NetworkException.GeneralError -> ErrorEvent.HttpError(
            code = throwable.code,
            responseMessage = throwable.messageBody,
            detailedResponseMessage = throwable.messageBody
        )

        else -> ErrorEvent.GeneralError(
            responseMessage = throwable.message,
            detailedResponseMessage = throwable.message
        )
    }
}

