package net.geidea.sdk.presentation.features.paymentdetails.components.header

import net.geidea.sdk.core.utils.extensions.updateIfChanged
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent

internal fun reducePaymentHeaderState(
    state: PaymentHeaderState,
    event: PaymentEvent
) = when (event) {

    is PaymentHeaderEvent.UpdateExpandedHeader ->
        updateIfChanged(state, state.isExpanded, !state.isExpanded) {
            copy(isExpanded = !state.isExpanded)
        }

    else -> state
}
