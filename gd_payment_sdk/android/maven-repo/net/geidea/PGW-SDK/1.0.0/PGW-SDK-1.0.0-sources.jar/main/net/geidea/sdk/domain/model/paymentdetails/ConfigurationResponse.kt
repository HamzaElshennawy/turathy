package net.geidea.sdk.domain.model.paymentdetails

import net.geidea.sdk.core.utils.constants.safeJson


internal data class PaymentConfigResponse(
    internal val merchantName: String?,
    internal val currency: String?,
    internal val country: String?,
    internal val orderSummary: OrderSummary?,
    internal val paymentOperation: String?,
    internal val merchantConfigurations: MerchantConfigurations?,
    internal val devicePaymentMethods: List<PaymentMethod>?,
    internal val paymentMethods: List<PaymentMethod>?,
    internal val savedCards: SavedCards?
)

internal fun mapPaymentConfigResponse(jsonString: String): PaymentConfigResponse {
    val json = safeJson(jsonString)
    return PaymentConfigResponse(
        merchantName = json.optString("merchantName", ""),
        currency = json.optString("currency", ""),
        country = json.optString("country", ""),
        paymentOperation = json.optString("paymentOperation", ""),
        orderSummary = json.optJSONObject("orderSummary")?.let { mapOrderSummary(it.toString()) },
        merchantConfigurations = json.optJSONObject("merchantConfigurations")
            ?.let { mapMerchantConfigurations(it.toString()) },
        devicePaymentMethods = json.optJSONArray("devicePaymentMethods")?.let { arr ->
            List(arr.length()) { i -> mapPaymentMethod(arr.getJSONObject(i).toString()) }
        } ?: emptyList(),
        paymentMethods = json.optJSONArray("paymentMethods")?.let { arr ->
            List(arr.length()) { i -> mapPaymentMethod(arr.getJSONObject(i).toString()) }
        } ?: emptyList(),
        savedCards = json.optJSONObject("saved_Cards")?.let { mapSavedCards(it.toString()) }
    )
}

internal data class OrderSummary(
    internal val ordersItems: List<OrderItem>,
    internal val orderDetails: List<OrderDetail>,
    internal val currency: String,
    internal val total: Double,
    internal val subTotal: Double,
)

private fun mapOrderSummary(jsonString: String): OrderSummary {
    val json = safeJson(jsonString)
    val ordersItems = json.optJSONArray("ordersItems")?.let { arr ->
        List(arr.length()) { i -> mapOrderItem(arr.getJSONObject(i).toString()) }
    } ?: emptyList()
    val orderDetails = json.optJSONArray("orderDetails")?.let { arr ->
        List(arr.length()) { i -> mapOrderDetail(arr.getJSONObject(i).toString()) }
    } ?: emptyList()
    return OrderSummary(
        ordersItems = ordersItems,
        orderDetails = orderDetails,
        currency = json.optString("currency", ""),
        total = json.optDouble("total", 0.0),
        subTotal = json.optDouble("subTotal", 0.0),
    )
}

internal data class OrderDetail(
    internal val id: Int,
    internal val title: String,
    internal val value: Double
)

private fun mapOrderDetail(jsonString: String): OrderDetail {
    val json = safeJson(jsonString)
    return OrderDetail(
        id = json.optInt("id", 0),
        title = json.optString("title", ""),
        value = json.optDouble("value", 0.0)
    )
}

internal data class OrderItem(
    internal val id: Int,
    internal val name: String,
    internal val quantity: Int,
    internal val price: Double,
    internal val icon: String
)

private fun mapOrderItem(jsonString: String): OrderItem {
    val json = safeJson(jsonString)
    return OrderItem(
        id = json.optInt("id", 0),
        name = json.optString("name", ""),
        quantity = json.optInt("quantity", 0),
        price = json.optDouble("price", 0.0),
        icon = json.optString("icon", ""),

        )
}

internal data class MerchantConfigurations(
    internal val needsEmail: Boolean,
    internal val needsShippingAddress: Boolean,
    internal val needsBillingAddress: Boolean
)

private fun mapMerchantConfigurations(jsonString: String): MerchantConfigurations {
    val json = safeJson(jsonString)
    return MerchantConfigurations(
        needsEmail = json.optBoolean("needsEmail", false),
        needsShippingAddress = json.optBoolean("needsShippingAddress", false),
        needsBillingAddress = json.optBoolean("needsBillingAddress", false)
    )
}

internal data class PaymentMethod(
    internal val id: Int,
    internal val type: String,
    internal val icon: String?,
    internal val name: String?,
    internal val localizedName: String?,
    val supportedCards: List<SupportedCard>?
)

private fun mapPaymentMethod(jsonString: String): PaymentMethod {
    val json = safeJson(jsonString)
    val supportedCards = json.optJSONArray("supportedCards")?.let { arr ->
        List(arr.length()) { i -> mapSupportedCard(arr.getJSONObject(i).toString()) }
    } ?: emptyList()
    return PaymentMethod(
        id = json.optInt("id", 0),
        type = json.optString("type", ""),
        icon = json.optString("icon", ""),
        name = json.optString("name", ""),
        localizedName = json.optString("localizedName", ""),
        supportedCards = supportedCards
    )
}

internal data class SupportedCard(
    internal val name: String?,
    internal val icon: String?,
    internal val regex: String?
)

private fun mapSupportedCard(jsonString: String): SupportedCard {
    val json = safeJson(jsonString)
    return SupportedCard(
        name = json.optString("name", ""),
        icon = json.optString("icon", ""),
        regex = json.optString("regex", "")
    )
}

internal data class SavedCards(internal val eligibleToSaveCard: Boolean)

private fun mapSavedCards(jsonString: String): SavedCards {
    val json = safeJson(jsonString)
    return SavedCards(
        eligibleToSaveCard = json.optBoolean("eligibleToSaveCard", false)
    )
}
