package net.geidea.sdk.core.ui.components

import androidx.annotation.DimenRes
import androidx.annotation.StringRes
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.sp
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SDKFont
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.ui.validation.FieldValidationTrigger


@Composable
internal fun PrimaryTextField(
    modifier: Modifier = Modifier,
    value: String,
    onValueChange: (String) -> Unit,
    @StringRes label: Int? = null,
    @StringRes placeholder: Int? = null,
    enabled: Boolean = true,
    readOnly: Boolean = false,
    singleLine: Boolean = true,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    minLines: Int = 1,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    supportingText: @Composable (() -> Unit)? = null,
    textStyle: TextStyle = SdkTheme.typography.medium14.copy(
        color = SdkTheme.colors.onPrimary
    ),
    labelStyle: TextStyle? = null,
    placeholderStyle: TextStyle = SdkTheme.typography.medium14,
    containerColor: Color = SdkTheme.colors.transparent,
    @DimenRes borderWidth: Int = R.dimen.spacing_1,
    @DimenRes cornerRadius: Int = R.dimen.primary_textfield_corner_radius,
    @DimenRes verticalPadding: Int = R.dimen.primary_textfield_vertical_padding,
    @DimenRes horizontalPadding: Int = R.dimen.primary_textfield_horizontal_padding,
    isError: Boolean = false,
    @StringRes errorMessage: Int? = null,
    errorStyle: TextStyle = SdkTheme.typography.medium12.copy(
        color = Color(0xFFD32323)
    ),
    colors: TextFieldColors = TextFieldDefaults.colors(
        focusedIndicatorColor = SdkTheme.colors.transparent,
        unfocusedIndicatorColor = SdkTheme.colors.transparent,
        disabledIndicatorColor = SdkTheme.colors.transparent,
        errorIndicatorColor = SdkTheme.colors.transparent,
        focusedTextColor = SdkTheme.colors.neutral300,
        unfocusedTextColor = SdkTheme.colors.neutral300,
        focusedContainerColor = SdkTheme.colors.transparent,
        unfocusedContainerColor = SdkTheme.colors.transparent,
        errorContainerColor = SdkTheme.colors.transparent,
    ),
    validationTrigger: FieldValidationTrigger = FieldValidationTrigger.ON_VALUE_CHANGE,
) {
    var isFocused by rememberSaveable { mutableStateOf(false) }
    var lostFocusOnce by rememberSaveable { mutableStateOf(false) }

    val currentValue by rememberUpdatedState(value)
    val currentOnValueChange by rememberUpdatedState(onValueChange)

    val shouldShowError = when (validationTrigger) {
        FieldValidationTrigger.ON_FOCUS_LOST -> isError && ((lostFocusOnce && isFocused) || !isFocused)
        FieldValidationTrigger.ON_VALUE_CHANGE -> isError
    }

    val borderColor = when {
        shouldShowError -> colors.errorLabelColor
        isFocused -> SdkTheme.colors.primary
        else -> SdkTheme.colors.neutral20
    }

    val labelColor = when {
        shouldShowError -> colors.errorLabelColor
        isFocused -> SdkTheme.colors.primary
        else -> SdkTheme.colors.neutral80
    }


    Column(modifier = modifier.wrapContentHeight()) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = containerColor,
            shape = RoundedCornerShape(dimensionResource(cornerRadius))
        ) {
            TextField(
                value = currentValue,
                onValueChange = currentOnValueChange,
                label = label?.let {
                    {
                        Text(
                            text = stringResource(it),
                            style = labelStyle ?: TextStyle(
                                fontFamily = SDKFont.getFont(),
                                fontWeight = FontWeight.Medium,
                                fontSize = dimensionResource(
                                    if (isFocused || value.isNotBlank())
                                        R.dimen.textfield_focused_label_sized
                                    else
                                        R.dimen.textfield_unfocused_label_sized
                                ).value.sp
                            ),
                            color = labelColor
                        )
                    }
                },
                placeholder = placeholder?.let {
                    {
                        Text(
                            stringResource(it), style = placeholderStyle.copy(
                                color = SdkTheme.colors.onPrimary
                            )
                        )
                    }
                },
                isError = shouldShowError,
                enabled = enabled,
                readOnly = readOnly,
                singleLine = singleLine,
                maxLines = maxLines,
                minLines = minLines,
                keyboardOptions = keyboardOptions,
                keyboardActions = keyboardActions,
                visualTransformation = visualTransformation,
                leadingIcon = leadingIcon,
                trailingIcon = trailingIcon,
                supportingText = supportingText,
                textStyle = textStyle,
                shape = RoundedCornerShape(dimensionResource(cornerRadius)),
                colors = colors,
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .padding(
                        horizontal = dimensionResource(horizontalPadding),
                        vertical = dimensionResource(verticalPadding),
                    )
                    .onFocusChanged { focusState ->
                        if (isFocused && !focusState.isFocused) {
                            lostFocusOnce = true
                        }
                        isFocused = focusState.isFocused
                    }
                    .border(
                        width = dimensionResource(borderWidth),
                        color = borderColor,
                        shape = RoundedCornerShape(dimensionResource(cornerRadius))
                    )
            )
        }

        if (shouldShowError && errorMessage != null) {
            ErrorText(errorMessageRes = errorMessage, errorStyle = errorStyle)
        }
    }
}
