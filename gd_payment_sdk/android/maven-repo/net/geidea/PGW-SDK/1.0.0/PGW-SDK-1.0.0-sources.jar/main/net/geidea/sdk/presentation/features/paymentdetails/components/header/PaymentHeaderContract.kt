package net.geidea.sdk.presentation.features.paymentdetails.components.header

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import net.geidea.sdk.domain.model.paymentdetails.OrderDetail
import net.geidea.sdk.domain.model.paymentdetails.OrderItem
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent


@Immutable
@Stable
internal data class PaymentHeaderState(
    internal val isExpanded: Boolean = false,
    internal val currency: String = "",
    internal val total: Double = 0.0,
    internal val subTotal: Double = 0.0,
    internal val ordersDetails: List<OrderDetail> = emptyList(),
    internal val ordersItems: List<OrderItem> = emptyList()
)


internal sealed interface PaymentHeaderEvent : PaymentEvent {
    data object UpdateExpandedHeader : PaymentHeaderEvent
}