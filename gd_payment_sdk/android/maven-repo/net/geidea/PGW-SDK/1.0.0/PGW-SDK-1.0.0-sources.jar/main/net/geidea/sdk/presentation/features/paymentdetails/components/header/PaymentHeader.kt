package net.geidea.sdk.presentation.features.paymentdetails.components.header

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.components.ItemBreakerGrayComponent
import net.geidea.sdk.core.ui.components.MerchantLogo
import net.geidea.sdk.core.ui.components.ReceiptItemComponentWithImages
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.utils.constants.Constants
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentState
import net.geidea.sdk.sdk.GDPaymentSDK


@Composable
internal fun PaymentHeaderSection(
    modifier: Modifier = Modifier,
    paymentState: PaymentState,
    onEvent: (PaymentEvent) -> Unit = {},
    backgroundColor: Color = SdkTheme.colors.secondary,
    contentPadding: PaddingValues = PaddingValues(
        horizontal = dimensionResource(R.dimen.spacing_32)
    ),
) {
    val currentOnEvent by rememberUpdatedState(onEvent)
    val state = paymentState.paymentHeaderState

    val arrowRotation by remember(state.isExpanded) {
        derivedStateOf { if (state.isExpanded) 180f else 0f }
    }

    val onToggleExpand = remember(currentOnEvent) {
        { currentOnEvent(PaymentHeaderEvent.UpdateExpandedHeader) }
    }

    val screenHeight = with(LocalDensity.current) {
        LocalWindowInfo.current.containerSize.height.toDp()
    }


    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(backgroundColor)
            .padding(contentPadding)
    ) {
        LanguageHeaderRow(modifier = Modifier.padding(start = dimensionResource(R.dimen.spacing_16)))

        if (paymentState.paymentOperation != Constants.PaymentOperation.SAVE_CARD) {
            TotalRow(
                currency = state.currency,
                total = state.total.toString(),
                arrowRotation = arrowRotation,
                onToggleExpand = onToggleExpand
            )

            AnimatedVisibility(visible = state.isExpanded) {
                LazyColumn(
                    modifier = Modifier
                        .padding(top = dimensionResource(R.dimen.spacing_16))
                        .fillMaxWidth()
                        .heightIn(max = screenHeight / 4),
                ) {
                    items(state.ordersItems) { order ->
                        ReceiptItemComponentWithImages(
                            iconUrl = order.icon,
                            itemTitle = order.name,
                            quantity = order.quantity.toString(),
                            price = order.price.toString(),
                            currency = state.currency,
                        )
                    }

                    item(key = "divider_1") {
                        ItemBreakerGrayComponent(
                            modifier = Modifier.padding(vertical = dimensionResource(R.dimen.spacing_16))
                        )
                    }

                    item(key = "sub_total_row") {
                        AmountRow(
                            modifier = Modifier
                                .padding(bottom = dimensionResource(R.dimen.spacing_16))
                                .fillMaxWidth(),
                            title = stringResource(R.string.sub_total),
                            currency = state.currency,
                            amount = state.subTotal
                        )
                    }

                    items(state.ordersDetails) { detail ->
                        ReceiptItemComponent(
                            key = detail.title,
                            value = "${state.currency} ${detail.value}"
                        )
                    }

                    item(key = "divider_2") {
                        ItemBreakerGrayComponent(
                            modifier = Modifier.padding(vertical = dimensionResource(R.dimen.spacing_16))
                        )
                    }

                    item(key = "total_row") {
                        AmountRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = dimensionResource(R.dimen.spacing_8)),
                            title = stringResource(R.string.total),
                            currency = state.currency,
                            amount = state.total
                        )
                    }

                }
            }

            Spacer(modifier = Modifier.height(dimensionResource(R.dimen.spacing_16)))
        }
    }
}

@Composable
private fun AmountRow(
    modifier: Modifier = Modifier,
    title: String,
    currency: String,
    amount: Double,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = SdkTheme.typography.semibold16,
            color = SdkTheme.colors.neutral900,
        )
        Text(
            text = "$currency $amount",
            style = SdkTheme.typography.semibold16,
            color = SdkTheme.colors.neutral900
        )
    }
}


@Composable
private fun LanguageHeaderRow(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = dimensionResource(R.dimen.spacing_24)),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        GDPaymentSDK.sharedInstance().getConfigurations().theme.merchantLogo

        MerchantLogo(
            merchantLogo = GDPaymentSDK.sharedInstance().getConfigurations().theme.merchantLogo
        )
        //GeideaLogo()
        Box(modifier = modifier.fillMaxWidth()) {
            Icon(
                modifier = modifier
                    .size(dimensionResource(R.dimen.spacing_32))
                    .align(Alignment.CenterEnd)
                    .clickable {
                        GDPaymentSDK.sharedInstance().onPaymentCanceled()
                    },
                painter = painterResource(R.drawable.ic_close),
                contentDescription = stringResource(R.string.close),
            )
        }
    }
}

@Composable
private fun TotalRow(
    modifier: Modifier = Modifier,
    currency: String, total: String, arrowRotation: Float, onToggleExpand: () -> Unit
) {
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Row(
        modifier = modifier
            .fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$currency $total",
            style = SdkTheme.typography.bold32,
            color = SdkTheme.colors.neutral900,
        )

        Row(
            modifier = Modifier.clickable(onClick = {
                keyboardController?.hide()
                focusManager.clearFocus()
                onToggleExpand()
            }),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.details_label),
                style = SdkTheme.typography.semibold16,
                color = SdkTheme.colors.neutral900
            )
            Icon(
                modifier = Modifier.rotate(arrowRotation),
                painter = painterResource(R.drawable.ic_arrow_down),
                contentDescription = "Dropdown"
            )
        }
    }
}

@Composable
private fun ReceiptItemComponent(modifier: Modifier = Modifier, key: String, value: String) {

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = dimensionResource(R.dimen.spacing_8)),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = key, style = SdkTheme.typography.regular14, color = SdkTheme.colors.neutral300
        )
        Text(
            text = value, style = SdkTheme.typography.medium14, color = SdkTheme.colors.neutral700
        )
    }
}
