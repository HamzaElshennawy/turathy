package net.geidea.sdk.sdk

enum class SDKLanguage(val language: String) {
    ENGLISH("en"),

    ARABIC("ar")
}