package net.geidea.sdk.presentation.features.cardscan

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import net.geidea.sdk.core.ui.validation.validators.CardValidator
import kotlin.coroutines.resume

internal class CardTextRecognizer {
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var lastPartialData = ScannedCardData()

    internal suspend fun extractCardData(bitmap: Bitmap): ScannedCardData =
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)

            textRecognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val newData = parseCardText(visionText.text, visionText)

                    // Merge with previous detections
                    lastPartialData = mergeCardData(lastPartialData, newData)

                    continuation.resume(lastPartialData)
                }
                .addOnFailureListener {
                    continuation.resume(ScannedCardData())
                }
        }

    private fun parseCardText(text: String, visionText: Text): ScannedCardData {
        val lines = text.lines().filter { it.trim().isNotEmpty() }
        var cardNumber = ""
        var expiryDate = ""
        var cardHolderName = ""
        var confidence = 0f

        // 1. Try to find card number across blocks/lines/elements
        val digitGroups = mutableListOf<String>()
        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                for (element in line.elements) {
                    val clean = element.text.replace("[^0-9]".toRegex(), "")
                    if (clean.length in 3..4) { // likely card digit group
                        digitGroups.add(clean)
                    }
                }
            }
        }

        if (digitGroups.size >= 4) {
            val possibleNumber = digitGroups.joinToString("")
            if (CardValidator.isValidCardNumber(possibleNumber)) {
                cardNumber = possibleNumber
                confidence += 0.5f
            }
        }

        // 2. Expiry date detection
        for (line in lines) {
            val expiryRegex = Regex("(0[1-9]|1[0-2])[/\\s-]([0-9]{2}|[0-9]{4})")
            val expiryMatch = expiryRegex.find(line)
            if (expiryMatch != null && CardValidator.isValidExpiryDate(expiryMatch.value)) {
                expiryDate = expiryMatch.value
                confidence += 0.3f
                break
            }
        }

        // 3. Cardholder name detection
        for (line in lines) {
            val nameRegex = Regex("^[A-Z\\s]{8,30}$")
            if (nameRegex.matches(line.trim()) &&
                !line.contains(Regex("[0-9/]")) &&
                line.trim().split("\\s".toRegex()).size >= 2
            ) {
                cardHolderName = line.trim()
                confidence += 0.3f
                break
            }
        }

        return ScannedCardData(
            cardNumber = cardNumber,
            expiryDate = expiryDate,
            cardHolderName = cardHolderName,
            isValid = cardNumber.isNotEmpty(),
            confidence = confidence
        )
    }

    private fun mergeCardData(old: ScannedCardData, new: ScannedCardData): ScannedCardData {
        return ScannedCardData(
            cardNumber = new.cardNumber.ifEmpty { old.cardNumber },
            expiryDate = new.expiryDate.ifEmpty { old.expiryDate },
            cardHolderName = new.cardHolderName.ifEmpty { old.cardHolderName },
            isValid = ((new.cardNumber.isNotEmpty() || old.cardNumber.isNotEmpty())),
            confidence = maxOf(old.confidence, new.confidence)
        )
    }

    internal fun reset() {
        lastPartialData = ScannedCardData()
    }
}