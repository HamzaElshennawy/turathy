package net.geidea.sdk.core.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import net.geidea.sdk.R
import net.geidea.sdk.sdk.GDPaymentSDK
import net.geidea.sdk.sdk.SDKLanguage

internal class SDKFont {
    companion object {
        fun getFont(
            language: SDKLanguage = GDPaymentSDK.sharedInstance().getConfigurations().language
        ): FontFamily {
            return if (language == SDKLanguage.ENGLISH) {
                FontFamily(
                    Font(R.font.montserrat_regular, FontWeight.Normal),
                    Font(R.font.montserrat_medium, FontWeight.Medium),
                    Font(R.font.montserrat_semibold, FontWeight.SemiBold),
                    Font(R.font.montserrat_bold, FontWeight.Bold),
                )
            } else {
                FontFamily(
                    Font(R.font.almarai_light, FontWeight.Normal),
                    Font(R.font.almarai_regular, FontWeight.Medium),
                    Font(R.font.almarai_bold, FontWeight.SemiBold),
                    Font(R.font.almarai_extra_bold, FontWeight.Bold),
                )
            }
        }
    }
}