package net.geidea.sdk.core.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import net.geidea.sdk.core.utils.constants.Constants
import net.geidea.sdk.domain.model.pay.mapPerformAuthenticateResponse
import net.geidea.sdk.domain.model.pay.toJson
import net.geidea.sdk.presentation.features.cardscan.scannedCardResultFromJson
import net.geidea.sdk.presentation.features.cardscan.screen.CardScanScreen
import net.geidea.sdk.presentation.features.cardscan.toJson
import net.geidea.sdk.presentation.features.otp.screen.OTPScreen
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.cardUiModelFromJson
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.toJson
import net.geidea.sdk.presentation.features.paymentdetails.screen.PaymentScreen

@Composable
internal fun SDKNavigation(
    navController: NavHostController,
    modifier: Modifier = Modifier,
) {
    NavHost(
        modifier = modifier,
        navController = navController,
        startDestination = Destination.CardDetailsScreen.fullRoute,
    ) {

        composable(
            route = Destination.CardDetailsScreen.fullRoute,
            enterTransition = { null },
            exitTransition = { null }
        ) { backStackEntry ->
            val result = backStackEntry.savedStateHandle.get<String>("card_scan_result")
                ?.let { scannedCardResultFromJson(it) }

            val proceedToPay =
                navController.currentBackStackEntry?.savedStateHandle?.get<Boolean>(Constants.DestinationArgs.PROCEED_TO_PAY)

            PaymentScreen(
                onNavigateToCardScan = {
                    navController.navigate(Destination.CardScanScreen.fullRoute)
                },
                onNavigateToOTP = { authResponse, cardDetails ->
                    navController.currentBackStackEntry?.savedStateHandle?.set(
                        Constants.DestinationArgs.AUTH_RESPONSE,
                        authResponse.toJson()
                    )
                    navController.currentBackStackEntry?.savedStateHandle?.set(
                        Constants.DestinationArgs.CARD_DETAILS,
                        cardDetails.toJson()
                    )

                    navController.navigate(Destination.OTPScreen.fullRoute)
                },
                scannedCardResult = result,
                proceedToPay = proceedToPay == true
            )
        }

        composable(
            route = Destination.OTPScreen.fullRoute,
            arguments = Destination.OTPScreen.args,
            enterTransition = { null },
            exitTransition = { null }
        ) {
            val previousBackStackEntry = navController.previousBackStackEntry?.savedStateHandle

            val performAuthResponse = previousBackStackEntry
                ?.get<String>(Constants.DestinationArgs.AUTH_RESPONSE)
                ?.let { mapPerformAuthenticateResponse(it) }

            val cardUiModel = previousBackStackEntry
                ?.get<String>(Constants.DestinationArgs.CARD_DETAILS)
                ?.let { cardUiModelFromJson(it) }

            OTPScreen(
                onNavigateBack = {
                    navController.navigateUp()
                },
                onNavigateBackToPay = {
                    navController.previousBackStackEntry?.savedStateHandle?.set(
                        Constants.DestinationArgs.PROCEED_TO_PAY,
                        true
                    )
                    navController.navigateUp()
                },
                authResponse = performAuthResponse,
                cardDetails = cardUiModel,
            )
        }

        composable(route = Destination.CardScanScreen.fullRoute) {
            CardScanScreen(onCardScanned = { result ->
                if (result.success && result.cardData != null) {
                    navController.previousBackStackEntry
                        ?.savedStateHandle
                        ?.set("card_scan_result", result.toJson())
                }
                navController.popBackStack()
            }, onDismiss = {
                navController.popBackStack()
            })
        }
    }
}