package net.geidea.sdk.presentation.features.cardscan.ml.image

/*
 * RenderScript is deprecated, but alternatives are not yet well supported.
 *
 * According to the android developer blog, We should be maintaining two code paths going forward to
 * keep taking advantage of the device GPU for image processing. Native vulkan is only supported on
 * API 29+.
 *
 * https://android-developers.googleblog.com/2021/04/android-gpu-compute-going-forward.html
 *
 * More investigation is needed here to determine what the impact of using the CPU only
 * renderscript-intrinsics-replacement-toolkit vs. native vulkan is.
 *
 * https://github.com/android/renderscript-intrinsics-replacement-toolkit/blob/main/renderscript-toolkit/src/main/java/com/google/android/renderscript/Toolkit.kt
 */
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.YuvImage
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicYuvToRGB
import android.renderscript.Type
import android.util.Size
import androidx.annotation.CheckResult
import androidx.annotation.RestrictTo
import net.geidea.sdk.presentation.features.cardscan.utils.cacheFirstResult

/**
 * Get the RenderScript instance.
 */
internal val getRenderScript = cacheFirstResult { context: Context -> RenderScript.create(context) }

/**
 * An image made of data in the NV21 format.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
class NV21Image(val width: Int, val height: Int, val nv21Data: ByteArray) {

    /**
     * The size of the [NV21Image].
     */
    val size = Size(width, height)

    /**
     * Crop a region of the [NV21Image].
     *
     * https://www.programmersought.com/article/75461140907/
     */
    fun crop(left: Int, top: Int, right: Int, bottom: Int): NV21Image {
        if (left > width || top > height) {
            return NV21Image(0, 0, ByteArray(0))
        }

        if (left == 0 && top == 0 && right == width && bottom == height) {
            return this
        }

        // Take the couple
        val x = left * 2 / 2
        val y = top * 2 / 2
        val w = (right - left) * 2 / 2
        val h = (bottom - top) * 2 / 2

        val yUnit = w * h
        val uv = yUnit / 2
        val nData = ByteArray(yUnit + uv)
        val uvIndexDst = w * h - y / 2 * w
        val uvIndexSrc = width * height + x
        var srcPos0 = y * width
        var destPos0 = 0
        var uvSrcPos0 = uvIndexSrc
        var uvDestPos0 = uvIndexDst
        for (i in y until y + h) {
            System.arraycopy(nv21Data, srcPos0 + x, nData, destPos0, w) // y memory block copy
            srcPos0 += width
            destPos0 += w
            if ((i and 1) == 0) {
                System.arraycopy(nv21Data, uvSrcPos0, nData, uvDestPos0, w) // uv memory block copy
                uvSrcPos0 += width
                uvDestPos0 += w
            }
        }

        return NV21Image(w, h, nData)
    }

    /**
     * Convert to a [YuvImage].
     */
    @CheckResult
    fun toYuvImage() = YuvImage(
        nv21Data,
        ImageFormat.NV21,
        width,
        height,
        null
    )

    /**
     * https://github.com/silvaren/easyrs/blob/c8eed0f0b713bbb1eb375aca23d615677e8adb3c/easyrs/src/main/java/io/github/silvaren/easyrs/tools/YuvToRgb.java
     *
     * TODO: once the renderscript toolkit is available in maven central, replace this method with
     * the yuvToRgbBitmap from that https://github.com/android/renderscript-intrinsics-replacement-toolkit/blob/main/renderscript-toolkit/src/main/java/com/google/android/renderscript/Toolkit.kt#L1079
     */
    fun toBitmap(renderScript: RenderScript): Bitmap {
        val yuvTypeBuilder: Type.Builder =
            Type.Builder(renderScript, Element.U8(renderScript)).setX(nv21Data.size)
        val yuvType: Type = yuvTypeBuilder.create()
        val yuvAllocation = Allocation.createTyped(renderScript, yuvType, Allocation.USAGE_SCRIPT)
        yuvAllocation.copyFrom(nv21Data)

        val rgbTypeBuilder: Type.Builder =
            Type.Builder(renderScript, Element.RGBA_8888(renderScript))
        rgbTypeBuilder.setX(width)
        rgbTypeBuilder.setY(height)
        val rgbAllocation = Allocation.createTyped(renderScript, rgbTypeBuilder.create())

        val yuvToRgbScript =
            ScriptIntrinsicYuvToRGB.create(renderScript, Element.RGBA_8888(renderScript))
        yuvToRgbScript.setInput(yuvAllocation)
        yuvToRgbScript.forEach(rgbAllocation)

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        rgbAllocation.copyTo(bitmap)

        // remove allocated objects
        yuvType.destroy()
        yuvAllocation.destroy()
        rgbAllocation.destroy()
        yuvToRgbScript.destroy()

        return bitmap
    }
}