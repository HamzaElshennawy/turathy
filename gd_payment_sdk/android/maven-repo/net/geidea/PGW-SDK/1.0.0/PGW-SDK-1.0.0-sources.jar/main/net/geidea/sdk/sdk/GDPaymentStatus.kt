package net.geidea.sdk.sdk

enum class GDPaymentStatus {
    SUCCESS,
    PENDING,
    FAILURE,
}