package net.geidea.sdk.core.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme

@Composable
internal fun PoweredByComponent(modifier: Modifier = Modifier, sdkVersion: String = "V 2.3.4") {

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.powered_by),
                style = SdkTheme.typography.medium16,
                color = SdkTheme.colors.onPrimary
            )

            GeideaLogo(logoScale = 0.8f)
        }

        Text(
            text = sdkVersion,
            style = SdkTheme.typography.regular14,
            color = SdkTheme.colors.onPrimary
        )
    }

}