package net.geidea.sdk.core.ui.components

import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.utils.extensions.conditional


@Composable
internal fun GeideaLogo(modifier: Modifier = Modifier, tintColor: Color? = null, logoScale: Float = 1.5f) {
    val gradientBrush =
        Brush.horizontalGradient(listOf(SdkTheme.colors.gradient1A, SdkTheme.colors.gradient1A))

    Icon(
        modifier = modifier
            .wrapContentSize()
            .scale(logoScale)
            .conditional(tintColor == null) {
                graphicsLayer(alpha = 0.99f)
                    .drawWithCache {
                        onDrawWithContent {
                            drawContent()
                            drawRect(
                                brush = gradientBrush, blendMode = BlendMode.SrcAtop
                            )
                        }
                    }
            },
        painter = painterResource(id = R.drawable.geidea_logo),
        contentDescription = "logo",
        tint = tintColor ?: LocalContentColor.current
    )
}
