package net.geidea.sdk.core.ui.validation.validators

import java.util.Calendar

internal object CardValidator {
    internal fun isValidCardNumber(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace("\\s".toRegex(), "")
        return cleaned.length in 13..19 && luhnCheck(cleaned)
    }

    private fun luhnCheck(cardNumber: String): Boolean {
        var sum = 0
        var alternate = false

        for (i in cardNumber.length - 1 downTo 0) {
            var digit = cardNumber[i].toString().toInt()
            if (alternate) {
                digit *= 2
                if (digit > 9) digit -= 9
            }
            sum += digit
            alternate = !alternate
        }
        return sum % 10 == 0
    }

    internal fun isValidExpiryDate(expiry: String): Boolean {
        val regex = Regex("^(0[1-9]|1[0-2])\\/?([0-9]{2}|[0-9]{4})$")
        if (!regex.matches(expiry)) return false

        val parts = expiry.split("/", "-")
        if (parts.size != 2) return false

        val month = parts[0].toIntOrNull() ?: return false
        val year = parts[1].toIntOrNull() ?: return false
        val fullYear = if (year < 100) 2000 + year else year

        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1

        return fullYear > currentYear || (fullYear == currentYear && month >= currentMonth)
    }

    internal fun getCardType(cardNumber: String): String {
        val cleaned = cardNumber.replace("\\s".toRegex(), "")
        return when {
            cleaned.startsWith("4") -> "Visa"
            cleaned.startsWith("5") || cleaned.startsWith("2") -> "Mastercard"
            cleaned.startsWith("3") -> "American Express"
            cleaned.startsWith("6") -> "Discover"
            else -> "Unknown"
        }
    }
}