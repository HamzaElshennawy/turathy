package net.geidea.sdk.sdk

data class GDPaymentResult(
    val orderId: String? = null,
    val tokenId: String? = null,
    val agreementId: String? = null,
    val paymentMethod: PaymentMethodResult? = null,
    )

data class PaymentMethodResult(
    val type: String? = null,
    val brand: String? = null,
    val cardholderName: String? = null,
    val maskedCardNumber: String? = null,
    val wallet: String? = null,
    val expiryDate: ExpiryDateResult? = null
)

data class ExpiryDateResult(
    val month: Int? = null,
    val year: Int? = null
)


fun GDPaymentResult.toReadableString(): String {
    val builder = StringBuilder()

    builder.appendLine("orderId: $orderId")
    builder.appendLine("tokenId: $tokenId")
    builder.appendLine("agreementId: $agreementId")

    builder.appendLine("type: ${paymentMethod?.type}")
    builder.appendLine("brand: ${paymentMethod?.brand}")
    builder.appendLine("cardholderName: ${paymentMethod?.cardholderName}")
    builder.appendLine("maskedCardNumber: ${paymentMethod?.maskedCardNumber}")
    builder.appendLine("wallet: ${paymentMethod?.wallet}")

    builder.appendLine("month: ${paymentMethod?.expiryDate?.month}")
    builder.appendLine("year: ${paymentMethod?.expiryDate?.year}")

    return builder.toString()
}
