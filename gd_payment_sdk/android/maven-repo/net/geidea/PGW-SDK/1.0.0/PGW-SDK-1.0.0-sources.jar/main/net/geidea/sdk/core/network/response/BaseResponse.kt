package net.geidea.sdk.core.network.response


internal sealed class BaseResponse<out T> {
    internal abstract val statusCode: Int
    internal abstract val headers: Map<String, List<String>>
    internal abstract val responseCode: String?
    internal abstract val responseMessage: String?
    internal abstract val detailedResponseMessage: String?

    internal data class Success<T>(
        val data: T,
        override val statusCode: Int,
        override val headers: Map<String, List<String>>,
        override val responseCode: String? = "000",
        override val responseMessage: String? = "Success",
        override val detailedResponseMessage: String? = "The operation was successful"
    ) : BaseResponse<T>()

    internal data class Unauthorized(
        override val statusCode: Int,
        override val headers: Map<String, List<String>>,
        override val responseCode: String? = null,
        override val responseMessage: String? = null,
        override val detailedResponseMessage: String? = null
    ) : BaseResponse<Nothing>()

    internal data class Failure(
        override val statusCode: Int,
        override val headers: Map<String, List<String>>,
        override val responseCode: String? = null,
        override val responseMessage: String? = null,
        override val detailedResponseMessage: String? = null
    ) : BaseResponse<Nothing>()
}
