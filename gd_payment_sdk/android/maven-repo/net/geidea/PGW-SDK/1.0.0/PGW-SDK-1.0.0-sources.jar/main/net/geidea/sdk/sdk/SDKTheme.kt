package net.geidea.sdk.sdk

import android.graphics.drawable.Drawable
import net.geidea.sdk.core.utils.constants.Constants


data class SDKTheme(
    val style: ThemeStyle = ThemeStyle.LIGHT,
    val primaryColor: String? = null,
    val secondaryColor: String? = null,
    val merchantLogo: Drawable? = null
) {
    enum class ThemeStyle { LIGHT, AUTO }

    // Helper methods to get actual colors (with defaults)
    fun getPrimaryColorHex(isDarkTheme: Boolean = false): String {
        return primaryColor ?: if (isDarkTheme) {
            Constants.SDKDefaultColors.PRIMARY_DARK_HEX
        } else {
            Constants.SDKDefaultColors.PRIMARY_HEX
        }
    }

    fun getSecondaryColorHex(isDarkTheme: Boolean = false): String {
        return secondaryColor ?: if (isDarkTheme) {
            Constants.SDKDefaultColors.SECONDARY_DARK_HEX
        } else {
            Constants.SDKDefaultColors.SECONDARY_HEX
        }
    }
}