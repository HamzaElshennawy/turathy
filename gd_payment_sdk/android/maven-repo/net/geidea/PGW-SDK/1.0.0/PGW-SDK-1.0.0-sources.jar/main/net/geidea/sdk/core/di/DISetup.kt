package net.geidea.sdk.core.di

import net.geidea.sdk.core.network.client.HttpClient
import net.geidea.sdk.core.network.client.NetworkClient
import net.geidea.sdk.core.ui.validation.validators.CardNumberValidator
import net.geidea.sdk.core.ui.validation.validators.CvvValidator
import net.geidea.sdk.core.ui.validation.validators.DateValidator
import net.geidea.sdk.core.ui.validation.validators.NameValidator
import net.geidea.sdk.core.ui.validation.validators.PaymentValidators
import net.geidea.sdk.data.repository.PaymentRepositoryImpl
import net.geidea.sdk.data.source.remote.PaymentRemoteDataSource
import net.geidea.sdk.data.source.remote.PaymentRemoteDataSourceImpl
import net.geidea.sdk.domain.repository.PaymentRepository
import net.geidea.sdk.domain.usecase.GetConfigurationUseCase
import net.geidea.sdk.domain.usecase.PayUseCase
import net.geidea.sdk.domain.usecase.PerformAuthUseCase
import net.geidea.sdk.internal.GSDKEnvironment
import net.geidea.sdk.presentation.features.cardscan.viewmodel.CardScanViewModel
import net.geidea.sdk.presentation.features.otp.viewmodel.OTPViewModel
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentViewModel
import net.geidea.sdk.sdk.GDEnvironment
import net.geidea.sdk.sdk.GDPaymentSDKConfiguration
import net.geidea.sdk.sdk.SDKTheme

internal fun setupDependencies(configuration: GDPaymentSDKConfiguration): DependencyContainer {
    return createDependencyContainer {
        // SDK Theme
        registerSingleton<SDKTheme> {
            configuration.theme
        }

        // HTTP Client
        registerSingleton<NetworkClient> {
            val environment: GDEnvironment = GSDKEnvironment()
            HttpClient(
                baseUrl = environment.getBaseUrl(configuration.region),
                language = configuration.language.language,
            )
        }

        // Data Sources
        registerSingleton<PaymentRemoteDataSource> {
            PaymentRemoteDataSourceImpl(
                httpClient = inject<NetworkClient>(),
            )
        }

        // Repositories
        registerSingleton<PaymentRepository> {
            PaymentRepositoryImpl(
                remoteDataSource = inject<PaymentRemoteDataSource>()
            )
        }

        // UseCases
        registerSingleton<GetConfigurationUseCase> {
            GetConfigurationUseCase(
                repository = inject<PaymentRepository>()
            )
        }



        registerSingleton<PerformAuthUseCase> {
            PerformAuthUseCase(
                repository = inject<PaymentRepository>()
            )
        }

        registerSingleton<PayUseCase> {
            PayUseCase(
                repository = inject<PaymentRepository>()
            )
        }

        // Validators
        registerSingleton<NameValidator> {
            NameValidator()
        }

        registerSingleton<CardNumberValidator> {
            CardNumberValidator()
        }
        registerSingleton<CvvValidator> {
            CvvValidator()
        }
        registerSingleton<DateValidator> {
            DateValidator()
        }

        registerSingleton<PaymentValidators> {
            PaymentValidators()
        }


        // ViewModels
        registerViewModel<PaymentViewModel> {
            PaymentViewModel(
                paymentValidators = inject<PaymentValidators>(),
                getConfigurationUseCase = inject<GetConfigurationUseCase>(),
                performAuthUseCase = inject<PerformAuthUseCase>(),
                payUseCase = inject<PayUseCase>(),
                sessionId = configuration.sessionId,
            )
        }

        registerViewModel<OTPViewModel> {
            OTPViewModel()
        }
        registerViewModel<CardScanViewModel> {
            CardScanViewModel()
        }
    }
}