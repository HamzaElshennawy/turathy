package net.geidea.sdk.sdk

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.Composable
import androidx.fragment.app.FragmentManager
import net.geidea.sdk.core.di.setupDependencies
import net.geidea.sdk.internal.GSDKEnvironment
import net.geidea.sdk.presentation.GDPaymentActivity
import net.geidea.sdk.presentation.GDPaymentBottomSheetFragment
import net.geidea.sdk.presentation.GDPaymentFragment

/**
 * Main entry point for the Geidea Payment SDK
 */
class GDPaymentSDK private constructor() {

    companion object {
        @SuppressLint("StaticFieldLeak")
        @Volatile
        private var INSTANCE: GDPaymentSDK? = null

        /**
         * Get shared instance of the SDK
         */
        @JvmStatic
        fun sharedInstance(): GDPaymentSDK {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: GDPaymentSDK().also { INSTANCE = it }
            }
        }
    }

    private var configuration: GDPaymentSDKConfiguration = GDPaymentSDKConfiguration(sessionId = "")
    private var paymentCallback: GDPaymentResultListener? = null

    private var presentationStyle: SDKPresentationStyle? = null

    private var context: Context? = null

    private var currentActivity: Activity? = null

    private lateinit var bottomSheetFragment: GDPaymentBottomSheetFragment

    private val environmentSDK: GDEnvironment = GSDKEnvironment()

    /**
     * @param configurations Includes all configurations like Environment, Language, Session ID, Theme
     */
    internal fun getConfigurations(): GDPaymentSDKConfiguration {
        return this.configuration
    }

    fun getEnvironmentBaseUrl(region: REGION, isSandbox: Boolean): String {
        return environmentSDK.getBaseUrl(region)
    }

    /**
     * Set payment result callback
     */
    fun setPaymentCallback(callback: GDPaymentResultListener) {
        this.paymentCallback = callback
    }

    internal fun getContext(): Context {
        return this.context ?: throw GDPaymentSDKError.NoActivityFound
    }

    /**
     * Start payment flow with Geidea UI
     * @param presentationStyle SDK provides 3 styles of presentation
     * @param context The context to start the payment flow from
     * @throws GDPaymentSDKError if configuration is not set or other presentation errors
     */
    @Throws(GDPaymentSDKError::class)
    fun start(
        configuration: GDPaymentSDKConfiguration,
        context: Context,
        presentationStyle: SDKPresentationStyle? = SDKPresentationStyle.Push(),
    ) {
        this.context = context
        this.presentationStyle = presentationStyle
        this.configuration = configuration
        setupDependencies(
            configuration = configuration,
        )
        // Register fonts if needed (Android equivalent)
        //StyleFont.registerFontsIfNeeded()

        when (presentationStyle) {
            is SDKPresentationStyle.Push -> {
                handlePushPresentation(presentationStyle, context)
            }

            is SDKPresentationStyle.Present -> {
                registerActivity(presentationStyle.activity)
                handlePresentPresentation(presentationStyle)
            }

            is SDKPresentationStyle.BottomSheet -> {
                handleBottomSheetPresentation(presentationStyle, context)
            }

            else -> {
                handlePushPresentation(SDKPresentationStyle.Push(), context)
            }
        }
    }

    // Internal method to handle payment completion
    fun onPaymentCompleted(result: GDPaymentResult) {
        paymentCallback?.onPaymentCompleted(result)
        closeSDK()
    }

    internal fun onPaymentFailed(error: GDPaymentError) {
        paymentCallback?.onPaymentFailure(error)
        closeSDK()
    }

    internal fun onPaymentCanceled() {
        closeSDK()
        paymentCallback?.onPaymentCanceled()
    }

    private fun handlePushPresentation(style: SDKPresentationStyle.Push, context: Context) {
        val activity = style.activity ?: ViewControllerUtils.findActivity(context)
        ?: throw GDPaymentSDKError.NoActivityFound

        startPaymentActivity(activity)
    }

    private fun handlePresentPresentation(
        style: SDKPresentationStyle.Present
    ): (@Composable () -> Unit)? {

        return when (val presentationType = style.presentationType) {
            is SDKPresentationStyle.Present.PresentationType.Fragment -> {
                addPaymentFragment(presentationType.fragmentManager, presentationType.containerId)
                null
            }
        }
    }

    private fun handleBottomSheetPresentation(
        style: SDKPresentationStyle.BottomSheet,
        context: Context
    ) {
        val activity = style.activity ?: ViewControllerUtils.findActivity(context)
        ?: throw GDPaymentSDKError.NoActivityFound

        // Validate activity type for bottom sheet
        if (activity !is ComponentActivity) {
            throw GDPaymentSDKError.BottomSheetRequiresAppCompatActivity
        }
        registerActivity(activity)

        // Validate max height if provided
        style.maxHeightDp?.let { maxHeight ->
            val screenHeight = ViewControllerUtils.getScreenHeightDp(activity)
            if (maxHeight > screenHeight) {
                throw GDPaymentSDKError.MaxHeightExceedsScreenHeight
            }
        }
        showBottomSheetFragment(activity, style.maxHeightDp)
    }

    private fun startPaymentActivity(activity: Activity) {
        val intent = Intent(activity, GDPaymentActivity::class.java)
        activity.startActivity(intent)
    }

    private fun addPaymentFragment(fragmentManager: FragmentManager, containerId: Int) {
        try {
            val fragment = GDPaymentFragment.newInstance()
            fragmentManager.beginTransaction()
                .replace(containerId, fragment, GDPaymentFragment.TAG)
                .addToBackStack(GDPaymentFragment.TAG)
                .commit()
        } catch (e: Exception) {
            throw GDPaymentSDKError.FragmentManagerNotFound
        }
    }

    private fun showBottomSheetFragment(activity: Activity?, maxHeightDp: Float?) {
        try {
            val fragmentActivity = activity as? AppCompatActivity
            if (fragmentActivity != null) {
                bottomSheetFragment = GDPaymentBottomSheetFragment.newInstance(maxHeightDp)
                bottomSheetFragment.show(
                    activity.supportFragmentManager,
                    GDPaymentBottomSheetFragment.TAG
                )
            } else {
                // Fallback if not a FragmentActivity
                throw GDPaymentSDKError.BottomSheetRequiresAppCompatActivity
            }
        } catch (e: Exception) {
            throw GDPaymentSDKError.FragmentManagerNotFound
        }
    }


    internal fun registerActivity(activity: Activity) {
        currentActivity = activity
    }

    internal fun unregisterActivity(activity: Activity) {
        if (currentActivity == activity) {
            currentActivity = null
        }
    }

    internal fun getCurrentActivity(): Activity? {
        return currentActivity
    }


    internal fun closeSDK() {
        when (presentationStyle) {
            is SDKPresentationStyle.Push -> {
                getCurrentActivity()?.finish()
            }

            is SDKPresentationStyle.Present -> {
                when (val type =
                    (presentationStyle as SDKPresentationStyle.Present).presentationType) {
                    is SDKPresentationStyle.Present.PresentationType.Fragment -> {
                        type.fragmentManager.popBackStack()
                    }

//                    is SDKPresentationStyle.Present.PresentationType.Composable -> {
//                        //TODO handle present compose close sdk
//                    }
                }
            }

            is SDKPresentationStyle.BottomSheet -> {
                bottomSheetFragment.dismissAllowingStateLoss()
            }

            null -> {

            }
        }
    }

}