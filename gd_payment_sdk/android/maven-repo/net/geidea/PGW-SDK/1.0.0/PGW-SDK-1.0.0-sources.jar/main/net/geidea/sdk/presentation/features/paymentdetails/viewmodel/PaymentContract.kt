package net.geidea.sdk.presentation.features.paymentdetails.viewmodel

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import net.geidea.sdk.core.mvi.BaseEffect
import net.geidea.sdk.core.mvi.ErrorEvent
import net.geidea.sdk.core.mvi.ViewEvent
import net.geidea.sdk.core.mvi.ViewState
import net.geidea.sdk.domain.model.pay.PerformAuthenticateResponse
import net.geidea.sdk.domain.model.pay.ThreeDSecureResponse
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.CardUiModel
import net.geidea.sdk.presentation.features.paymentdetails.components.card.savedcard.SavedCardsState
import net.geidea.sdk.presentation.features.paymentdetails.components.header.PaymentHeaderState
import net.geidea.sdk.presentation.features.paymentdetails.components.paymentmethods.PaymentMethodsState

@Immutable
@Stable
internal data class PaymentState(
    override val isLoading: Boolean = false,
    internal val showOverlayLoading: Boolean = false,
    internal val showReceiptDialog: Boolean = false,
    override val errorEvent: ErrorEvent? = null,
    override val isOverlayError: Boolean = false,
    override val isFullScreenError: Boolean = false,
    internal val paymentResponse: ThreeDSecureResponse? = null,
    internal val showShippingDetailsLabel: Boolean = false,
    internal val paymentHeaderState: PaymentHeaderState = PaymentHeaderState(),
    internal val paymentMethodState: PaymentMethodsState = PaymentMethodsState(),
    internal val savedCardsState: SavedCardsState = SavedCardsState(),
    internal val cardDetailsState: CardUiModel = CardUiModel(),
    internal val authResponse: PerformAuthenticateResponse? = null,
    internal val paymentOperation: String? = null,
) : ViewState


internal interface PaymentEvent : ViewEvent {
    data object LoadData : PaymentEvent
    data object SubmitClicked : PaymentEvent
    data object ScrollingStarted : PaymentEvent
    data object ScanCardClicked : PaymentEvent
    data object ProceedToPay : PaymentEvent
    data object DismissReceipt : PaymentEvent

}


internal sealed interface PaymentEffect : BaseEffect {
    data class NavigateToOTP(
        internal val authResponse: PerformAuthenticateResponse,
        internal val cardDetails: CardUiModel,
    ) : PaymentEffect

    data object NavigateToCardScan : PaymentEffect

    data class ShowReceipt(
        internal val response: ThreeDSecureResponse? = null,
        internal val isSuccess: Boolean = false,
        internal val errorMessage: String? = "Payment operation failed",
    ) : PaymentEffect
}
