package net.geidea.sdk.sdk

sealed class GDPaymentSDKError(message: String) : Exception(message) {
    object ConfigurationNotSet : GDPaymentSDKError("SDK configuration is not set. Call setConfigurations() first.")
    object PushIsOnlySupportedInViewContext : GDPaymentSDKError("Push presentation is only supported in View context, not in Compose.")
    object NoActivityFound : GDPaymentSDKError("No activity found to present the payment flow.")
    object BottomSheetRequiresAppCompatActivity : GDPaymentSDKError("Bottom sheet presentation requires AppCompatActivity.")
    object MaxHeightExceedsScreenHeight : GDPaymentSDKError("Maximum height exceeds screen height.")
    object FragmentManagerNotFound : GDPaymentSDKError("Fragment manager not found.")
}