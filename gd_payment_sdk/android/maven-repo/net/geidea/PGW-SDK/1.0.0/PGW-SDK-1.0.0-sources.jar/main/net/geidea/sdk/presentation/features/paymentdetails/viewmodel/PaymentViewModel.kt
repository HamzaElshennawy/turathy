package net.geidea.sdk.presentation.features.paymentdetails.viewmodel

import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import net.geidea.sdk.core.mvi.BaseViewModel
import net.geidea.sdk.core.mvi.ErrorEvent
import net.geidea.sdk.core.mvi.ViewEvent
import net.geidea.sdk.core.ui.validation.validators.PaymentValidators
import net.geidea.sdk.core.utils.constants.Constants
import net.geidea.sdk.domain.model.GatewayDecision
import net.geidea.sdk.domain.model.pay.GetPerformAuthenticateResponse
import net.geidea.sdk.domain.model.pay.PayRequest
import net.geidea.sdk.domain.model.pay.PayResponse
import net.geidea.sdk.domain.model.pay.PaymentMethod
import net.geidea.sdk.domain.model.pay.PerformAuthRequest
import net.geidea.sdk.domain.model.pay.PerformAuthenticateResponse
import net.geidea.sdk.domain.usecase.GetConfigurationUseCase
import net.geidea.sdk.domain.usecase.PayUseCase
import net.geidea.sdk.domain.usecase.PerformAuthUseCase
import net.geidea.sdk.presentation.features.paymentdetails.components.card.carddetails.CardDetailsEvent
import net.geidea.sdk.presentation.features.paymentdetails.components.card.carddetails.reduceCardDetailsState
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.CardUiModel
import net.geidea.sdk.presentation.features.paymentdetails.components.card.savedcard.SavedCardEvent
import net.geidea.sdk.presentation.features.paymentdetails.components.card.savedcard.SavedCardsState
import net.geidea.sdk.presentation.features.paymentdetails.components.card.savedcard.reduceSavedCardState
import net.geidea.sdk.presentation.features.paymentdetails.components.header.PaymentHeaderEvent
import net.geidea.sdk.presentation.features.paymentdetails.components.header.reducePaymentHeaderState
import net.geidea.sdk.presentation.features.paymentdetails.components.paymentmethods.PaymentMethodsEvent
import net.geidea.sdk.presentation.features.paymentdetails.components.paymentmethods.reducePaymentMethodState
import net.geidea.sdk.sdk.ExpiryDateResult
import net.geidea.sdk.sdk.GDPaymentResult
import net.geidea.sdk.sdk.GDPaymentSDK
import net.geidea.sdk.sdk.PaymentMethodResult


internal class PaymentViewModel(
    private val paymentValidators: PaymentValidators,
    private val getConfigurationUseCase: GetConfigurationUseCase,
    private val performAuthUseCase: PerformAuthUseCase,
    private val payUseCase: PayUseCase,
    private val sessionId: String,
) : BaseViewModel<PaymentState, PaymentEvent, PaymentEffect>() {


    init {
        fetchConfiguration()
    }

    override fun createInitialState(): PaymentState = PaymentState()

    override fun handleEvent(event: ViewEvent) {
        when (event) {
            is PaymentEvent.LoadData -> fetchConfiguration()
            is PaymentEvent.SubmitClicked -> submitData()
            is ViewEvent.ClearError -> {
                setState {
                    copy(
                        errorEvent = null,
                        isOverlayError = false,
                        isFullScreenError = true,
                    )
                }
            }

            is ViewEvent.ClearOvelayError -> {
                setState {
                    copy(
                        errorEvent = null,
                        isOverlayError = true,
                        isFullScreenError = false,
                    )
                }
            }

            is PaymentHeaderEvent -> {
                setState {
                    copy(
                        paymentHeaderState = reducePaymentHeaderState(
                            state = paymentHeaderState, event = event
                        )
                    )
                }
            }


            is SavedCardEvent -> setState {
                copy(
                    savedCardsState = reduceSavedCardState(
                        savedCardsState,
                        event = event,
                        paymentValidators
                    )
                )
            }

            is CardDetailsEvent -> {

                setState {
                    copy(
                        cardDetailsState = reduceCardDetailsState(
                            cardDetailsState,
                            event = event,
                            paymentValidators
                        )
                    )
                }
            }

            is PaymentEvent.ScanCardClicked -> {
                emitEffect(PaymentEffect.NavigateToCardScan)
            }

            is PaymentEvent.ScrollingStarted -> {
                setState {
                    copy(
                        paymentHeaderState = paymentHeaderState.copy(
                            isExpanded = false
                        )
                    )
                }
            }

            is PaymentMethodsEvent -> {
                setState {
                    copy(
                        paymentMethodState = reducePaymentMethodState(
                            state = paymentMethodState,
                            event = event
                        )
                    )
                }
            }

            is PaymentEvent.ProceedToPay -> {
                proceedToPay()
            }

            is PaymentEvent.DismissReceipt -> {
                setState { copy(showReceiptDialog = false) }

                val response = state.value.paymentResponse

                GDPaymentSDK.sharedInstance().onPaymentCompleted(
                    GDPaymentResult(
                        orderId = response?.orderId,
                        tokenId = response?.tokenId,
                        agreementId = response?.agreementId,
                        paymentMethod = response?.paymentMethod?.let { pm ->
                            PaymentMethodResult(
                                type = pm.type,
                                brand = pm.brand,
                                cardholderName = pm.cardholderName,
                                maskedCardNumber = pm.maskedCardNumber,
                                wallet = pm.wallet,
                                expiryDate = pm.expiryDate?.let { exp ->
                                    ExpiryDateResult(
                                        month = exp.month,
                                        year = exp.year
                                    )
                                }
                            )
                        },
                    )
                )
            }
        }

    }


    private fun fetchConfiguration() {
        collectResponse(
            flow = getConfigurationUseCase.getConfiguration(),
            onSuccess = { config ->
                setState {
                    copy(
                        showShippingDetailsLabel = config.merchantConfigurations?.needsShippingAddress == true ||
                                config.merchantConfigurations?.needsBillingAddress == true,
                        paymentHeaderState = paymentHeaderState.copy(
                            currency = config.orderSummary?.currency.orEmpty(),
                            total = config.orderSummary?.total?.toDouble() ?: 0.0,
                            subTotal = config.orderSummary?.subTotal?.toDouble() ?: 0.0,
                            ordersItems = config.orderSummary?.ordersItems.orEmpty(),
                            ordersDetails = config.orderSummary?.orderDetails ?: emptyList()
                        ),
                        paymentMethodState = paymentMethodState.copy(
                            paymentMethods = config.paymentMethods.orEmpty(),
                            selectedMethod = paymentMethodState.selectedMethod
                                ?: config.paymentMethods?.firstOrNull()
                        ),
                        cardDetailsState = cardDetailsState.copy(
                            supportedCards = config.paymentMethods?.getOrNull(0)?.supportedCards
                                ?: listOf(),
                            showSavedCard = config.savedCards?.eligibleToSaveCard == true
                        ),
                        paymentOperation = config.paymentOperation,
                        errorEvent = null,
                    )
                }
            },
            onError = { errorEvent ->
                setState {
                    copy(
                        isLoading = false,
                        isFullScreenError = true,
                        errorEvent = errorEvent
                    )
                }
            },
            loadingState = { isLoading ->
                setState { copy(isLoading = isLoading) }
            }
        )
    }


    private fun validateCardDetails(
        state: PaymentState
    ): Pair<SavedCardsState, CardUiModel> {
        val validatedSavedCards = reduceSavedCardState(
            state.savedCardsState,
            SavedCardEvent.ValidateCardSelection,
            paymentValidators
        )

        val validatedCard = reduceCardDetailsState(
            state.cardDetailsState,
            CardDetailsEvent.ValidateAllFields,
            paymentValidators
        )

        return validatedSavedCards to validatedCard
    }

    private fun validateAllFieldsAndUpdateState(): Boolean {
        val currentState = state.value



        val (validatedSavedCards, validatedCard) =
            if (!currentState.savedCardsState.showAddNewCardRow ||
                currentState.savedCardsState.cards.isEmpty()
            ) {
                validateCardDetails(currentState)
            } else {
                currentState.savedCardsState to currentState.cardDetailsState
            }

        val newState = currentState.copy(
            savedCardsState = validatedSavedCards,
            cardDetailsState = validatedCard
        )

        if (newState != currentState) {
            setState { newState }
        }


        val isCardSelectionValid = validatedSavedCards.selectedCard != null
        val isCardFieldsValid = validatedCard.isValid

        val isCardValid =
            if (validatedSavedCards.showAddNewCardRow) {
                isCardFieldsValid
            } else {
                isCardSelectionValid && isCardFieldsValid
            }

        return isCardValid
    }

    private fun submitData() {
        viewModelScope.launch {
            val isValid = validateAllFieldsAndUpdateState()
            if (!isValid) return@launch

            collectResponse(
                flow = performAuth(),
                onSuccess = { response ->
                    setState {
                        copy(
                            authResponse = response,
                            showOverlayLoading = false
                        )
                    }

                    when (response.gatewayDecision) {

                        GatewayDecision.Reject.name -> {
                            setState {
                                copy(
                                    errorEvent = ErrorEvent.GeneralError(),
                                    isOverlayError = true
                                )
                            }
                        }

                        GatewayDecision.ContinueToPay.name -> {
                            val htmlBody = response.htmlBodyContent
                            setState { copy(authResponse = response) }
                            if (!htmlBody.isNullOrEmpty()) {
                                emitEffect(
                                    PaymentEffect.NavigateToOTP(
                                        response,
                                        state.value.cardDetailsState
                                    )
                                )
                            } else {
                                proceedToPay()
                            }
                        }

                        GatewayDecision.ContinueToPayer.name,
                        GatewayDecision.ProceedToCReq.name,
                            -> {
                            val htmlBody = response.htmlBodyContent
                            if (htmlBody.isNullOrEmpty()) {
                                setState {
                                    copy(
                                        errorEvent = ErrorEvent.GeneralError(),
                                        isOverlayError = true
                                    )
                                }
                            } else {
                                setState { copy(authResponse = response) }
                                emitEffect(
                                    PaymentEffect.NavigateToOTP(
                                        response,
                                        state.value.cardDetailsState
                                    )
                                )
                            }
                        }

                        GatewayDecision.ContinueToPayWithNotEnrolledCard.name -> {
                            proceedToPay()
                        }

                        else -> {
                            setState {
                                copy(
                                    errorEvent = ErrorEvent.GeneralError(),
                                    isOverlayError = true
                                )
                            }
                        }
                    }

                },
                onError = { error ->
                    setState {
                        copy(
                            errorEvent = ErrorEvent.BusinessError(
                                responseMessage = error.responseMessage,
                                detailedResponseMessage = error.detailedResponseMessage,
                                messageRes = error.messageRes,
                            ),
                            isOverlayError = true
                        )
                    }
                },
                loadingState = {
                    setState { copy(showOverlayLoading = it) }
                }
            )
        }
    }


    private fun performAuth(): Flow<GetPerformAuthenticateResponse> {


        return performAuthUseCase.performAuth(
            PerformAuthRequest(
                paymentOperation = state.value.paymentOperation,
                sessionId = sessionId,
                cardOnFile = if (state.value.paymentOperation
                    == Constants.PaymentOperation.SAVE_CARD
                ) true
                else state.value.cardDetailsState.isCardSaved,
                paymentMethod = PaymentMethod(
                    expiryDate = state.value.cardDetailsState.expiryDate.value.replace("/", "|"),
                    cvv = state.value.cardDetailsState.cvv.value,
                    cardNumber = state.value.cardDetailsState.cardNumber.value,
                    cardholderName = state.value.cardDetailsState.nameOnCard.value.trim()
                        .replace(Regex("\\s{2,}"), " ")
                ),
            )
        )
    }


    private fun pay(authResponse: PerformAuthenticateResponse): Flow<PayResponse> {
        return payUseCase.execute(
            PayRequest(
                threeDSecureId = authResponse.threeDSecureId,
                orderId = authResponse.orderId,
                sessionId = sessionId,
                source = Constants.SDK_SOURCE,
                paymentMethod = PaymentMethod(
                    expiryDate = state.value.cardDetailsState.expiryDate.value.replace(
                        "/",
                        "|"
                    ),
                    cvv = state.value.cardDetailsState.cvv.value,
                    cardNumber = state.value.cardDetailsState.cardNumber.value,
                    cardholderName = state.value.cardDetailsState.nameOnCard.value.trim()
                        .replace(Regex("\\s{2,}"), " ")
                ),
            )
        )
    }

    private fun proceedToPay() {
        val authResponse = state.value.authResponse
        if (authResponse != null) {
            collectResponse(
                flow = pay(authResponse = authResponse),
                onSuccess = { response ->
                    setState {
                        copy(
                            showReceiptDialog = true,
                            paymentResponse = response
                        )
                    }
                },
                onError = { error ->
                    setState {
                        copy(
                            errorEvent = ErrorEvent.BusinessError(
                                responseMessage = error.responseMessage,
                                detailedResponseMessage = error.detailedResponseMessage,
                                messageRes = error.messageRes,
                            ),
                            isOverlayError = true,
                        )
                    }
                },
                loadingState = { setState { copy(showOverlayLoading = it) } }
            )
        }
    }
}
