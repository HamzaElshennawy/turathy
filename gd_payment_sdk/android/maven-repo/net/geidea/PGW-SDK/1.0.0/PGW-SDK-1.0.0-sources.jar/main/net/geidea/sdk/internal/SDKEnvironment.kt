package net.geidea.sdk.internal

internal sealed class SDKEnvironment(val baseUrl: String) {

    // --- EGY ---
    data object EgyptDev : SDKEnvironment("https://api.dev.geidea.net/")
    data object EgyptTest : SDKEnvironment("https://api.test.geidea.net/")
    data object EgyptPreprod : SDKEnvironment("https://api.gd-pprod-infra.net/")
    data object EgyptProd : SDKEnvironment("https://api.merchant.geidea.net/")

    // --- KSA ---
    data object KsaDev : SDKEnvironment("https://api.dev.geidea.net/")
    data object KsaTest : SDKEnvironment("https://api.test.geidea.net/")
    data object KsaPreprod : SDKEnvironment("https://api.gd-pprod-infra.net/")

    data object KsaProd : SDKEnvironment("https://api.ksamerchant.geidea.net/")

    // --- UAE ---
    data object UaeTest : SDKEnvironment("https://api.uae-test.geidea.net/")
    data object UaePreprod : SDKEnvironment("https://api.staging.geidea.ae/")
    data object UaeProd : SDKEnvironment("https://api.merchant.geidea.ae/")
}
