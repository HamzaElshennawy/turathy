package net.geidea.sdk.sdk

interface GDPaymentResultListener {
    fun onPaymentCompleted(result: GDPaymentResult)
    fun onPaymentFailure(error: GDPaymentError)
    fun onPaymentCanceled()
}