package net.geidea.sdk.core.utils.extensions

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

internal fun getCurrentTimestamp(): String {
    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    dateFormat.timeZone = TimeZone.getDefault()
    return dateFormat.format(Date())
}


internal fun formatExpiryDate(calendar: Calendar): String {
    val monthStr =
        (calendar.get(Calendar.MONTH) + 1).toString().padStart(2, '0')
    val yearStr = calendar.get(Calendar.YEAR).toString().takeLast(2)
    return "$monthStr/$yearStr"
}


internal fun getCurrentMonth(): Int {
    val calendar = Calendar.getInstance()
    return calendar.get(Calendar.MONTH) + 1
}

internal fun getCurrentYear(): Int {
    val calendar = Calendar.getInstance()
    return calendar.get(Calendar.YEAR)
}
