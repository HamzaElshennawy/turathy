package net.geidea.sdk.presentation.features.paymentdetails.components.paymentmethods

import net.geidea.sdk.core.utils.extensions.updateIfChanged
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent

internal fun reducePaymentMethodState(
    state: PaymentMethodsState,
    event: PaymentEvent
) = when (event) {

    is PaymentMethodsEvent.OnMethodSelected ->
        updateIfChanged(state, state.selectedMethod, event.method) {
            copy(selectedMethod = event.method)
        }

    else -> state
}
