package net.geidea.sdk.presentation.features.paymentdetails.components.card.savedcard

import kotlinx.collections.immutable.toPersistentList
import net.geidea.sdk.core.ui.models.TextFieldInput
import net.geidea.sdk.core.ui.models.updateTextField
import net.geidea.sdk.core.ui.validation.ValidationResult
import net.geidea.sdk.core.ui.validation.validators.PaymentValidators
import net.geidea.sdk.core.utils.extensions.updateIfChanged
import net.geidea.sdk.presentation.features.paymentdetails.components.card.model.CardUiModel
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentEvent


private fun CardUiModel.clearCvvIfNeeded() =
    if (cvv.value.isNotEmpty() || !cvv.validation.isValid) {
        copy(cvv = TextFieldInput("", ValidationResult(true)))
    } else this


internal fun reduceSavedCardState(
    state: SavedCardsState,
    event: PaymentEvent,
    paymentValidators: PaymentValidators
) = when (event) {

    is SavedCardEvent.AddNewCard -> updateIfChanged(
        state = state,
        currentValue = Triple(state.selectedCard, state.showAddNewCardRow, state.cards),
        newValue = Triple(
            null, false, state.cards.map { it.clearCvvIfNeeded() }.toPersistentList()
        )
    ) {
        copy(
            selectedCard = null,
            showAddNewCardRow = false,
            showCardSelectionError = false,
            cards = state.cards.map { it.clearCvvIfNeeded() }.toPersistentList()
        )
    }


    is SavedCardEvent.CardSelected -> updateIfChanged(
        state = state,
        currentValue = Pair(state.selectedCard, state.showAddNewCardRow),
        newValue = Pair(event.card, true)
    ) {
        copy(
            selectedCard = event.card,
            showAddNewCardRow = true,
            showCardSelectionError = false,
            cards = state.cards.map {
                if (it.id == state.selectedCard?.id) it.clearCvvIfNeeded() else it
            }.toPersistentList()
        )
    }

    is SavedCardEvent.CVVChanged -> {
        val updatedCards = state.cards.map { card ->
            if (card.id == event.cardId) {
                updateIfChanged(
                    state = card,
                    currentValue = card.cvv.value,
                    newValue = event.cvv,
                    validator = paymentValidators.cvv
                ) { validation ->
                    copy(cvv = TextFieldInput(event.cvv, validation))
                }
            } else card
        }
        if (updatedCards == state.cards) state
        else state.copy(cards = updatedCards.toPersistentList())
    }

    is SavedCardEvent.ValidateCardSelection -> {
        val noCardSelected = state.selectedCard == null

        if (noCardSelected) {
            // No card selected, just update the error flags directly
            state.copy(
                showCardSelectionError = true, showCvvError = false
            )
        } else {
            // Validate CVV on the selected card
            val currentCvvField = state.selectedCard.cvv
            val validatedCvv = updateTextField(currentCvvField.value, paymentValidators.cvv)

            // Update cards list with the validated CVV if changed
            val updatedCards = state.cards.map { card ->
                if (card.id == state.selectedCard.id) {
                    if (card.cvv == validatedCvv) card else card.copy(cvv = validatedCvv)
                } else card
            }.toPersistentList()

            // Updated selectedCard reference with validated CVV
            val updatedSelectedCard = updatedCards.first { it.id == state.selectedCard.id }

            // Determine if CVV is valid now
            val cvvInvalid = !validatedCvv.validation.isValid

            // Only copy if anything changed
            if (updatedSelectedCard == state.selectedCard && !state.showCardSelectionError && state.showCvvError == cvvInvalid) {
                state
            } else {
                state.copy(
                    cards = updatedCards,
                    selectedCard = updatedSelectedCard,
                    showCardSelectionError = false,
                    showCvvError = cvvInvalid
                )
            }
        }
    }


    else -> state
}
