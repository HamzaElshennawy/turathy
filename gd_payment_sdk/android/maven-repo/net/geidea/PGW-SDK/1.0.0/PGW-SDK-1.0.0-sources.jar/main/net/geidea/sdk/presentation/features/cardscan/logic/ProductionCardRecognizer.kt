package net.geidea.sdk.presentation.features.cardscan.logic

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import net.geidea.sdk.core.ui.validation.validators.CardValidator
import net.geidea.sdk.presentation.features.cardscan.ScannedCardData
import kotlin.coroutines.resume
import kotlin.math.abs

internal class ProductionCardRecognizer {

    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    // Separate history for each field for better accuracy
    private val cardNumberHistory = mutableListOf<String>()
    private val expiryHistory = mutableListOf<String>()
    private val nameHistory = mutableListOf<String>()

    private val maxHistorySize = 6 // Sweet spot for speed vs accuracy

    // Bank/card issuer keywords to ignore
    private val ignoreKeywords = setOf(
        "VISA", "MASTERCARD", "MASTER", "CARD", "AMERICAN", "EXPRESS",
        "AMEX", "DISCOVER", "BANK", "DEBIT", "CREDIT", "PLATINUM",
        "GOLD", "CLASSIC", "SIGNATURE", "MEMBER", "SINCE", "BANK", "BUNK", "BANQUE", "MISR"
    )

    internal suspend fun extractCardData(bitmap: Bitmap): ScannedCardData =
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)

            textRecognizer.process(image)
                .addOnSuccessListener { visionText ->

                    // Extract each field independently
                    val cardNumber = extractCardNumber(visionText)
                    val expiry = extractExpiry(visionText)
                    val name = extractName(visionText)

                    // Add to history
                    if (cardNumber.isNotEmpty()) {
                        cardNumberHistory.add(cardNumber)
                        if (cardNumberHistory.size > maxHistorySize) {
                            cardNumberHistory.removeAt(0)
                        }
                    }

                    if (expiry.isNotEmpty()) {
                        expiryHistory.add(expiry)
                        if (expiryHistory.size > maxHistorySize) {
                            expiryHistory.removeAt(0)
                        }
                    }

                    if (name.isNotEmpty()) {
                        nameHistory.add(name)
                        if (nameHistory.size > maxHistorySize) {
                            nameHistory.removeAt(0)
                        }
                    }

                    // Build consensus
                    val consensusNumber = getConsensus(cardNumberHistory)
                    val consensusExpiry = getConsensus(expiryHistory)
                    val consensusName = getConsensus(nameHistory)

                    // Calculate confidence
                    val numberConfidence = getConfidence(consensusNumber, cardNumberHistory)
                    val expiryConfidence = getConfidence(consensusExpiry, expiryHistory)
                    val nameConfidence = getConfidence(consensusName, nameHistory)

                    val overallConfidence = (numberConfidence * 0.6f) +
                            (expiryConfidence * 0.2f) +
                            (nameConfidence * 0.2f)

                    val isValid = consensusNumber.isNotEmpty() && numberConfidence >= 0.5f

                    Log.d("CardRecognizer", "Number: $consensusNumber (conf: $numberConfidence)")
                    Log.d("CardRecognizer", "Expiry: $consensusExpiry (conf: $expiryConfidence)")
                    Log.d("CardRecognizer", "Name: $consensusName (conf: $nameConfidence)")
                    Log.d("CardRecognizer", "Overall: $overallConfidence, Valid: $isValid")

                    continuation.resume(
                        ScannedCardData(
                            cardNumber = consensusNumber,
                            expiryDate = consensusExpiry,
                            cardHolderName = consensusName,
                            isValid = isValid,
                            confidence = overallConfidence
                        )
                    )
                }
                .addOnFailureListener {
                    continuation.resume(ScannedCardData())
                }
        }

    /**
     * Extract card number - Priority #1
     */
    private fun extractCardNumber(visionText: Text): String {
        val candidates = mutableListOf<Pair<String, Float>>()

        // Strategy 1: Find complete 16-digit pattern
        for (block in visionText.textBlocks) {
            if (shouldIgnoreBlock(block.text)) continue

            val blockText = block.text

            // Match various formats
            val patterns = listOf(
                Regex("\\b\\d{4}\\s+\\d{4}\\s+\\d{4}\\s+\\d{4}\\b"),
                Regex("\\b\\d{4}-\\d{4}-\\d{4}-\\d{4}\\b"),
                Regex("\\b\\d{16}\\b"),
                Regex("\\b\\d{4}[•·]\\d{4}[•·]\\d{4}[•·]\\d{4}\\b")
            )

            for (pattern in patterns) {
                pattern.findAll(blockText).forEach { match ->
                    val number = match.value.filter { it.isDigit() }
                    if (number.length == 16 && CardValidator.isValidCardNumber(number)) {
                        candidates.add(number to 1.0f)
                    }
                }
            }
        }

        // Strategy 2: Collect 4-digit groups spatially
        val digitGroups = mutableListOf<DigitGroup>()

        for (block in visionText.textBlocks) {
            if (shouldIgnoreBlock(block.text)) continue

            for (line in block.lines) {
                for (element in line.elements) {
                    val cleaned = element.text.filter { it.isDigit() }
                    if (cleaned.length == 4) {
                        element.boundingBox?.let { bounds ->
                            digitGroups.add(
                                DigitGroup(cleaned, bounds, bounds.centerY())
                            )
                        }
                    }
                }
            }
        }

        // Group by Y position (same horizontal line)
        val lines = digitGroups.groupBy { (it.centerY / 30).toInt() }

        for ((_, groups) in lines) {
            if (groups.size >= 4) {
                val sorted = groups.sortedBy { it.bounds.left }

                // Try combinations of 4 consecutive groups
                for (i in 0..groups.size - 4) {
                    val fourGroups = sorted.subList(i, i + 4)
                    val number = fourGroups.joinToString("") { it.digits }

                    if (CardValidator.isValidCardNumber(number)) {
                        // Check spacing consistency
                        val spacings = fourGroups.zipWithNext { a, b ->
                            b.bounds.left - a.bounds.right
                        }
                        val avgSpacing = spacings.average()
                        val variance = spacings.map { abs(it - avgSpacing) }.average()
                        val confidence = 1.0f - (variance / avgSpacing).toFloat().coerceIn(0f, 0.5f)

                        candidates.add(number to confidence)
                    }
                }
            }
        }

        // Strategy 3: Amex (15 digits)
        for (block in visionText.textBlocks) {
            if (shouldIgnoreBlock(block.text)) continue

            val cleaned = block.text.filter { it.isDigit() }
            if (cleaned.length == 15 && CardValidator.isValidCardNumber(cleaned)) {
                candidates.add(cleaned to 0.95f)
            }
        }

        // Return highest confidence candidate
        return candidates.maxByOrNull { it.second }?.first ?: ""
    }

    /**
     * Extract expiry date
     */
    private fun extractExpiry(visionText: Text): String {
        val candidates = mutableListOf<Pair<String, Float>>()

        val patterns = listOf(
            // MM/YY
            Regex("\\b(0[1-9]|1[0-2])/([0-9]{2})\\b"),
            // MM/YYYY
            Regex("\\b(0[1-9]|1[0-2])/([2][0-9]{3})\\b"),
            // With keywords
            Regex("(?:VALID|EXP|EXPIRES)\\s*(?:THRU)?\\s*:?\\s*(0[1-9]|1[0-2])/([0-9]{2})", RegexOption.IGNORE_CASE),
            // MM-YY or MM YY
            Regex("\\b(0[1-9]|1[0-2])[-\\s]([0-9]{2})\\b")
        )

        for (block in visionText.textBlocks) {
            val blockText = block.text
            val hasKeyword = blockText.contains(Regex("VALID|EXP|THRU", RegexOption.IGNORE_CASE))

            for (pattern in patterns) {
                pattern.findAll(blockText).forEach { match ->
                    val date = match.groupValues.drop(1).joinToString("/")
                    val normalized = normalizeExpiry(date)

                    if (CardValidator.isValidExpiryDate(normalized)) {
                        val confidence = if (hasKeyword) 1.0f else 0.7f
                        candidates.add(normalized to confidence)
                    }
                }
            }
        }

        return candidates.maxByOrNull { it.second }?.first ?: ""
    }

    /**
     * Extract cardholder name
     */
    private fun extractName(visionText: Text): String {
        val candidates = mutableListOf<Pair<String, Float>>()

        val cardHeight = visionText.textBlocks.maxOfOrNull {
            it.boundingBox?.bottom ?: 0
        } ?: 1

        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                val lineText = line.text.trim()

                // Skip if contains numbers, slashes, or card keywords
                if (lineText.any { it.isDigit() || it == '/' }) continue
                if (shouldIgnoreBlock(lineText)) continue

                // Must be 2-4 words
                val words = lineText.split(Regex("\\s+")).filter { it.isNotEmpty() }
                if (words.size !in 2..4) continue

                // Must be 10-30 characters
                if (lineText.length !in 10..30) continue

                // Check uppercase ratio
                val letters = lineText.count { it.isLetter() }
                if (letters == 0) continue

                val upperRatio = lineText.count { it.isUpperCase() }.toFloat() / letters
                if (upperRatio < 0.7f) continue

                // Calculate confidence based on position (names usually bottom half)
                val bounds = line.boundingBox ?: continue
                val verticalPos = bounds.centerY().toFloat() / cardHeight

                var confidence = 0.5f
                if (verticalPos > 0.6f) confidence += 0.3f
                if (upperRatio > 0.9f) confidence += 0.2f

                candidates.add(lineText to confidence)
            }
        }

        return candidates.maxByOrNull { it.second }?.first ?: ""
    }

    private fun normalizeExpiry(date: String): String {
        val digits = date.filter { it.isDigit() }
        return when (digits.length) {
            4 -> "${digits.substring(0, 2)}/${digits.substring(2, 4)}"
            6 -> "${digits.substring(0, 2)}/${digits.substring(4, 6)}"
            else -> date
        }
    }

    private fun shouldIgnoreBlock(text: String): Boolean {
        val upper = text.uppercase()
        return ignoreKeywords.any { upper.contains(it) }
    }

    private fun getConsensus(history: List<String>): String {
        if (history.isEmpty()) return ""
        return history.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: ""
    }

    private fun getConfidence(value: String, history: List<String>): Float {
        if (value.isEmpty() || history.isEmpty()) return 0f
        val count = history.count { it == value }
        return count.toFloat() / history.size
    }

    internal fun reset() {
        cardNumberHistory.clear()
        expiryHistory.clear()
        nameHistory.clear()
    }

    private data class DigitGroup(
        val digits: String,
        val bounds: Rect,
        val centerY: Int
    )
}