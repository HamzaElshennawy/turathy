package net.geidea.sdk.sdk

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper

/**
 * Utility class for handling Activity/Context operations
 */
object ViewControllerUtils {

    /**
     * Get screen height in DP
     */
    fun getScreenHeightDp(context: Context): Float {
        val displayMetrics = context.resources.displayMetrics
        return displayMetrics.heightPixels / displayMetrics.density
    }

    /**
     * Find Activity from Context
     */
    fun findActivity(context: Context): Activity? {
        return when (context) {
            is Activity -> context
            is ContextWrapper -> findActivity(context.baseContext)
            else -> null
        }
    }
}