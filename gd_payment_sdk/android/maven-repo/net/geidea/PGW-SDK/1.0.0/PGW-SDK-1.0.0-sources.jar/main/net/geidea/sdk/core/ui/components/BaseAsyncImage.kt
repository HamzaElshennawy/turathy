package net.geidea.sdk.core.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.geidea.sdk.R
import net.geidea.sdk.core.utils.extensions.shimmerEffect


@Composable
internal fun BaseAsyncImage(
    imageUrl: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    shape: Shape = RectangleShape,
    contentScale: ContentScale = ContentScale.Fit,
    shimmerColor: Color = Color.LightGray.copy(alpha = 0.4f),
    backgroundColor: Color = Color.LightGray.copy(alpha = 0.1f),
    height: Dp = dimensionResource(R.dimen.spacing_24)
) {
    var loadingState by rememberSaveable { mutableStateOf(true) }

    val bitmapState = produceState<ImageBitmap?>(initialValue = null, imageUrl) {
        if (!imageUrl.isNullOrEmpty()) {
            loadingState = true
            value = try {
                withContext(Dispatchers.IO) {
                    val url = java.net.URL(imageUrl)
                    val bmp = android.graphics.BitmapFactory.decodeStream(url.openStream())
                    bmp?.asImageBitmap()
                }
            } catch (e: Exception) {
                null
            } finally {
                loadingState = false
            }
        } else {
            loadingState = false
        }
    }

    val boxModifier = if (loadingState) {
        modifier
            .height(height)
            .width(dimensionResource(R.dimen.spacing_32))
            .clip(shape)
            .background(backgroundColor)
    } else {
        modifier
            .height(height)
            .wrapContentWidth()
            .clip(shape)
    }

    Box(modifier = boxModifier) {
        bitmapState.value?.let { image ->
            Image(
                bitmap = image,
                contentDescription = contentDescription,
                contentScale = contentScale,
                modifier = Modifier
                    .fillMaxHeight()
                    .wrapContentWidth()
            )
        }

        if (loadingState) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .shimmerEffect(shape, shimmerColor, backgroundColor)
            )
        }
    }
}







