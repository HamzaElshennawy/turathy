package net.geidea.sdk.presentation.features.cardscan


internal data class ScannedCardData(
    internal val cardNumber: String = "",
    internal val expiryDate: String = "",
    internal val cardHolderName: String = "",
    internal val isValid: Boolean = false,
    internal val confidence: Float = 0f
)