package net.geidea.sdk.presentation.features.cardscan.exception

import androidx.annotation.RestrictTo

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
class ImageTypeNotSupportedException(val imageType: Int) : Exception()