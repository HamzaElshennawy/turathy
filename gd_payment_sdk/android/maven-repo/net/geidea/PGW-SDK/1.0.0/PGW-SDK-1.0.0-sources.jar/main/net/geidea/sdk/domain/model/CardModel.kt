package net.geidea.sdk.domain.model

import net.geidea.sdk.R


internal data class CardModel(
    internal val id: String,
    internal val cardNumber: String,
    internal val expiryDate: String,
    internal val cvv: String = "",
    internal val nameOnCard: String,
    internal val isCardSaved: Boolean = false,
    internal val iconResId: Int
)

internal fun getDummySavedCards() = listOf(
    CardModel(
        id = "1",
        cardNumber = "xxxx - 1877",
        expiryDate = "12/27",
        nameOnCard = "John Doe",
        isCardSaved = true,
        iconResId = R.drawable.ic_master
    ), CardModel(
        id = "2", cardNumber = "xxxx - 1878", expiryDate = "11/26",

        nameOnCard = "Jane Smith", isCardSaved = false, iconResId = R.drawable.ic_master
    ), CardModel(
        id = "3",
        cardNumber = "xxxx - 1879",
        expiryDate = "10/25",
        nameOnCard = "Alice Johnson",
        isCardSaved = true,
        iconResId = R.drawable.ic_master
    )
)

