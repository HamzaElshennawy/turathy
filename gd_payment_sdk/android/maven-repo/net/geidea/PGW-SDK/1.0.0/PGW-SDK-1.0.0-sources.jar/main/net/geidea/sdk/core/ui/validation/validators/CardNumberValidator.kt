package net.geidea.sdk.core.ui.validation.validators

import net.geidea.sdk.R
import net.geidea.sdk.core.ui.validation.ValidationResult
import net.geidea.sdk.core.ui.validation.Validator

internal class CardNumberValidator : Validator {
    override fun validate(value: String): ValidationResult {
        val cardNumberDigits = value
            .replace(" ", "")
            .replace("-", "")

        if (cardNumberDigits.isBlank()) {
            return ValidationResult(
                isValid = false,
                message = R.string.field_required
            )
        }

        if (cardNumberDigits.length < 13 || cardNumberDigits.length > 16) {
            return ValidationResult(
                isValid = false,
                message = R.string.invalid_card_number
            )
        }

        if (!isValidLuhn(cardNumberDigits)) {
            return ValidationResult(
                isValid = false,
                message = R.string.invalid_card_number
            )
        }

        return ValidationResult(isValid = true)
    }

    private fun isValidLuhn(number: String): Boolean {
        var sum = 0
        var alternate = false

        for (i in number.length - 1 downTo 0) {
            var n = number[i].digitToInt()
            if (alternate) {
                n *= 2
                if (n > 9) n -= 9
            }
            sum += n
            alternate = !alternate
        }

        return sum % 10 == 0
    }
}

