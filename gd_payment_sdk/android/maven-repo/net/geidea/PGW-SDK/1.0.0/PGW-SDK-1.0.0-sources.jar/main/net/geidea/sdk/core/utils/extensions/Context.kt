package net.geidea.sdk.core.utils.extensions

import android.content.Context
import net.geidea.sdk.sdk.SDKLanguage
import java.util.Locale

internal fun Context.withSdkLocale(language: SDKLanguage): Context {
    val locale = when (language) {
        SDKLanguage.ENGLISH -> Locale("en")
        SDKLanguage.ARABIC -> Locale("ar")
    }

    val config = resources.configuration
    config.setLocale(locale)
    return createConfigurationContext(config)
}