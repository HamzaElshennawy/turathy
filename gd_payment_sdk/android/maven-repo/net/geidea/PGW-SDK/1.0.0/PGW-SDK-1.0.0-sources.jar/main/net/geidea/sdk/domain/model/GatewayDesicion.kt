package net.geidea.sdk.domain.model

enum class GatewayDecision {
    ContinueToPayer,
    ContinueToPay,
    ContinueToPayWithNotEnrolledCard,
    Reject,
    ProceedToCReq
}
