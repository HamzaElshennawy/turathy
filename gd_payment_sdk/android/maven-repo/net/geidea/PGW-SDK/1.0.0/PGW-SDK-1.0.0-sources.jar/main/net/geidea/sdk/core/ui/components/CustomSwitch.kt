package net.geidea.sdk.core.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.theme.SdkTheme


@Composable
internal fun CustomSwitch(
    modifier: Modifier = Modifier,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    size: Dp = dimensionResource(R.dimen.spacing_24),
    trackColor: Color = if (isChecked) SdkTheme.colors.primary else SdkTheme.colors.tertiary,
    thumbColor: Color = SdkTheme.colors.surface,
    animationDuration: Int = 150
) {
    val padding = dimensionResource(R.dimen.spacing_2)
    val thumbSize = size - padding * 2

    val thumbOffset by animateDpAsState(
        targetValue = if (isChecked) size else dimensionResource(R.dimen.spacing_0),
        animationSpec = tween(durationMillis = animationDuration),
        label = "thumbOffset"
    )

    Box(
        modifier = modifier
            .size(width = size * 2, height = size)
            .clip(RoundedCornerShape(percent = 50))
            .background(trackColor)
            .toggleable(
                value = isChecked, onValueChange = onCheckedChange, role = Role.Switch
            ), contentAlignment = Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .padding(padding)
                .offset(x = thumbOffset)
                .size(thumbSize)
                .clip(CircleShape)
                .background(thumbColor)
        )
    }
}