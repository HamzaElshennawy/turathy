package net.geidea.sdk.presentation.features.paymentdetails.components.card.carddetails


import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import net.geidea.sdk.R
import net.geidea.sdk.core.ui.components.BaseAsyncImage
import net.geidea.sdk.core.ui.components.CustomDatePickerDialog
import net.geidea.sdk.core.ui.components.CustomSwitch
import net.geidea.sdk.core.ui.components.PrimaryTextField
import net.geidea.sdk.core.ui.models.TextFieldInput
import net.geidea.sdk.core.ui.theme.SdkTheme
import net.geidea.sdk.core.ui.validation.FieldValidationTrigger
import net.geidea.sdk.core.ui.visualtransformation.CardNumberVisualTransformation
import net.geidea.sdk.core.utils.constants.Constants
import net.geidea.sdk.core.utils.extensions.formatExpiryDate
import net.geidea.sdk.domain.model.paymentdetails.SupportedCard
import net.geidea.sdk.presentation.features.cardscan.screen.activity.CardScanSheet
import net.geidea.sdk.presentation.features.cardscan.screen.activity.CardScanSheetParams
import net.geidea.sdk.presentation.features.cardscan.screen.activity.CardScanSheetResult
import net.geidea.sdk.presentation.features.paymentdetails.viewmodel.PaymentState

@Composable
internal fun CardDetailsSection(
    modifier: Modifier = Modifier,
    paymentState: PaymentState,
    onEvent: (CardDetailsEvent) -> Unit,
) {
    val state = paymentState.cardDetailsState

    val currentOnEvent by rememberUpdatedState(onEvent)
    val launcher =
        rememberLauncherForActivityResult(CardScanSheet.activityResultContract) { result ->
            when (result) {
                is CardScanSheetResult.Completed -> {
                    println("Card: ${result.scannedCard.pan}")
                    currentOnEvent(CardDetailsEvent.CardNumberChanged(result.scannedCard.pan))
                }

                is CardScanSheetResult.Canceled -> {}
                is CardScanSheetResult.Failed -> {}
            }
        }
    if (state.showDatePicker) {
        Dialog(onDismissRequest = {
            currentOnEvent(CardDetailsEvent.ShowDatePickerChanged(false))
        }) {
            CustomDatePickerDialog(
                initialMonth = state.month,
                initialYear = state.year,
                onDateConfirmed = { date ->
                    currentOnEvent(CardDetailsEvent.ExpiryDateChanged(formatExpiryDate(date)))
                    currentOnEvent(CardDetailsEvent.ShowDatePickerChanged(false))
                },
                onDismissRequest = {
                    currentOnEvent(CardDetailsEvent.ShowDatePickerChanged(false))
                },
            )
        }
    }

    Column(
        modifier = modifier.padding(top = dimensionResource(R.dimen.spacing_24)),
        verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.spacing_16))
    ) {
        Text(
            text = stringResource(R.string.card_details),
            style = SdkTheme.typography.semibold16.copy(color = SdkTheme.colors.onPrimary)
        )

        Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            // Card number
            CardNumberTextField(
                modifier = modifier.weight(1f),
                state.cardNumber,
                currentOnEvent,
                state.possibleBrand
            )

            Spacer(
                Modifier.width(dimensionResource(R.dimen.spacing_16))
            )

            //card scan
            Box(
                modifier = Modifier
                    .wrapContentSize()
                    .border(
                        width = dimensionResource(R.dimen.spacing_1),
                        color = SdkTheme.colors.neutral20,
                        shape = RoundedCornerShape(dimensionResource(R.dimen.spacing_8))
                    )
                    .padding(dimensionResource(R.dimen.spacing_14))
                    .clickable {
                        launcher.launch(CardScanSheetParams())
                    }
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_scan),
                    contentDescription = "Scan Card",
                    modifier = Modifier.width(dimensionResource(R.dimen.spacing_24)),
                    colorFilter = ColorFilter.tint(SdkTheme.colors.onPrimary)

                )
            }
        }

        // Expiry + CVV Row
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.spacing_16))
        ) {
            ExpiryDateTextField(state.expiryDate, currentOnEvent)

            CvvTextField(state.cvv, currentOnEvent)
        }

        // Name on card
        CardNameTextFiled(state.nameOnCard, currentOnEvent)

        if (state.showSavedCard && paymentState.paymentOperation != Constants.PaymentOperation.SAVE_CARD)
            SaveCardOption(
                isChecked = state.isCardSaved, onCheckedChange = {
                    currentOnEvent(CardDetailsEvent.CardSavedChanged(it))
                })

    }
}

@Composable
private fun CardNumberTextField(
    modifier: Modifier = Modifier,
    state: TextFieldInput,
    currentOnEvent: (CardDetailsEvent) -> Unit,
    possibleBrand: SupportedCard? = null,
) {
    PrimaryTextField(
        modifier = modifier.wrapContentHeight(),
        value = state.value,
        onValueChange = { input ->
            val digits = input.filter(Char::isDigit).take(16)
            if (digits != state.value) {
                currentOnEvent(CardDetailsEvent.CardNumberChanged(digits))
            }
        },
        validationTrigger = FieldValidationTrigger.ON_FOCUS_LOST,
        isError = !state.validation.isValid,
        errorMessage = state.validation.message,
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number
        ),
        visualTransformation = CardNumberVisualTransformation(),
        label = R.string.card_number,
        trailingIcon = {
            if (possibleBrand != null) {
                BaseAsyncImage(
                    imageUrl = possibleBrand.icon,
                    contentDescription = null,
                    height = dimensionResource(R.dimen.spacing_20)
                )
            } else {
                Icon(
                    painter = painterResource(R.drawable.ic_card_number),
                    contentDescription = null,
                    tint = Color.Unspecified
                )
            }
        })
}

@Composable
private fun RowScope.ExpiryDateTextField(
    state: TextFieldInput,
    currentOnEvent: (CardDetailsEvent) -> Unit
) {
    Box(
        modifier = Modifier
            .weight(1f)
            .height(IntrinsicSize.Min)
    ) {
        PrimaryTextField(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            value = state.value,
            readOnly = true,
            onValueChange = { },
            label = R.string.card_expiry,
            isError = !state.validation.isValid,
            errorMessage = state.validation.message,
            trailingIcon = {
                IconButton(
                    onClick = {
                        currentOnEvent(CardDetailsEvent.ShowDatePickerChanged(true))
                    },
                    modifier = Modifier
                        .zIndex(1f)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_calender),
                        contentDescription = null,
                        tint = Color.Unspecified
                    )
                }
            }
        )

        Box(
            modifier = Modifier
                .matchParentSize()
                .clickable(
                    role = Role.Button,
                    onClick = {
                        currentOnEvent(CardDetailsEvent.ShowDatePickerChanged(true))
                    }
                )
        )
    }
}


@Composable
private fun RowScope.CvvTextField(
    state: TextFieldInput, currentOnEvent: (CardDetailsEvent) -> Unit
) {
    PrimaryTextField(
        modifier = Modifier
            .weight(1f)
            .wrapContentHeight(),
        value = state.value,
        onValueChange = { input ->
            val digits = input.take(4)
            if (digits != state.value) {
                currentOnEvent(CardDetailsEvent.CvvChanged(digits))
            }
        },
        trailingIcon = {
            Icon(
                painter = painterResource(R.drawable.ic_cvv),
                contentDescription = null,
                tint = Color.Unspecified,
                modifier = Modifier.zIndex(1f)
            )
        },
        label = R.string.CVV,
        isError = !state.validation.isValid,
        errorMessage = state.validation.message,
        visualTransformation = PasswordVisualTransformation(),
        validationTrigger = FieldValidationTrigger.ON_FOCUS_LOST,
        keyboardActions = KeyboardActions.Default,
        keyboardOptions = KeyboardOptions.Default.copy(
            keyboardType = KeyboardType.Number
        ),

        )
}

@Composable
private fun CardNameTextFiled(
    cardName: TextFieldInput, currentOnEvent: (CardDetailsEvent) -> Unit
) {
    PrimaryTextField(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        value = cardName.value,
        onValueChange = { currentOnEvent(CardDetailsEvent.CardNameChanged(it)) },
        label = R.string.card_name,
        isError = !cardName.validation.isValid,
        errorMessage = cardName.validation.message,
        validationTrigger = FieldValidationTrigger.ON_FOCUS_LOST,
    )
}


@Composable
private fun SaveCardOption(
    modifier: Modifier = Modifier, isChecked: Boolean, onCheckedChange: (Boolean) -> Unit
) {
    val layoutDirection = LocalLayoutDirection.current
    val paddingModifier = Modifier.padding(
        end = if (layoutDirection == LayoutDirection.Ltr) dimensionResource(R.dimen.spacing_12)
        else dimensionResource(R.dimen.spacing_0),
        start = if (layoutDirection == LayoutDirection.Rtl) dimensionResource(R.dimen.spacing_12)
        else dimensionResource(R.dimen.spacing_0)
    )

    Row(
        modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .then(paddingModifier),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = stringResource(R.string.save_card_title),
                style = SdkTheme.typography.medium14.copy(color = SdkTheme.colors.onPrimary),
            )


            Text(
                modifier = Modifier.padding(top = dimensionResource(R.dimen.spacing_8)),
                text = stringResource(R.string.save_card_description),
                style = SdkTheme.typography.regular12.copy(
                    color = SdkTheme.colors.onPrimary
                ),
            )
        }

        Box(
            modifier = Modifier.wrapContentSize(), contentAlignment = Alignment.Center
        ) {
            CustomSwitch(
                isChecked = isChecked,
                onCheckedChange = onCheckedChange,
            )
        }
    }
}