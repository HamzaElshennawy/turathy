package net.geidea.sdk.core.ui.validation

internal enum class FieldValidationTrigger {
    ON_FOCUS_LOST,
    ON_VALUE_CHANGE
}